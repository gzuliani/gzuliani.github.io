// TiffReader.cpp: implementation of the CTiffReader class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TiffReader.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTiffReader::CTiffReader(LPCTSTR Path)
{
	m_IsTiff = FALSE;
	
	m_Width = 0;
	m_Height = 0;

	// default is 300x300 dpi
	m_ResUnit = 2;
	m_HorzRes = 300;
	m_VertRes = 300;

	// open image file
	if (!m_Image.Open(Path,CFile::modeRead))
		return;

	// parse the header
	if (!(m_IsTiff = ReadHeader()))
	{
		m_Image.Close();
		return;
	}

	// examine the tags
	if (!ReadImageTags(m_Hdr.ifd_offset))
	{
		m_Image.Close();
		return;
	}

	// all done!
	m_Image.Close();
}

CTiffReader::~CTiffReader()
{

}



//////////////////////////////////////////////////////////////////////
// public interface

long CTiffReader::GetHorzDPI()
{
	if ((!m_IsTiff) || ((m_ResUnit != 2) && (m_ResUnit != 3)))
		return 0;

	if (m_ResUnit == 2)
		// uses inches
		return m_HorzRes;	
	else
		// uses cm: convert!
		return (long)(m_HorzRes * 2.54);
}

long CTiffReader::GetVertDPI()
{
	if ((!m_IsTiff) || ((m_ResUnit != 2) && (m_ResUnit != 3)))
		return 0;

	if (m_ResUnit == 2)
		// uses inches
		return m_VertRes;	
	else
		// uses cm: convert!
		return (long)(m_VertRes * 2.54);
}

double CTiffReader::GetMmWidth()
{
	long hRes = GetHorzDPI();
	return hRes ? ((m_Width + 0.) / hRes * 25.4) : 0;
}

double CTiffReader::GetMmHeight()
{
	long hRes = GetVertDPI();
	return hRes ? ((m_Height + 0.) / hRes * 25.4) : 0;
}

double CTiffReader::GetInchesWidth()
{
	long hRes = GetHorzDPI();
	return hRes ? ((m_Width + 0.) / hRes) : 0;
}

double CTiffReader::GetInchesHeight()
{
	long hRes = GetVertDPI();
	return hRes ? ((m_Height + 0.) / hRes) : 0;
}



//////////////////////////////////////////////////////////////////////
// protected helper functions

BOOL CTiffReader::ReadHeader()
{
	// read the header
	if (m_Image.Read(&m_Hdr,sizeof(m_Hdr)) != sizeof(m_Hdr))
		return FALSE;
	
	if ((m_Hdr.byte_order != *(unsigned short*)"II")
		&& (m_Hdr.byte_order != *(unsigned short*)"MM"))
		return FALSE;

	m_IsMotorola = (m_Hdr.byte_order == *(unsigned short*)"MM");

	m_Hdr.version_id = MakeShort(m_Hdr.version_id);
	m_Hdr.ifd_offset = MakeLong(m_Hdr.ifd_offset);

	if (m_Hdr.version_id != (unsigned short)0x2a)
		return FALSE;

	return (m_Hdr.ifd_offset != 0);
}

BOOL CTiffReader::ReadImageTags(unsigned long ifd)
{
	// go to the specified ifd
	if (m_Image.Seek((DWORD)ifd,CFile::begin) != (LONG)ifd)
		return FALSE;

	// read the tag count word
	unsigned short TotalTags = 0;
	if (m_Image.Read(&TotalTags,sizeof(TotalTags)) != sizeof(TotalTags))
		return FALSE;

	// rerrange read bytes
	TotalTags = MakeShort(TotalTags);

	for (long Tag = 0; Tag < TotalTags; Tag++)
		if (!ReadNextTag())
			return FALSE;

	return TRUE;
}

BOOL CTiffReader::ReadNextTag()
{
	TAG Tag;
	if (m_Image.Read(&Tag,sizeof(Tag)) != sizeof(Tag))
		return FALSE;

	// rerrange read bytes
	Tag.id = MakeShort(Tag.id);
	Tag.type = MakeShort(Tag.type);
	Tag.length = MakeLong(Tag.length);
	Tag.offset = MakeLong(Tag.offset);

	// is it a recognized tag?
	switch (Tag.id)
	{
		case 256 :	// image width
			if (Tag.type == 4)
				m_Width = Tag.offset;
			else
				if (m_IsMotorola)
					m_Width = (short)(Tag.offset >> 16);
				else
					m_Width = (short)Tag.offset;
			break;
		case 257 :	// image length
			if (Tag.type == 4)
				m_Height = Tag.offset;
			else
				if (m_IsMotorola)
					m_Height = Tag.offset >> 16;
				else
					m_Height = (short)Tag.offset;
			break;
		case 282 :	// x resolution
		{	
			long Num,Den;
			DWORD CurPos = m_Image.GetPosition();
			m_Image.Seek((DWORD)Tag.offset,CFile::begin);
			m_Image.Read(&Num,sizeof(Num));
			m_Image.Read(&Den,sizeof(Den));
			m_Image.Seek(CurPos,CFile::begin);
			Num = MakeLong(Num);
			Den = MakeLong(Den);
			m_HorzRes = (long)((Num + 0.) / Den);
			break;
		}
		case 283 :	// y resolution
		{
			long Num,Den;
			DWORD CurPos = m_Image.GetPosition();
			m_Image.Seek((DWORD)Tag.offset,CFile::begin);
			m_Image.Read(&Num,sizeof(Num));
			m_Image.Read(&Den,sizeof(Den));
			m_Image.Seek(CurPos,CFile::begin);
			Num = MakeLong(Num);
			Den = MakeLong(Den);
			m_VertRes = (long)((Num + 0.) / Den);
			break;
		}
		case 296 :	// resolution unit
			if (m_IsMotorola)
				m_ResUnit = (short)(Tag.offset >> 16);
			else
				m_ResUnit = (short)Tag.offset;
			break;
	}
	
	return TRUE;
}



