// FPSrv.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "FPSrv.h"
#include "FPSrvMain.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFPSrvApp

BEGIN_MESSAGE_MAP(CFPSrvApp, CWinApp)
	//{{AFX_MSG_MAP(CFPSrvApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFPSrvApp construction

CFPSrvApp::CFPSrvApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CFPSrvApp object

CFPSrvApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CFPSrvApp initialization

BOOL CFPSrvApp::InitInstance()
{
	SetRegistryKey(IDS_REG_CLASS);
	Enable3dControlsStatic();

	BOOL Inform = ((_tcsstr(m_lpCmdLine,_T("/i")) != NULL)
					|| (_tcsstr(m_lpCmdLine,_T("/I")) != NULL));

	if ((m_pMainWnd = new CFPSrvMain(Inform)) != NULL)
		return ((CFPSrvMain*)m_pMainWnd)->Create();
	else
		return FALSE;
}

int CFPSrvApp::ExitInstance() 
{
	if (m_pMainWnd != NULL)
		delete m_pMainWnd;

	return CWinApp::ExitInstance();
}
