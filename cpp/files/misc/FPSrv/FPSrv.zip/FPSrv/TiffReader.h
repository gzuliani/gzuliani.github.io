// TiffReader.h: interface for the CTiffReader class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TIFFREADER_H__3609BB21_78CA_11D2_9DF6_444553540000__INCLUDED_)
#define AFX_TIFFREADER_H__3609BB21_78CA_11D2_9DF6_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CTiffReader  
{
protected:
	struct HEADER
	{
		unsigned short	byte_order;
		unsigned short	version_id;
		unsigned long	ifd_offset;
	};

	struct TAG
	{
		unsigned short	id;
		unsigned short	type;
		unsigned long	length;
		unsigned long	offset;
	};

public:
	CTiffReader(LPCTSTR Path);
	virtual ~CTiffReader();

	// public interface
	BOOL IsTiff() { return m_IsTiff; }

	long GetHorzDPI();
	long GetVertDPI();

	long GetWidth() { return m_Width; }
	long GetHeight() { return m_Height; }

	double GetMmWidth();
	double GetMmHeight();

	double GetInchesWidth();
	double GetInchesHeight();

protected:
	CFile	m_Image;
	HEADER	m_Hdr;
	BOOL	m_IsMotorola;
		
	// tiff data
	BOOL m_IsTiff;

	long m_Width;
	long m_Height;
	long m_HorzRes;
	long m_VertRes;
	short m_ResUnit;
	
	BOOL ReadHeader();
	BOOL ReadImageTags(unsigned long ifd);
	BOOL ReadNextTag();

	// inline functions
	unsigned long MakeLong(unsigned long ul)
	{
		return m_IsMotorola ? (unsigned long)(((ul & 0x000000ff) << 24) | ((ul & 0x0000ff00) << 8) | ((ul & 0x00ff0000) >> 8) | ((ul & 0xff000000) >> 24)) : ul;
	}

	unsigned short MakeShort(unsigned short us)
	{
		return m_IsMotorola ? (unsigned short)(((us & 0x00ff) << 8) | ((us & 0xff00) >> 8)) : us;
	}
};

#endif // !defined(AFX_TIFFREADER_H__3609BB21_78CA_11D2_9DF6_444553540000__INCLUDED_)
