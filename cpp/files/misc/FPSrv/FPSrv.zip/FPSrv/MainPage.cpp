// MainPage.cpp : implementation file
//

#include "stdafx.h"
#include "MainPage.h"
#include "TrickDlg.h"
#include "CreditsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainPage property page

IMPLEMENT_DYNCREATE(CMainPage, CPropertyPage)

CMainPage::CMainPage() : CPropertyPage(CMainPage::IDD)
{
	//{{AFX_DATA_INIT(CMainPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	// load the icons
	m_IdleIcon = AfxGetApp()->LoadIcon(IDI_IDLE);
	m_WaitIcon = AfxGetApp()->LoadIcon(IDI_WAIT);
	m_BusyIcon = AfxGetApp()->LoadIcon(IDI_BUSY);

	// undocumented starts from the beginning
	m_Step = 0;
	m_Timer = -1;
	m_ScrollingMsg = _T("                                ");
	m_ScrollingMsg += _T("                                ");
	m_ScrollingMsg += _T("Congratulations, ");
	m_ScrollingMsg += _T("you are on the right way for ");
	m_ScrollingMsg += _T("the undocumented of the year...           ");
	m_ScrollingMsg += _T("just another step (or two) and you will ");
	m_ScrollingMsg += _T("discover the final joke!                      ");
	m_ScrollingMsg += _T("Hold on!!!         ");
	m_ScrollingCount = 0;
	m_TrickMenu.LoadMenu(IDR_TRICK_MENU);
}

CMainPage::~CMainPage()
{
}

void CMainPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMainPage)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMainPage, CPropertyPage)
	//{{AFX_MSG_MAP(CMainPage)
	ON_BN_CLICKED(IDC_SHUTDOWN, OnShutDown)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_TIMER()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP

	ON_COMMAND(ID_TRICK_STOP,OnScrollStop)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainPage message handlers

BOOL CMainPage::OnInitDialog() 
{
	CString CopyRight;
	CopyRight.LoadString(IDS_COPYRIGHT);
	SetDlgItemText(IDC_COPYRIGHT,CopyRight);

	CPropertyPage::OnInitDialog();
	return TRUE;
}

void CMainPage::OnShutDown() 
{
	if (m_Step != 3)
		AfxGetApp()->m_pMainWnd->PostMessage(WM_COMMAND,ID_FPSRV_CLOSE);
	else 
	{
		if ((AfxMessageBox(IDS_CONFIRM_CLOSE,MB_ICONEXCLAMATION | MB_YESNO) == IDYES)
			&& (AfxMessageBox(_T("Are you REALLY sure?"),MB_ICONEXCLAMATION | MB_YESNO) == IDNO))
		{
			// open the undocumented window!
			AfxMessageBox(_T("Well done!\nJust one more click for the credits..."),MB_ICONINFORMATION);
			CCreditsDlg dlg;
			dlg.DoModal();
		}
		else
		{
			m_Step = -1;
			AfxGetApp()->m_pMainWnd->PostMessage(WM_COMMAND,ID_FPSRV_CLOSE);
		}
	}
}



void CMainPage::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	CPropertyPage::OnLButtonDblClk(nFlags, point);

	switch (m_Step)
	{
		case 0:
			// double click the icon holding down the CTRL key
			if ((nFlags & MK_CONTROL) && !(nFlags & MK_SHIFT))
			{
				// clicked the icon?
				CRect IconRect;
				GetDlgItem(IDC_FPSRV_ICON)->GetWindowRect(IconRect);
				ScreenToClient(IconRect);
	
				if (!IconRect.PtInRect(point))
					return;

				// we got it!
				CClientDC DC(this);
				DC.DrawIcon(IconRect.TopLeft(),m_WaitIcon);
				Sleep(250);
				DC.DrawIcon(IconRect.TopLeft(),m_BusyIcon);
				Sleep(250);
				DC.DrawIcon(IconRect.TopLeft(),m_IdleIcon);
				m_Step = 1;
			}
			break;

		case 1:
			// double click the icon holding down the SHIFT key
			if (!(nFlags & MK_CONTROL) && (nFlags & MK_SHIFT))
			{
				// clicked the icon?
				CRect IconRect;
				GetDlgItem(IDC_FPSRV_ICON)->GetWindowRect(IconRect);
				ScreenToClient(IconRect);
	
				if (!IconRect.PtInRect(point))
					return;

				// we got it!
				CTrickDlg dlg;
				if (dlg.DoModal() == IDOK)
				{
					// show the scrolling message
					m_ScrollingPos = 0;
					m_Timer = SetTimer(1,75,NULL);
					m_Step = 2;
				}
				else
					m_Step = -1;
			}
			break;

		case 2:
			// see context menu management
			AfxMessageBox(_T("Why are you sending me all these clicks?"),MB_ICONQUESTION);
			break;

		case 3:
			// see context menu management
			AfxMessageBox(_T("What are you searching for?"),MB_ICONQUESTION);
			break;
	}
}



// ====================
// scroll timer
// ====================

void CMainPage::OnTimer(UINT nIDEvent) 
{
	if (nIDEvent == m_Timer)
	{
		// scroll the copyright message
		if (m_ScrollingPos >= m_ScrollingMsg.GetLength())
		{
			m_ScrollingPos = 0;
			m_ScrollingCount++;
		}

		CString Msg = m_ScrollingMsg.Mid(m_ScrollingPos);
		SetDlgItemText(IDC_COPYRIGHT,Msg);
		m_ScrollingPos++;
	}
	else
		CPropertyPage::OnTimer(nIDEvent);
}



// ====================
// context menu
// ====================

void CMainPage::OnRButtonDown(UINT nFlags, CPoint point) 
{
	if (m_Step == 2)	
	{
		// clicked the copyright text?
		CRect TextRect;
		GetDlgItem(IDC_COPYRIGHT)->GetWindowRect(TextRect);
		ScreenToClient(TextRect);
	
		if (!TextRect.PtInRect(point))
			return;

		// open the context menu
		CMenu* pMenu = m_TrickMenu.GetSubMenu(0);	
		CPoint MenuPos(point);
		ClientToScreen(&MenuPos);
		pMenu->TrackPopupMenu(TPM_LEFTALIGN,MenuPos.x,MenuPos.y,this);
	}
	
	CPropertyPage::OnRButtonDown(nFlags, point);
}

LONG CMainPage::OnScrollStop(UINT wParam, LONG lParam)
{
	if (m_Timer != -1)
	{
		KillTimer(m_Timer);
		m_Timer = -1;
		
		CString CopyRight;
		CopyRight.LoadString(IDS_COPYRIGHT);
		SetDlgItemText(IDC_COPYRIGHT,CopyRight);
	}

	if ((m_Step == 2) && (m_ScrollingCount > 1))
		m_Step = 3;
	else
		m_Step = -1;

	return 1;
}

