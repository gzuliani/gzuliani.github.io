// AboutDialog.cpp : implementation file
//

#include "stdafx.h"
#include "AboutDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDialog dialog


CAboutDialog::CAboutDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CAboutDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAboutDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	// load the icons
	m_IdleIcon = AfxGetApp()->LoadIcon(IDI_IDLE);
	m_WaitIcon = AfxGetApp()->LoadIcon(IDI_WAIT);
	m_BusyIcon = AfxGetApp()->LoadIcon(IDI_BUSY);

	m_Timer = -1;
}


void CAboutDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAboutDialog, CDialog)
	//{{AFX_MSG_MAP(CAboutDialog)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAboutDialog message handlers

BOOL CAboutDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_Timer = SetTimer(1,500,NULL);
	return TRUE;
}

void CAboutDialog::OnTimer(UINT nIDEvent) 
{
	if (nIDEvent == m_Timer)
	{
		HICON Icon = m_IdleIcon;
		CRect IconRect;
		GetDlgItem(IDC_FPSRV_ICON)->GetWindowRect(IconRect);
		ScreenToClient(IconRect);

		switch (rand() % 3)
		{
			case 0: Icon = m_IdleIcon; break;
			case 1:	Icon = m_WaitIcon; break;
			case 2: Icon = m_BusyIcon; break;
		}

		CClientDC DC(this);
		DC.DrawIcon(IconRect.TopLeft(),Icon);
	}
	else
		CDialog::OnTimer(nIDEvent);
}
