// DirsPage.cpp : implementation file
//

#include "stdafx.h"
#include "DirsPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDirsPage property page

IMPLEMENT_DYNCREATE(CDirsPage, CPropertyPage)

CDirsPage::CDirsPage() : CPropertyPage(CDirsPage::IDD)
{
	//{{AFX_DATA_INIT(CDirsPage)
	m_InputDir = _T("");
	m_OutputDir = _T("");
	m_ErrorDir = _T("");
	m_Overwrite = FALSE;
	//}}AFX_DATA_INIT

	m_RegDir.LoadString(IDS_REG_DIRS);
	m_RegInputDir.LoadString(IDS_REG_DIRINPUT);
	m_RegOutputDir.LoadString(IDS_REG_DIROUTPUT);
	m_RegErrorDir.LoadString(IDS_REG_DIRERROR);
	m_RegOverwrite.LoadString(IDS_REG_DIROVERWRITE);
}

CDirsPage::~CDirsPage()
{
}

void CDirsPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDirsPage)
	DDX_Text(pDX, IDC_INPUTDIR, m_InputDir);
	DDX_Text(pDX, IDC_OUTPUTDIR, m_OutputDir);
	DDX_Text(pDX, IDC_ERRORDIR, m_ErrorDir);
	DDX_Check(pDX, IDC_OVERWRITE, m_Overwrite);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDirsPage, CPropertyPage)
	//{{AFX_MSG_MAP(CDirsPage)
	ON_BN_CLICKED(IDC_BROWSEINPUTDIR, OnBrowseInputDir)
	ON_BN_CLICKED(IDC_BROWSEOUTPUTDIR, OnBrowseOutputDir)
	ON_BN_CLICKED(IDC_BROWSEERRORDIR, OnBrowseErrorDir)
	ON_EN_CHANGE(IDC_ERRORDIR, OnGenericChange)
	ON_EN_CHANGE(IDC_INPUTDIR, OnGenericChange)
	ON_EN_CHANGE(IDC_OUTPUTDIR, OnGenericChange)
	ON_BN_CLICKED(IDC_OVERWRITE, OnGenericChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDirsPage message handlers

BOOL CDirsPage::OnInitDialog() 
{
	// load directories names
	m_InputDir = AfxGetApp()->GetProfileString(m_RegDir,m_RegInputDir);
	m_OutputDir = AfxGetApp()->GetProfileString(m_RegDir,m_RegOutputDir);
	m_ErrorDir = AfxGetApp()->GetProfileString(m_RegDir,m_RegErrorDir);
	m_Overwrite = AfxGetApp()->GetProfileInt(m_RegDir,m_RegOverwrite,FALSE);

	CPropertyPage::OnInitDialog();
	return TRUE;
}

void CDirsPage::OnBrowseInputDir() 
{
	// browse the directory tree
	AfxMessageBox("Ehm, not yet available. Sorry!",MB_ICONINFORMATION);
	SetModified(TRUE);
}

void CDirsPage::OnBrowseOutputDir() 
{
	// browse the directory tree
	AfxMessageBox("Ehm, not yet available. Sorry!",MB_ICONINFORMATION);
	SetModified(TRUE);
}

void CDirsPage::OnBrowseErrorDir() 
{
	// browse the directory tree
	AfxMessageBox("Ehm, not yet available. Sorry!",MB_ICONINFORMATION);
	SetModified(TRUE);
}

void CDirsPage::OnGenericChange() 
{
	SetModified(TRUE);
}

BOOL CDirsPage::OnApply() 
{
	// get the dialog data
	UpdateData(TRUE);

	// do the directories exist?
	if (GetFileAttributes(m_InputDir) == (DWORD)-1)
	{
		AfxMessageBox(IDS_INVALIDINPUTDIR,MB_ICONSTOP);
		((CPropertySheet*)GetParent())->SetActivePage(this);
		return FALSE;
	}
		
	if (GetFileAttributes(m_OutputDir) == (DWORD)-1)
	{
		AfxMessageBox(IDS_INVALIDOUTPUTDIR,MB_ICONSTOP);
		((CPropertySheet*)GetParent())->SetActivePage(this);
		return FALSE;
	}

	if (GetFileAttributes(m_ErrorDir) == (DWORD)-1)
	{
		AfxMessageBox(IDS_INVALIDERRORDIR,MB_ICONSTOP);
		((CPropertySheet*)GetParent())->SetActivePage(this);
		return FALSE;
	}

	// save directory names
	AfxGetApp()->WriteProfileString(m_RegDir,m_RegInputDir,m_InputDir);
	AfxGetApp()->WriteProfileString(m_RegDir,m_RegOutputDir,m_OutputDir);
	AfxGetApp()->WriteProfileString(m_RegDir,m_RegErrorDir,m_ErrorDir);
	AfxGetApp()->WriteProfileInt(m_RegDir,m_RegOverwrite,m_Overwrite);

	return CPropertyPage::OnApply();
}


