#if !defined(AFX_DIRSPAGE_H__ED73DBE1_70CF_11D2_9DF6_444553540000__INCLUDED_)
#define AFX_DIRSPAGE_H__ED73DBE1_70CF_11D2_9DF6_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DirsPage.h : header file
//

#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CDirsPage dialog

class CDirsPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CDirsPage)

// Construction
public:
	CDirsPage();
	~CDirsPage();

protected:
// Dialog Data
	//{{AFX_DATA(CDirsPage)
	enum { IDD = IDD_FPSRV_DIRS };
	CString	m_InputDir;
	CString	m_OutputDir;
	CString	m_ErrorDir;
	BOOL	m_Overwrite;
	//}}AFX_DATA

	// registry keys
	CString	m_RegDir;
	CString	m_RegInputDir;
	CString	m_RegOutputDir;
	CString	m_RegErrorDir;
	CString m_RegOverwrite;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CDirsPage)
	public:
	virtual BOOL OnApply();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CDirsPage)
	afx_msg void OnBrowseInputDir();
	afx_msg void OnBrowseOutputDir();
	afx_msg void OnBrowseErrorDir();
	virtual BOOL OnInitDialog();
	afx_msg void OnGenericChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIRSPAGE_H__ED73DBE1_70CF_11D2_9DF6_444553540000__INCLUDED_)
