#if !defined(AFX_MAINPAGE_H__ED73DBE2_70CF_11D2_9DF6_444553540000__INCLUDED_)
#define AFX_MAINPAGE_H__ED73DBE2_70CF_11D2_9DF6_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MainPage.h : header file
//

#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CMainPage dialog

class CMainPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CMainPage)

// Construction
public:
	CMainPage();
	~CMainPage();

protected:
// Dialog Data
	//{{AFX_DATA(CMainPage)
	enum { IDD = IDD_FPSRV_MAIN };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

	// undocumented support
	int		m_Step;
	UINT	m_Timer;
	CString	m_ScrollingMsg;
	int 	m_ScrollingPos;
	int 	m_ScrollingCount;
	CMenu	m_TrickMenu;

	// icons
	HICON m_IdleIcon;
	HICON m_WaitIcon;
	HICON m_BusyIcon;

	afx_msg LONG OnScrollStop(UINT wParam, LONG lParam);

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CMainPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CMainPage)
	afx_msg void OnShutDown();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINPAGE_H__ED73DBE2_70CF_11D2_9DF6_444553540000__INCLUDED_)
