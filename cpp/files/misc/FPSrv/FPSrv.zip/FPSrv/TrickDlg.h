#if !defined(AFX_TRICKDLG_H__C7040FC1_7C91_11D2_9DF6_444553540000__INCLUDED_)
#define AFX_TRICKDLG_H__C7040FC1_7C91_11D2_9DF6_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// TrickDlg.h : header file
//

#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CTrickDlg dialog

class CTrickDlg : public CDialog
{
// Construction
public:
	CTrickDlg(CWnd* pParent = NULL);   // standard constructor

protected:
// Dialog Data
	//{{AFX_DATA(CTrickDlg)
	enum { IDD = IDD_TRICKY };
		// NOTE: the ClassWizard will add data members here	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTrickDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTrickDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPuah();
	afx_msg void OnNotBad();
	virtual void OnOK();
	afx_msg void OnMasterPiece();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRICKDLG_H__C7040FC1_7C91_11D2_9DF6_444553540000__INCLUDED_)
