// AdvancedPage.cpp : implementation file
//

#include "stdafx.h"
#include "AdvancedPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAdvancedPage property page

IMPLEMENT_DYNCREATE(CAdvancedPage, CPropertyPage)

CAdvancedPage::CAdvancedPage() : CPropertyPage(CAdvancedPage::IDD)
{
	//{{AFX_DATA_INIT(CAdvancedPage)
	m_MultiPrint = FALSE;
	m_AutoRotate = FALSE;
	m_AutoDPI = FALSE;
	m_HorzDPI = 0;
	m_VertDPI = 0;
	m_LockDPI = FALSE;
	m_AutoMargins = FALSE;
	m_TopMargin = 0;
	m_LeftMargin = 0;
	m_LockMargins = FALSE;
	m_AutoCut = FALSE;
	m_CutHeight = 0;
	m_CutGap = 0;
	m_Inform = FALSE;
	m_CreateLog = FALSE;
	//}}AFX_DATA_INIT
	
	// set exclamation mark icon for this page
	m_psp.dwFlags |= PSP_USEHICON;
	m_psp.hIcon = LoadIcon(NULL,IDI_EXCLAMATION);

	m_RegAdv.LoadString(IDS_REG_ADVANCED);
	m_RegMultiPrint.LoadString(IDS_REG_MULTIPRINTADV);
	m_RegAutoRotate.LoadString(IDS_REG_AUTOROTATEADV);
	m_RegAutoDPI.LoadString(IDS_REG_AUTODPIADV);
	m_RegHorzDPI.LoadString(IDS_REG_HORZDPIADV);
	m_RegVertDPI.LoadString(IDS_REG_VERTDPIADV);
	m_RegLockDPI.LoadString(IDS_REG_LOCKDPIADV);
	m_RegAutoMargins.LoadString(IDS_REG_AUTOMARGINSADV);
	m_RegTopMargin.LoadString(IDS_REG_TOPMARGINADV);
	m_RegLeftMargin.LoadString(IDS_REG_LEFTMARGINADV);
	m_RegLockMargins.LoadString(IDS_REG_LOCKMARGINSADV);
	m_RegAutoCut.LoadString(IDS_REG_AUTOCUTADV);
	m_RegCutHeight.LoadString(IDS_REG_CUTHEIGHTADV);
	m_RegCutGap.LoadString(IDS_REG_CUTGAPADV);
	m_RegCreateLog.LoadString(IDS_REG_CREATELOGADV);
	m_RegInform.LoadString(IDS_REG_INFORMADV);
}

CAdvancedPage::~CAdvancedPage()
{
}

void CAdvancedPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAdvancedPage)
	DDX_Check(pDX, IDC_MULTIPRINT, m_MultiPrint);
	DDX_Check(pDX, IDC_ROTATE, m_AutoRotate);
	DDX_Check(pDX, IDC_DPI, m_AutoDPI);
	DDX_Text(pDX, IDC_HORZDPI, m_HorzDPI);
	DDX_Text(pDX, IDC_VERTDPI, m_VertDPI);
	DDX_Check(pDX, IDC_LOCKDPI, m_LockDPI);
	DDX_Check(pDX, IDC_MARGINS, m_AutoMargins);
	DDX_Text(pDX, IDC_TOPMARGIN, m_TopMargin);
	DDX_Text(pDX, IDC_LEFTMARGIN, m_LeftMargin);
	DDX_Check(pDX, IDC_LOCKMARGINS, m_LockMargins);
	DDX_Check(pDX, IDC_CUT, m_AutoCut);
	DDX_Text(pDX, IDC_CUTHEIGHT, m_CutHeight);
	DDX_Text(pDX, IDC_CUTGAP, m_CutGap);
	DDX_Check(pDX, IDC_INFORM, m_Inform);
	DDX_Check(pDX, IDC_LOG, m_CreateLog);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAdvancedPage, CPropertyPage)
	//{{AFX_MSG_MAP(CAdvancedPage)
	ON_BN_CLICKED(IDC_MULTIPRINT, OnMultiPrint)
	ON_BN_CLICKED(IDC_DPI, OnDPI)
	ON_BN_CLICKED(IDC_LOCKDPI, OnLockDPI)
	ON_BN_CLICKED(IDC_MARGINS, OnMargins)
	ON_BN_CLICKED(IDC_LOCKMARGINS, OnLockMargins)
	ON_BN_CLICKED(IDC_CUT, OnCut)
	ON_EN_CHANGE(IDC_HORZDPI, OnChangeHorzDPI)
	ON_EN_CHANGE(IDC_TOPMARGIN, OnChangeTopMargin)
	ON_EN_CHANGE(IDC_CUTGAP, OnGenericChange)
	ON_EN_CHANGE(IDC_CUTHEIGHT, OnGenericChange)
	ON_EN_CHANGE(IDC_LEFTMARGIN, OnGenericChange)
	ON_BN_CLICKED(IDC_ROTATE, OnGenericChange)
	ON_EN_CHANGE(IDC_VERTDPI, OnGenericChange)
	ON_BN_CLICKED(IDC_INFORM, OnInform)
	ON_BN_CLICKED(IDC_LOG, OnLog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAdvancedPage message handlers

BOOL CAdvancedPage::OnInitDialog() 
{
	// load advanced parameters
	m_MultiPrint = AfxGetApp()->GetProfileInt(m_RegAdv,m_RegMultiPrint,FALSE);
	m_AutoRotate = AfxGetApp()->GetProfileInt(m_RegAdv,m_RegAutoRotate,FALSE);
	m_AutoDPI = AfxGetApp()->GetProfileInt(m_RegAdv,m_RegAutoDPI,FALSE);
	m_HorzDPI = AfxGetApp()->GetProfileInt(m_RegAdv,m_RegHorzDPI,0);
	m_VertDPI = AfxGetApp()->GetProfileInt(m_RegAdv,m_RegVertDPI,0);
	m_LockDPI = AfxGetApp()->GetProfileInt(m_RegAdv,m_RegLockDPI,0);
	m_AutoMargins = AfxGetApp()->GetProfileInt(m_RegAdv,m_RegAutoMargins,FALSE);
	m_TopMargin = AfxGetApp()->GetProfileInt(m_RegAdv,m_RegTopMargin,0);
	m_LeftMargin = AfxGetApp()->GetProfileInt(m_RegAdv,m_RegLeftMargin,0);
	m_LockMargins = AfxGetApp()->GetProfileInt(m_RegAdv,m_RegLockMargins,0);
	m_AutoCut = AfxGetApp()->GetProfileInt(m_RegAdv,m_RegAutoCut,FALSE);
	m_CutHeight = AfxGetApp()->GetProfileInt(m_RegAdv,m_RegCutHeight,0);
	m_CutGap = AfxGetApp()->GetProfileInt(m_RegAdv,m_RegCutGap,0);
	m_CreateLog = AfxGetApp()->GetProfileInt(m_RegAdv,m_RegCreateLog,0);
	m_Inform = AfxGetApp()->GetProfileInt(m_RegAdv,m_RegInform,0);

	CPropertyPage::OnInitDialog();

	// enable controls
	GetDlgItem(IDC_ROTATE)->EnableWindow(m_MultiPrint);
	OnDPI(); 
	OnLockDPI();
	OnMargins(); 
	OnLockMargins(); 
	OnCut(); 

	return TRUE;
}

void CAdvancedPage::OnMultiPrint() 
{
	BOOL Checked = (IsDlgButtonChecked(IDC_MULTIPRINT) == 1);
	GetDlgItem(IDC_ROTATE)->EnableWindow(Checked);
	
	if (Checked)
	{
		m_AutoRotate = TRUE;
		((CButton*)GetDlgItem(IDC_ROTATE))->SetCheck(1);
	}

	SetModified(TRUE);
}

void CAdvancedPage::OnDPI() 
{
	BOOL Enable = (IsDlgButtonChecked(IDC_DPI) != 1);
	GetDlgItem(IDC_HORZDPI)->EnableWindow(Enable);
	GetDlgItem(IDC_VERTDPI)->EnableWindow(Enable);
	GetDlgItem(IDC_STATIC_HORZDPI)->EnableWindow(Enable);
	GetDlgItem(IDC_STATIC_VERTDPI)->EnableWindow(Enable);
	GetDlgItem(IDC_STATIC_HORZDPIUNIT)->EnableWindow(Enable);
	GetDlgItem(IDC_STATIC_VERTDPIUNIT)->EnableWindow(Enable);
	GetDlgItem(IDC_LOCKDPI)->EnableWindow(Enable);

	if (Enable)
		OnLockDPI();

	SetModified(TRUE);
}

void CAdvancedPage::OnLockDPI() 
{
	if (IsDlgButtonChecked(IDC_DPI) == 1)
		return;

	BOOL Checked = (IsDlgButtonChecked(IDC_LOCKDPI) == 1);

	if (Checked)
	{
		CString Text;
		GetDlgItemText(IDC_HORZDPI,Text);
		SetDlgItemText(IDC_VERTDPI,Text);
	}

	GetDlgItem(IDC_VERTDPI)->EnableWindow(!Checked);
	GetDlgItem(IDC_STATIC_VERTDPI)->EnableWindow(!Checked);
	GetDlgItem(IDC_STATIC_VERTDPIUNIT)->EnableWindow(!Checked);

	SetModified(TRUE);
}

void CAdvancedPage::OnMargins() 
{
	BOOL Enable = (IsDlgButtonChecked(IDC_MARGINS) != 1);
	GetDlgItem(IDC_TOPMARGIN)->EnableWindow(Enable);
	GetDlgItem(IDC_LEFTMARGIN)->EnableWindow(Enable);
	GetDlgItem(IDC_STATIC_TOPMARGIN)->EnableWindow(Enable);
	GetDlgItem(IDC_STATIC_LEFTMARGIN)->EnableWindow(Enable);
	GetDlgItem(IDC_STATIC_TOPMARGINUNIT)->EnableWindow(Enable);
	GetDlgItem(IDC_STATIC_LEFTMARGINUNIT)->EnableWindow(Enable);
	GetDlgItem(IDC_LOCKMARGINS)->EnableWindow(Enable);

	if (Enable)
		OnLockMargins();

	SetModified(TRUE);
}

void CAdvancedPage::OnLockMargins() 
{
	if (IsDlgButtonChecked(IDC_MARGINS) == 1)
		return;

	BOOL Checked = (IsDlgButtonChecked(IDC_LOCKMARGINS) == 1);

	if (Checked)
	{
		CString Text;
		GetDlgItemText(IDC_TOPMARGIN,Text);
		SetDlgItemText(IDC_LEFTMARGIN,Text);
	}

	GetDlgItem(IDC_LEFTMARGIN)->EnableWindow(!Checked);
	GetDlgItem(IDC_STATIC_LEFTMARGIN)->EnableWindow(!Checked);
	GetDlgItem(IDC_STATIC_LEFTMARGINUNIT)->EnableWindow(!Checked);

	SetModified(TRUE);
}

void CAdvancedPage::OnCut() 
{
	BOOL Enable = (IsDlgButtonChecked(IDC_CUT) != 1);
	GetDlgItem(IDC_CUTHEIGHT)->EnableWindow(Enable);
	GetDlgItem(IDC_STATIC_CUTHEIGHT)->EnableWindow(Enable);
	GetDlgItem(IDC_STATIC_CUTHEIGHTUNIT)->EnableWindow(Enable);
	GetDlgItem(IDC_CUTGAP)->EnableWindow(!Enable);
	GetDlgItem(IDC_STATIC_CUTGAP)->EnableWindow(!Enable);
	GetDlgItem(IDC_STATIC_CUTGAPUNIT)->EnableWindow(!Enable);

	SetModified(TRUE);
}

void CAdvancedPage::OnChangeHorzDPI() 
{
	if (IsDlgButtonChecked(IDC_LOCKDPI) == 1)
	{
		CString Text;
		GetDlgItemText(IDC_HORZDPI,Text);
		SetDlgItemText(IDC_VERTDPI,Text);
	}

	SetModified(TRUE);
}

void CAdvancedPage::OnChangeTopMargin() 
{
	if (IsDlgButtonChecked(IDC_LOCKMARGINS) == 1)
	{
		CString Text;
		GetDlgItemText(IDC_TOPMARGIN,Text);
		SetDlgItemText(IDC_LEFTMARGIN,Text);
	}

	SetModified(TRUE);
}

void CAdvancedPage::OnGenericChange() 
{
	SetModified(TRUE);
}

void CAdvancedPage::OnInform() 
{
	SetModified(TRUE);
}

void CAdvancedPage::OnLog() 
{
	SetModified(TRUE);
}

BOOL CAdvancedPage::OnApply() 
{
	// retrieve data
	UpdateData(TRUE);

	if (m_LockMargins)
		m_LeftMargin = m_TopMargin;

	if (m_LockDPI)
		m_VertDPI = m_HorzDPI;

	// save advanced parameters
	AfxGetApp()->WriteProfileInt(m_RegAdv,m_RegMultiPrint,m_MultiPrint);
	AfxGetApp()->WriteProfileInt(m_RegAdv,m_RegAutoRotate,m_AutoRotate);
	AfxGetApp()->WriteProfileInt(m_RegAdv,m_RegAutoDPI,m_AutoDPI);
	AfxGetApp()->WriteProfileInt(m_RegAdv,m_RegHorzDPI,m_HorzDPI);
	AfxGetApp()->WriteProfileInt(m_RegAdv,m_RegVertDPI,m_VertDPI);
	AfxGetApp()->WriteProfileInt(m_RegAdv,m_RegLockDPI,m_LockDPI);
	AfxGetApp()->WriteProfileInt(m_RegAdv,m_RegAutoMargins,m_AutoMargins);
	AfxGetApp()->WriteProfileInt(m_RegAdv,m_RegTopMargin,m_TopMargin);
	AfxGetApp()->WriteProfileInt(m_RegAdv,m_RegLeftMargin,m_LeftMargin);
	AfxGetApp()->WriteProfileInt(m_RegAdv,m_RegLockMargins,m_LockMargins);
	AfxGetApp()->WriteProfileInt(m_RegAdv,m_RegAutoCut,m_AutoCut);
	AfxGetApp()->WriteProfileInt(m_RegAdv,m_RegCutHeight,m_CutHeight);
	AfxGetApp()->WriteProfileInt(m_RegAdv,m_RegCutGap,m_CutGap);
	AfxGetApp()->WriteProfileInt(m_RegAdv,m_RegCreateLog,m_CreateLog);
	AfxGetApp()->WriteProfileInt(m_RegAdv,m_RegInform,m_Inform);

	return CPropertyPage::OnApply();
}


