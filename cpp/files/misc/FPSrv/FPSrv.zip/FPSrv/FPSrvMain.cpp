// FPSrvMain.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "FPSrvMain.h"

#include "TiffReader.h"

#include "MainPage.h"
#include "DirsPage.h"
#include "DriverPage.h"
#include "AdvancedPage.h"
#include "AboutDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// notification message
#define ID_FPSRV_ICON					(UINT)1
#define WM_FPSRV_ICON_NOTIFICATION		(WM_USER + 1)
#define WM_FPSRV_MONITOR_NOTIFICATION	(WM_USER + 2)

// driver capabilities
#define MIN_CUT_HEIGHT		7000
#define MAX_CUT_HEIGHT		18400
#define MIN_HORZ_DPI		32
#define MAX_HORZ_DPI		600
#define MIN_VERT_DPI		10
#define MAX_VERT_DPI		1200
#define MIN_LEFT_MARGIN		-1000
#define MAX_LEFT_MARGIN		12000
#define MIN_TOP_MARGIN		-1000
#define MAX_TOP_MARGIN		18450


/////////////////////////////////////////////////////////////////////////////
// CFPSrvMain

// ==============================
// input directory monitor
// ==============================

DWORD WINAPI CFPSrvMain::WaitForDriverTermination(LPVOID pParam)
{
	CFPSrvMain* pFPSrv = (CFPSrvMain*)pParam;

	if (pFPSrv->m_DriverThreadID != NULL)
	{
		pFPSrv->LogString(_T("CFPSrvMain::WaitForDriverTermination waiting for driver thread termination...\n"));
		WaitForSingleObject(pFPSrv->m_DriverThreadID,INFINITE);
		pFPSrv->LogString(_T("CFPSrvMain::WaitForDriverTermination driver thread terminated...\n"));
	}
	else
		pFPSrv->LogString(_T("CFPSrvMain::WaitForDriverTermination driver thread not found...\n"));

	// close dump file
	Sleep(1000);
	CloseHandle(pFPSrv->m_DumpFile);
	Sleep(1000);
	
	CString Path;
	if (pFPSrv->IsDriverResponseOk())
	{
		pFPSrv->LogString(_T("CFPSrvMain::ProcessNextFile driver response is ok!...\n"));
		Path = pFPSrv->m_OutputFilePath;
	}
	else
	{
		pFPSrv->LogString(_T("CFPSrvMain::ProcessNextFile bad driver response detected...\n"));
		Path = pFPSrv->m_ErrorFilePath;
	}
	
	// move file to destination directory
	if (GetFileAttributes(Path) == (DWORD)-1)
	{
		// destination file does not exist
		pFPSrv->LogString(_T("CFPSrvMain::ProcessNextFile moving file to destination dir...\n"));
		MoveFile(pFPSrv->m_InputFilePath,Path);
	}
	else
	{
		// delete destination file for overwriting
		if (pFPSrv->m_Overwrite)
		{
			pFPSrv->LogString(_T("CFPSrvMain::ProcessNextFile overwriting output file...\n"));
			DeleteFile(pFPSrv->m_OutputFilePath);
			MoveFile(pFPSrv->m_InputFilePath,pFPSrv->m_OutputFilePath);
		}
		else
		{
			// try to use an alternate name
			CString Ext, Aux, AltPath;
			int DotPos = Path.ReverseFind(_T('.')); 

			if (DotPos != -1)
			{
				Ext = Path.Mid(DotPos + 1);
				Path = Path.Left(DotPos);
			}
			
			// append ad index at the end of the file name
			int Index = 1;
			BOOL FoundUniqueName = FALSE;
			
			while ((Index < 1000) && !FoundUniqueName)
			{
				Aux.Format(_T(" #%d"),Index);
				AltPath = Path + Aux;
				
				if (!Ext.IsEmpty())
					AltPath += _T('.') + Ext;
		
				FoundUniqueName = (GetFileAttributes(AltPath) == (DWORD)-1);
				Index++;
			}


			if (FoundUniqueName)
			{
				// destination file does not exist
				pFPSrv->LogString(_T("CFPSrvMain::ProcessNextFile moving file to destination dir...\n"));
				MoveFile(pFPSrv->m_InputFilePath,AltPath);
			}
			else
			{
				// remove file from input dir
				pFPSrv->LogString(_T("CFPSrvMain::ProcessNextFile deleting input file...\n"));
				DeleteFile(pFPSrv->m_InputFilePath);
			}
		}
	}

	// restore "waiting"/"idle" icon
	CString Tip;
	Tip.LoadString(IDS_ICONTIP);

	if (pFPSrv->m_Running)
		pFPSrv->ChangeIcon(pFPSrv->m_WaitIcon,Tip);
	else
		pFPSrv->ChangeIcon(pFPSrv->m_IdleIcon,Tip);

	// reset driver threads references
	pFPSrv->m_DriverThreadID = NULL;
	pFPSrv->m_DriverListenerThreadID = NULL;

	pFPSrv->PostMessage(WM_FPSRV_MONITOR_NOTIFICATION,0,0);
	return 0;
}


HANDLE CFPSrvMain::m_MonitorThreadID = NULL;	

DWORD WINAPI CFPSrvMain::MonitorThread(LPVOID pParam)
{
	// retrieve input parameters
	CFPSrvMain* pFPSrv = (CFPSrvMain*)pParam;
	pFPSrv->LogString(_T("CFPSrvMain::MonitorThread entering...\n"));

	HANDLE Stop = OpenEvent(EVENT_ALL_ACCESS,FALSE,pFPSrv->m_StopEventName);
	
	// check input parameters
	if ((GetFileAttributes(pFPSrv->m_InputDir) == (DWORD)-1)
		|| (Stop == NULL))
	{
		pFPSrv->LogString(_T("CFPSrvMain::MonitorThread bad input parameter, exiting...\n"));
		m_MonitorThreadID = NULL;
		return (DWORD)-1;
	}

	pFPSrv->LogString(_T("CFPSrvMain::MonitorThread input parameters ok...\n"));

	// main window and input directory exists!
	DWORD Events = FILE_NOTIFY_CHANGE_FILE_NAME;
	HANDLE Monitor = FindFirstChangeNotification(pFPSrv->m_InputDir,FALSE,Events);

	if (Monitor == INVALID_HANDLE_VALUE)
	{
		pFPSrv->LogString(_T("CFPSrvMain::MonitorThread notification object not gained, exiting...\n"));
		m_MonitorThreadID = NULL;
		return (DWORD)-1;
	}

	pFPSrv->LogString(_T("CFPSrvMain::MonitorThread gained notification object...\n"));

	// set up event structure
	HANDLE WaitOnEvent[2];
	WaitOnEvent[0] = Stop;
	WaitOnEvent[1] = Monitor;

	// start watching
	DWORD FiredEvent;
	BOOL Terminate = FALSE;
	pFPSrv->LogString(_T("CFPSrvMain::MonitorThread entering loop...\n"));

	while (!Terminate)
	{
		pFPSrv->LogString(_T("CFPSrvMain::MonitorThread waiting for notification...\n"));
		FiredEvent = WaitForMultipleObjects(2,WaitOnEvent,FALSE,INFINITE);

		if ((FiredEvent - WAIT_OBJECT_0) == 0)
		{
			Terminate = TRUE;
			pFPSrv->LogString(_T("CFPSrvMain::MonitorThread termination request received...\n"));
		}
		
		if ((FiredEvent - WAIT_OBJECT_0) == 1)
		{
			pFPSrv->LogString(_T("CFPSrvMain::MonitorThread notification received...\n"));
			pFPSrv->PostMessage(WM_FPSRV_MONITOR_NOTIFICATION,0,0);
			FindNextChangeNotification(Monitor);
		}
	}

	// free system resources
	CloseHandle(Stop);
	FindCloseChangeNotification(Monitor);

	// thread is dying...
	pFPSrv->LogString(_T("CFPSrvMain::MonitorThread exiting thread procedure...\n"));
	m_MonitorThreadID = NULL;
	return 0;
}



// ==============================
// construction/destruction
// ==============================

CFPSrvMain::CFPSrvMain(BOOL Inform /*= FALSE*/)
{
	m_ForceInform = Inform;
	m_PriorityFileFilter = _T("!*.");

	// retrieve installation directory
	TCHAR FileName[MAX_PATH];
	GetModuleFileName(NULL,FileName,MAX_PATH); 
	m_WorkingDir = FileName;

	// extract the file name
	int BackSlashPos = m_WorkingDir.ReverseFind(_T('\\')); 

	if (BackSlashPos != -1)
		m_WorkingDir = m_WorkingDir.Left(BackSlashPos + 1);

	// driver command file name
	m_CmdFileName = _T("FPSRV98.CMD");
	m_CmdFilePath = m_WorkingDir + m_CmdFileName;

	// driver stdout collector
	m_DumpFile = NULL;
	m_DumpFilePath = m_WorkingDir + _T("FAST8.LOG");

	// log file
	m_LogFilePath = m_WorkingDir + _T("FPSRV98.LOG");

	m_DriverThreadID = NULL;	
	m_DriverListenerThreadID = NULL;

	m_StopEventName = _T("KillInputDirectoryMonitorThread");

	// load the icons
	m_IdleIcon = AfxGetApp()->LoadIcon(IDI_IDLE);
	m_WaitIcon = AfxGetApp()->LoadIcon(IDI_WAIT);
	m_BusyIcon = AfxGetApp()->LoadIcon(IDI_BUSY);

	// load the menu
	m_ContextMenu.LoadMenu(IDR_FPSRV_MENU);

	// set the "properties" item as the default one
	CMenu* pMenu = m_ContextMenu.GetSubMenu(0);	
	SetMenuDefaultItem(pMenu->m_hMenu,ID_FPSRV_PROPERTIES,FALSE);

	m_Running = FALSE;
	m_IsServing = FALSE;
	m_IsConfigDlgOpened = FALSE;

	m_IsImage = FALSE;
	m_Copies = 0;
	m_ImageHorzDPI = 0;
	m_ImageVertDPI = 0;
	m_ImageHorzSize = 0;
	m_ImageVertSize = 0;
}

CFPSrvMain::~CFPSrvMain()
{
	// stop the thread
	StopMonitor();

	DestroyIcon(m_IdleIcon);
	DestroyIcon(m_WaitIcon);
	DestroyIcon(m_BusyIcon);
}


BEGIN_MESSAGE_MAP(CFPSrvMain, CWnd)
	//{{AFX_MSG_MAP(CFPSrvMain)
	ON_COMMAND(ID_FPSRV_MULTIPRINT, OnFPSrvMultiPrint)
	ON_COMMAND(ID_FPSRV_STARTSTOP, OnFPSrvStartStop)
	ON_COMMAND(ID_FPSRV_PROPERTIES, OnFPSrvProperties)
	ON_COMMAND(ID_FPSRV_CLOSE, OnFPSrvClose)
	ON_COMMAND(ID_FPSRV_ABOUT, OnFPSrvAbout)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP

	// user defined message map
	ON_MESSAGE(WM_FPSRV_ICON_NOTIFICATION,OnFPSrvIconMsg)
	ON_MESSAGE(WM_FPSRV_MONITOR_NOTIFICATION,OnFPSrvMonitorMsg)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CFPSrvMain message handlers

// ==============================
// window creation/destruction
// ==============================

BOOL CFPSrvMain::Create(CWnd* pParentWnd /*= NULL*/) 
{
	// create an invisible main window...
	CString WndName;
	WndName.LoadString(IDS_APP_NAME);
	CString ClassName(AfxRegisterWndClass(CS_DBLCLKS));

	// avoid multiple instances of the same server
	if (::FindWindow(ClassName,WndName) != NULL)
	{
		AfxMessageBox(IDS_ALREADYRUNNING,MB_ICONINFORMATION);
		return FALSE;
	}

	if (CWnd::CreateEx(0,ClassName,WndName,WS_OVERLAPPEDWINDOW,CRect(0,0,10,10),pParentWnd,IDR_MAINFRAME))
	{
		// add the icon to the notification area
		NOTIFYICONDATA nid;
		nid.cbSize = sizeof(NOTIFYICONDATA);
		nid.hWnd = m_hWnd;
		nid.uID = ID_FPSRV_ICON;
		nid.uFlags = NIF_TIP | NIF_ICON | NIF_MESSAGE;
		nid.uCallbackMessage = WM_FPSRV_ICON_NOTIFICATION;
		nid.hIcon = m_IdleIcon;
		LoadString(NULL,IDS_ICONTIP,nid.szTip,64);
		Shell_NotifyIcon(NIM_ADD,&nid);

		// load config data
		LoadFormats();
		LoadDriverProperties();
		LoadAdvancedParameters();

		// load directories names
		if (LoadDirs())
		{
			if (!StartMonitor())
				AfxMessageBox(IDS_MONITORNOTSTARTED,MB_ICONSTOP);
		}
		else
			// open configuration window
			OnFPSrvProperties();

		return TRUE;
	}
	else
		return FALSE;
}



// ==============================
// logging function
// ==============================

void CFPSrvMain::LogString(LPCTSTR Line)
{
	OutputDebugString(Line);

	if (m_CreateLog)
	{
		CStdioFile LogFile;
		if (LogFile.Open(m_LogFilePath,CFile::modeWrite)
			|| LogFile.Open(m_LogFilePath,CFile::modeCreate | CFile::modeWrite))
		{
			LogFile.SeekToEnd();
			LogFile.WriteString(Line);
			LogFile.Close();
		}
	}
}



// ==============================
// icon switching
// ==============================

void CFPSrvMain::ChangeIcon(HICON Icon, LPCTSTR ToolTip /*= NULL*/)
{
	if ((Icon != m_IdleIcon)
		&& (Icon != m_WaitIcon)
		&& (Icon != m_BusyIcon))
		return;
	
	// change icon
	NOTIFYICONDATA nid;
	nid.cbSize = sizeof(NOTIFYICONDATA);
	nid.hWnd = m_hWnd;
	nid.uID = ID_FPSRV_ICON;
	nid.uFlags = NIF_ICON;
	nid.hIcon = Icon;

	if (ToolTip != NULL)
	{
		CString StrToolTip(ToolTip);
		if (StrToolTip.GetLength() > 63)
		{
			StrToolTip = StrToolTip.Left(60);
			StrToolTip += _T("...");
		}

		nid.uFlags |= NIF_TIP;
		_tcscpy(nid.szTip,StrToolTip);
	}

	Shell_NotifyIcon(NIM_MODIFY,&nid);
}



// ==============================
// registry configuration readers
// ==============================

BOOL CFPSrvMain::LoadDirs()
{
	// load registry configuration
	CString RegDir,RegInputDir,RegOutputDir,RegErrorDir,RegOverwrite;

	RegDir.LoadString(IDS_REG_DIRS);
	RegInputDir.LoadString(IDS_REG_DIRINPUT);
	RegOutputDir.LoadString(IDS_REG_DIROUTPUT);
	RegErrorDir.LoadString(IDS_REG_DIRERROR);
	RegOverwrite.LoadString(IDS_REG_DIROVERWRITE);

	m_InputDir = AfxGetApp()->GetProfileString(RegDir,RegInputDir);
	m_OutputDir = AfxGetApp()->GetProfileString(RegDir,RegOutputDir);
	m_ErrorDir = AfxGetApp()->GetProfileString(RegDir,RegErrorDir);
	m_Overwrite = AfxGetApp()->GetProfileInt(RegDir,RegOverwrite,FALSE);

	// found direcory names? 
	if (m_InputDir.IsEmpty() || m_OutputDir.IsEmpty() || m_ErrorDir.IsEmpty())
	{
		AfxMessageBox(IDS_MISSINGDIRNAMES,MB_ICONSTOP);
		return FALSE;
	}

	// does the input directory exist?
	if (GetFileAttributes(m_InputDir) == (DWORD)-1)
	{
		AfxMessageBox(IDS_INVALIDINPUTDIR,MB_ICONSTOP);
		return FALSE;
	}
		
	// does the output directory exist?
	if (GetFileAttributes(m_OutputDir) == (DWORD)-1)
	{
		AfxMessageBox(IDS_INVALIDOUTPUTDIR,MB_ICONSTOP);
		return FALSE;
	}

	// does the error directory exist?
	if (GetFileAttributes(m_ErrorDir) == (DWORD)-1)
	{
		AfxMessageBox(IDS_INVALIDERRORDIR,MB_ICONSTOP);
		return FALSE;
	}

	return TRUE;
}

BOOL CFPSrvMain::LoadFormats()
{
	// load registry configuration
	CString RegFormat,RegBMP,RegJPG,RegTGA,RegTIF;

	RegFormat.LoadString(IDS_REG_FORMATS);
	RegBMP.LoadString(IDS_REG_BMPFORMAT);
	RegJPG.LoadString(IDS_REG_JPGFORMAT);
	RegTGA.LoadString(IDS_REG_TGAFORMAT);
	RegTIF.LoadString(IDS_REG_TIFFORMAT);

	// load enabled formats
	m_UseBMP = AfxGetApp()->GetProfileInt(RegFormat,RegBMP,FALSE);
	m_UseJPG = AfxGetApp()->GetProfileInt(RegFormat,RegJPG,FALSE);
	m_UseTGA = AfxGetApp()->GetProfileInt(RegFormat,RegTGA,FALSE);
	m_UseTIF = AfxGetApp()->GetProfileInt(RegFormat,RegTIF,TRUE);

	return TRUE;
}

BOOL CFPSrvMain::LoadDriverProperties()
{
	// load registry configuration
	CString	RegDriver,RegDriverPath,RegDriverOptions,
			RegDriverOpenPrompt,RegDriverPriority;

	RegDriver.LoadString(IDS_REG_DRIVER);
	RegDriverPath.LoadString(IDS_REG_DRIVERPATH);
	RegDriverOptions.LoadString(IDS_REG_DRIVEROPTIONS);
	RegDriverOpenPrompt.LoadString(IDS_REG_DRIVEROPENPROMPT);
	RegDriverPriority.LoadString(IDS_REG_DRIVERPRIORITY);

	m_DriverPath = AfxGetApp()->GetProfileString(RegDriver,RegDriverPath);
	m_DriverOptions = AfxGetApp()->GetProfileString(RegDriver,RegDriverOptions);
	m_OpenPrompt = AfxGetApp()->GetProfileInt(RegDriver,RegDriverOpenPrompt,FALSE);
	m_Priority = AfxGetApp()->GetProfileInt(RegDriver,RegDriverPriority,0);

	return TRUE;
}

BOOL CFPSrvMain::LoadAdvancedParameters()
{
	// load registry configuration
	CString RegAdv,RegAutoRotate,RegMultiPrint,
			RegAutoDPI,RegHorzDPI,RegVertDPI,RegLockDPI,
			RegAutoMargins,RegTopMargin,RegLeftMargin,RegLockMargins,
			RegAutoCut,RegCutHeight,RegCutGap,RegCreateLog,RegInform;

	RegAdv.LoadString(IDS_REG_ADVANCED);
	RegMultiPrint.LoadString(IDS_REG_MULTIPRINTADV);
	RegAutoRotate.LoadString(IDS_REG_AUTOROTATEADV);
	RegAutoDPI.LoadString(IDS_REG_AUTODPIADV);
	RegHorzDPI.LoadString(IDS_REG_HORZDPIADV);
	RegVertDPI.LoadString(IDS_REG_VERTDPIADV);
	RegLockDPI.LoadString(IDS_REG_LOCKDPIADV);
	RegAutoMargins.LoadString(IDS_REG_AUTOMARGINSADV);
	RegTopMargin.LoadString(IDS_REG_TOPMARGINADV);
	RegLeftMargin.LoadString(IDS_REG_LEFTMARGINADV);
	RegLockMargins.LoadString(IDS_REG_LOCKMARGINSADV);
	RegAutoCut.LoadString(IDS_REG_AUTOCUTADV);
	RegCutHeight.LoadString(IDS_REG_CUTHEIGHTADV);
	RegCutGap.LoadString(IDS_REG_CUTGAPADV);
	RegCreateLog.LoadString(IDS_REG_CREATELOGADV);
	RegInform.LoadString(IDS_REG_INFORMADV);

	m_MultiPrint = AfxGetApp()->GetProfileInt(RegAdv,RegMultiPrint,FALSE);
	m_AutoRotate = AfxGetApp()->GetProfileInt(RegAdv,RegAutoRotate,FALSE);
	m_AutoDPI = AfxGetApp()->GetProfileInt(RegAdv,RegAutoDPI,FALSE);
	m_HorzDPI = AfxGetApp()->GetProfileInt(RegAdv,RegHorzDPI,0);
	m_VertDPI = AfxGetApp()->GetProfileInt(RegAdv,RegVertDPI,0);
	m_LockDPI = AfxGetApp()->GetProfileInt(RegAdv,RegLockDPI,0);
	m_AutoMargins = AfxGetApp()->GetProfileInt(RegAdv,RegAutoMargins,FALSE);
	m_TopMargin = AfxGetApp()->GetProfileInt(RegAdv,RegTopMargin,0);
	m_LeftMargin = AfxGetApp()->GetProfileInt(RegAdv,RegLeftMargin,0);
	m_LockMargins = AfxGetApp()->GetProfileInt(RegAdv,RegLockMargins,0);
	m_AutoCut = AfxGetApp()->GetProfileInt(RegAdv,RegAutoCut,FALSE);
	m_CutHeight = AfxGetApp()->GetProfileInt(RegAdv,RegCutHeight,0);
	m_CutGap = AfxGetApp()->GetProfileInt(RegAdv,RegCutGap,0);
	m_CreateLog = AfxGetApp()->GetProfileInt(RegAdv,RegCreateLog,0);
	m_Inform = AfxGetApp()->GetProfileInt(RegAdv,RegInform,0);

	return TRUE;
}



// ==============================
// monitor start/stop
// ==============================

BOOL CFPSrvMain::StartMonitor(BOOL KillPrevious /*= TRUE*/)
{
	// already running?
	if (m_MonitorThreadID != NULL)
	{	
		if (KillPrevious)
			StopMonitor();
		else
			return FALSE;
	}

	// create the "kill monitor thread" event
	if (m_Stop != NULL)
		CloseHandle(m_Stop);

	m_Stop = CreateEvent(NULL,FALSE,FALSE,m_StopEventName);

	if (m_Stop == NULL)
		return FALSE;

	// start the monitor thread
	DWORD ThreadID;
	LogString(_T("CFPSrvMain::StartMonitor creating thread...\n"));
	m_MonitorThreadID = CreateThread(NULL,0,CFPSrvMain::MonitorThread,this,0,&ThreadID);

	m_Running = (m_MonitorThreadID != NULL);
	m_Running ? ChangeIcon(m_WaitIcon) : ChangeIcon(m_IdleIcon);

	// check the input directory immediately
	if (m_Running)
		PostMessage(WM_FPSRV_MONITOR_NOTIFICATION);

	return m_Running;
}

BOOL CFPSrvMain::StopMonitor()
{
	m_Running = FALSE;
	ChangeIcon(m_IdleIcon);

	if (m_MonitorThreadID == NULL)
		// nothing to stop
		return TRUE;

	// request thread stop 
	if (m_Stop != NULL)
	{
		LogString(_T("CFPSrvMain::StopMonitor firing stop event...\n"));
		SetEvent(m_Stop);

		// wait until thread termination
		LogString(_T("CFPSrvMain::StopMonitor waiting for thread termination...\n"));
		while (m_MonitorThreadID != NULL)
			;

		LogString(_T("CFPSrvMain::StopMonitor thread terminated...\n"));

		// free event
		CloseHandle(m_Stop);
		m_Stop = NULL;
	}

	return TRUE;
}



// ==============================
// monitor notifications
// ==============================

LONG CFPSrvMain::OnFPSrvMonitorMsg(UINT wParam, LONG lParam)
{
	// any interesting file?
	CString Ext;
	BOOL FileFound = FALSE;

	if (m_UseBMP)
	{
		Ext.LoadString(IDS_REG_BMPFORMAT);
		FileFound = ProcessNextFile(Ext);
	}
	
	if (!FileFound && m_UseJPG)
	{
		Ext.LoadString(IDS_REG_JPGFORMAT);
		FileFound = ProcessNextFile(Ext);
	}
	
	if (!FileFound && m_UseTGA)
	{
		Ext.LoadString(IDS_REG_TGAFORMAT);
		FileFound = ProcessNextFile(Ext);
	}
	
	if (!FileFound && m_UseTIF)
	{
		Ext.LoadString(IDS_REG_TIFFORMAT);
		FileFound = ProcessNextFile(Ext);
	}

	return 0;
}



// ==============================
// file processing
// ==============================

BOOL CFPSrvMain::CreateCmdLine(LPTSTR CmdLine)
{
	// examine the tiff file
	CTiffReader Tiff(m_InputFilePath);
	
	if (!Tiff.IsTiff())
	{
		LogString(_T("CFPSrvMain::CreateCmdLine unrecognized tiff file format...\n"));
		return FALSE;
	}

	// retrieve tiff properties
	m_ImageHorzDPI = Tiff.GetHorzDPI();
	m_ImageVertDPI = Tiff.GetVertDPI();
	m_ImageHorzSize = Tiff.GetInchesWidth();
	m_ImageVertSize = Tiff.GetInchesHeight();

	// prepare the command line
	CString TmpCmdLine;
	TCHAR Buffer[MAX_PATH];

	TmpCmdLine.Format(_T("%s %s "),m_DriverPath,m_DriverOptions);

	// multi copy
	m_Copies = 1;

	if (m_MultiPrint)
	{
		// how many copies of this file?
		int AtPos = m_InputFileName.ReverseFind(_T('@'));

		if (AtPos > -1)
		{
			CString StrCopies;
			int DotPos = m_InputFileName.ReverseFind(_T('.'));

			if (DotPos == -1)
				StrCopies = m_InputFileName.Mid(AtPos + 1);
			else
				if (DotPos > AtPos)
					StrCopies = m_InputFileName.Mid(AtPos + 1,DotPos - AtPos - 1);

			// must be made of digits...
			BOOL MadeOfDigits = TRUE;
			for (int i = 0; i < StrCopies.GetLength(); i++)
				MadeOfDigits = MadeOfDigits && _istdigit(StrCopies[i]);

			if (!MadeOfDigits || (m_Copies = _ttol(StrCopies)) == 0)
				m_Copies = 1;
		}
			
		CString MultiCopy;
		MultiCopy.Format(_T("-m %d "),m_Copies);
		TmpCmdLine += MultiCopy;
	}
	
	// rotate the image?
	BOOL Rotate = FALSE;
	BOOL ShouldRotate = ((m_ImageHorzSize < m_ImageVertSize) && (Tiff.GetMmHeight() <= 305.));
	ShouldRotate |= ((Tiff.GetMmHeight() < 307.) && (Tiff.GetMmWidth() > 307.));

	if (m_MultiPrint && m_AutoRotate && ShouldRotate)
	{
		Rotate = TRUE;
		TmpCmdLine += _T("-rt ");
	}
	
	// create the command file name
	// @pf -l0 -t0 -h300 -v300 -L13073;<CR>
	
	CStdioFile CmdFile;
	if (!CmdFile.Open(m_CmdFilePath,CFile::modeWrite | CFile::modeCreate))
		return FALSE;

	CString Aux;
	CString CmdFileText(_T("@pf "));

	// using margins?
	double Top = 0;
	double Left = 0;

	if (!m_AutoMargins)
	{
		// convert to .001 inches
		Top = m_TopMargin * 39.37;
		Left = m_LeftMargin * 39.37;
	}
	
	// verify margins boundaries
	Top = __min(Top,MAX_TOP_MARGIN);
	Top = __max(Top,MIN_TOP_MARGIN);
	Left = __min(Left,MAX_LEFT_MARGIN);
	Left = __max(Left,MIN_LEFT_MARGIN);
	Aux.Format("-l%d -t%d ",(int)(Left + 0.5),(int)(Top + 0.5));
	CmdFileText += Aux;

	// set dpi
	short HorzDPI = (m_AutoDPI) ? m_ImageHorzDPI : m_HorzDPI;
	short VertDPI = (m_AutoDPI) ? m_ImageVertDPI : m_VertDPI;
	Aux.Format("-h%d -v%d ",(int)HorzDPI,(int)VertDPI);
	CmdFileText += Aux;

	// paper cut 
	double CutHeight = 0;
	double CutGap = 0;

	if (m_AutoCut)
	{
		// calculate cut height
		CutHeight = (Rotate) ? m_ImageHorzSize : m_ImageVertSize;
		
		// to .001 inches, plus the tolerance
		CutHeight = CutHeight*1000 + (m_CutGap * 39.37);
	}
	else
		CutHeight = m_CutHeight * 39.37;

	// verify cut height boundaries
	CutHeight = __min(CutHeight,MAX_CUT_HEIGHT);
	CutHeight = __max(CutHeight,MIN_CUT_HEIGHT);
	Aux.Format("-L%d;\n",(int)(CutHeight + 0.5));
	CmdFileText += Aux;

	CmdFile.WriteString(CmdFileText);
	CmdFile.Close();

	// convert command file path to 8.3 format
	GetShortPathName(m_CmdFilePath,Buffer,MAX_PATH);
	TmpCmdLine += _T("-c ");
	TmpCmdLine += Buffer;
	TmpCmdLine += _T(' ');

	// convert input file path to 8.3 format
	GetShortPathName(m_InputFilePath,Buffer,MAX_PATH);
	TmpCmdLine += Buffer;

	// transfer string
	_tcscpy(CmdLine,TmpCmdLine);

	if (m_Inform || m_ForceInform)
	{
		// prompt user for printing data
		CString Msg;
		Aux.Format(_T("image file: %s\n"),m_InputFilePath);
		Msg += Aux;
		Aux.Format(_T("image size is %dx%d pixels, %dx%d mm, %dx%d dpi\n"),
					(long)(Tiff.GetWidth() + 0.5),(long)(Tiff.GetHeight() + 0.5),
					(long)(Tiff.GetMmWidth() + 0.5),(long)(Tiff.GetMmHeight() + 0.5),
					HorzDPI,VertDPI);
		Msg += Aux;

		if (m_MultiPrint)
		{
			Aux.Format(_T("%d copies requested.\n"),m_Copies);
			Msg += Aux;
		}

		if (Rotate)
			Msg += _T("image will be rotated.\n");

		if (!m_AutoMargins)
		{
			Aux.Format(_T("image will be moved at (%d,%d) mm\n"),
						(int)(Left * 0.0254 + 0.5),(int)(Top * 0.0254 + 0.5));
			Msg += Aux;
		}

		if (m_CutHeight > 0)
		{
			Aux.Format(_T("image will be cut at %d mm\n"),
						(int)(CutHeight * 0.0254 + 0.5));
			Msg += Aux;
		}

//		SetForegroundWindow();
//		AfxMessageBox(Msg,MB_ICONINFORMATION);
		CString Caption;
		Caption.LoadString(IDS_APP_NAME);
		::MessageBox(NULL,Msg,Caption,MB_ICONINFORMATION);
	}

	return TRUE;
}

BOOL CFPSrvMain::ProcessNextFile(LPCTSTR FileExt /*= _T("*")*/)
{
	// server awaked?
	if (!m_Running)
		return FALSE;

	// server waiting on a notification?
	if (m_IsServing)
		return FALSE;

	// driver already running?
	if (m_DriverThreadID != NULL)
		return FALSE;

	if (m_DriverListenerThreadID != NULL)
		return FALSE;

	CString Path(m_InputDir);

	if (Path.IsEmpty())
		return FALSE;

	m_IsServing = TRUE;

	// complete the path
	if (Path.GetAt(Path.GetLength() - 1) != _T('\\'))
		Path += _T('\\');

	CString WatchingDir = Path;
	Path += m_PriorityFileFilter;
	Path += FileExt;
	WIN32_FIND_DATA Found;

	// search for high priority files (!*.tif)
	if (FindFirstFile(Path,&Found) == INVALID_HANDLE_VALUE)
	{
		Path = WatchingDir + _T("*.") + FileExt;

		// search for other files
		if (FindFirstFile(Path,&Found) == INVALID_HANDLE_VALUE)
		{
			LogString(_T("CFPSrvMain::ProcessNextFile no file found...\n"));
			m_IsServing = FALSE;
			return FALSE;
		}
	}

	// create input/output paths for this file
	m_InputFileName = Found.cFileName;
	m_InputFilePath = m_InputDir;
	m_OutputFilePath = m_OutputDir;
	m_ErrorFilePath = m_ErrorDir;

	if (m_InputFilePath.GetAt(m_InputFilePath.GetLength() - 1) != _T('\\'))
		m_InputFilePath += _T('\\');

	if (!m_OutputFilePath.IsEmpty() && m_OutputFilePath.GetAt(m_OutputFilePath.GetLength() - 1) != _T('\\'))
		m_OutputFilePath += _T('\\');

	if (!m_ErrorFilePath.IsEmpty() && m_ErrorFilePath.GetAt(m_ErrorFilePath.GetLength() - 1) != _T('\\'))
		m_ErrorFilePath += _T('\\');

	m_InputFilePath += m_InputFileName;
	m_OutputFilePath += m_InputFileName;
	m_ErrorFilePath += m_InputFileName;
	
	// is file ready for processing?
	CFile FileReady;

	if (!FileReady.Open(m_InputFilePath,CFile::modeWrite | CFile::shareExclusive))
	{
		LogString(_T("CFPSrvMain::ProcessNextFile input file not ready yet...\n"));

		// try again later...
		Sleep(500);
		PostMessage(WM_FPSRV_MONITOR_NOTIFICATION,0,0);
		m_IsServing = FALSE;
		return FALSE;
	}
	else
		FileReady.Close();

	// open the file for dumping dirver output
	m_DumpFile = CreateFile(m_DumpFilePath,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);

	if (m_DumpFile == INVALID_HANDLE_VALUE)
	{
		LogString(_T("CFPSrvMain::ProcessNextFile cannot create dump file, will try later...\n"));

		// try again later...
		Sleep(500);
		PostMessage(WM_FPSRV_MONITOR_NOTIFICATION,0,0);
		m_IsServing = FALSE;
		return FALSE;
	}

	// process the file
	CString DbgString;
	DbgString.Format(_T("CFPSrvMain::ProcessNextFile processing <%s>...\n"),m_InputFileName);
	LogString(DbgString);

	STARTUPINFO sui;
	PROCESS_INFORMATION pi;

	ZeroMemory(&sui,sizeof(STARTUPINFO));
	sui.cb = sizeof(STARTUPINFO);
	sui.dwFlags = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
	sui.wShowWindow = m_OpenPrompt ? SW_SHOW : SW_HIDE;
	sui.hStdInput = NULL;
	sui.hStdOutput = m_DumpFile;
	sui.hStdError = m_DumpFile;

	// set the driver parameters
	TCHAR pCmdLine[MAX_PATH];
	if (!CreateCmdLine(pCmdLine))
	{
		CloseHandle(m_DumpFile);
		m_IsServing = FALSE;
		return FALSE;
	}
	
	// change to "busy" icon
	CString Tip, Copies;
	Tip.LoadString(IDS_ICONTIP);
	Tip += _T(" - ") + m_InputFileName;

	if (m_MultiPrint)
	{
		Copies.Format(_T(" [%d]"),m_Copies);
		Tip += Copies;
	}
	
	ChangeIcon(m_BusyIcon,Tip);

	// set process priority
	DWORD Priority = NORMAL_PRIORITY_CLASS;

	switch (m_Priority)
	{
		case 0 : Priority = IDLE_PRIORITY_CLASS; break;
		case 1 : Priority = NORMAL_PRIORITY_CLASS; break;
		case 2 : Priority = HIGH_PRIORITY_CLASS; break;
		case 3 : Priority = REALTIME_PRIORITY_CLASS; break;
	}

	// start the driver
	if (CreateProcess(NULL,pCmdLine,NULL,NULL,TRUE,Priority,NULL,NULL,&sui,&pi))
	{
		LogString(_T("CFPSrvMain::ProcessNextFile creating driver termination monitor thread...\n"));
		m_DriverThreadID = pi.hThread;

		// all closing and re-synch operations will be
		// carried out by the new thread: dump file closing,
		// waiting icon restoring
		DWORD ThreadID;
		m_DriverListenerThreadID = CreateThread(NULL,0,CFPSrvMain::WaitForDriverTermination,this,0,&ThreadID);
	}
	else
	{
		// close dump file
		CloseHandle(m_DumpFile);

		// restore "waiting" icon
		CString Tip;
		Tip.LoadString(IDS_ICONTIP);
		ChangeIcon(m_WaitIcon,Tip);
	}
	
	m_IsServing = FALSE;
	return TRUE;	
}

BOOL CFPSrvMain::IsDriverResponseOk()
{
	// open the dump file
	CFile DumpFile;

	if (!DumpFile.Open(m_DumpFilePath,CFile::modeRead))
	{
		LogString(_T("CFPSrvMain::IsDriverResponseOk cannot open dump file...\n"));
		return FALSE;
	}

	// load the dump file
	DWORD DumpFileLen = DumpFile.GetLength();
	char* pBuffer = new char[DumpFileLen + 1];

	if ((pBuffer == NULL)	
		|| (DumpFile.Read(pBuffer,DumpFileLen) != DumpFileLen))
	{
		LogString(_T("CFPSrvMain::IsDriverResponseOk cannot read dump file...\n"));
		DumpFile.Close();
		return FALSE;
	}
	
	pBuffer[DumpFileLen] = 0x00;

	// search for the "fast8" string;
	// when found, some error occoured...
	BOOL Error = (strstr(pBuffer,"fast8") != NULL)
					|| (strstr(pBuffer,"error") != NULL)
					|| (strstr(pBuffer,"giving up") != NULL);

	// free resources
	DumpFile.Close();
	delete [] pBuffer;

	if (Error)
		LogString(_T("CFPSrvMain::IsDriverResponseOk found one of \"fast8\", \"error\", \"giving up\"...\n"));

	return !Error;
}



// ==============================
// icon notifications 
// ==============================

LONG CFPSrvMain::OnFPSrvIconMsg(UINT wParam, LONG lParam)
{
	if (wParam == ID_FPSRV_ICON)
	{
		// this is a notification from our icon
		switch (lParam)
		{
			case WM_LBUTTONDBLCLK :
				// fire the default context menu item procedure
				OnFPSrvProperties();
				break;

			case WM_RBUTTONUP :
			{	
				// retrieve mouse position
				POINT Pos;
				GetCursorPos(&Pos);

				// load the context menu
				SetForegroundWindow();
				CMenu* pMenu = m_ContextMenu.GetSubMenu(0);	

				// set start/stop text
				CString StartStop;
				if (m_Running)
					StartStop.LoadString(IDS_FPSRV_STOP);
				else
					StartStop.LoadString(IDS_FPSRV_START);

				pMenu->ModifyMenu(ID_FPSRV_STARTSTOP,MF_BYCOMMAND | MF_STRING,ID_FPSRV_STARTSTOP,StartStop);

				// check multiprint option
				if (m_MultiPrint)
					pMenu->CheckMenuItem(ID_FPSRV_MULTIPRINT,MF_CHECKED);
				else
					pMenu->CheckMenuItem(ID_FPSRV_MULTIPRINT,MF_UNCHECKED);

				// when driver is running, enable only start/stop and close options
				if (m_DriverThreadID != NULL)
				{
					pMenu->EnableMenuItem(ID_FPSRV_PROPERTIES,MF_GRAYED);
					pMenu->EnableMenuItem(ID_FPSRV_MULTIPRINT,MF_GRAYED);
				}
				else
				{
					pMenu->EnableMenuItem(ID_FPSRV_PROPERTIES,MF_ENABLED);
					pMenu->EnableMenuItem(ID_FPSRV_MULTIPRINT,MF_ENABLED);
				}

				// show context menu
				pMenu->TrackPopupMenu(TPM_LEFTALIGN,Pos.x,Pos.y,this);
				SetForegroundWindow();
				break;
			}
		}
	}

	return 0;
}



// ==============================
// context menu management
// ==============================

void CFPSrvMain::OnFPSrvMultiPrint()
{
	m_MultiPrint = !m_MultiPrint;
	
	if (m_MultiPrint)
		m_AutoRotate = TRUE;

	// save setting on registry
	CString RegAdv,RegMultiPrint,RegAutoRotate;
	RegAdv.LoadString(IDS_REG_ADVANCED);
	RegMultiPrint.LoadString(IDS_REG_MULTIPRINTADV);
	RegAutoRotate.LoadString(IDS_REG_AUTOROTATEADV);
	AfxGetApp()->WriteProfileInt(RegAdv,RegMultiPrint,m_MultiPrint);
	AfxGetApp()->WriteProfileInt(RegAdv,RegAutoRotate,m_AutoRotate);
}


void CFPSrvMain::OnFPSrvStartStop()
{
	m_Running ? StopMonitor() : StartMonitor();
}

void CFPSrvMain::OnFPSrvProperties() 
{
	if ((m_DriverThreadID != NULL) || (m_IsConfigDlgOpened)) 
		return;

	// load the configuration tabs
	CPropertySheet ConfigDlg(IDS_CONFIGDLGTITLE,this);

	CMainPage MainPage;
	ConfigDlg.AddPage(&MainPage);

	CDirsPage DirsPage;
	ConfigDlg.AddPage(&DirsPage);

	CDriverPage DriverPage;
	ConfigDlg.AddPage(&DriverPage);

	CAdvancedPage AdvancedPage;
	ConfigDlg.AddPage(&AdvancedPage);

	// open configuration dialog
	m_IsConfigDlgOpened = TRUE;
	
	if (ConfigDlg.DoModal() == IDOK)
	{
		// reload config data
		LoadFormats();
		LoadDriverProperties();
		LoadAdvancedParameters();

		// update directory names
		if (LoadDirs())
		{
			// restart the monitor
			StartMonitor();
		}
	}

	m_IsConfigDlgOpened = FALSE;
}

void CFPSrvMain::OnFPSrvClose() 
{
	if (AfxMessageBox(IDS_CONFIRM_CLOSE,MB_ICONEXCLAMATION | MB_YESNO) == IDYES)
	{
		// stop the thread
		StopMonitor();

		// remove the icon from the notification area
		NOTIFYICONDATA nid;
		nid.cbSize = sizeof(NOTIFYICONDATA);
		nid.hWnd = m_hWnd;
		nid.uID = ID_FPSRV_ICON;
		nid.uFlags = 0;
		Shell_NotifyIcon(NIM_DELETE,&nid);

		// shut down the server
		PostQuitMessage(0);
	}
}

void CFPSrvMain::OnFPSrvAbout() 
{
	CAboutDialog dlg;
	dlg.DoModal();
}