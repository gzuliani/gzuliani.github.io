#if !defined(AFX_DRIVERPAGE_H__3054AB86_71AA_11D2_9DF6_444553540000__INCLUDED_)
#define AFX_DRIVERPAGE_H__3054AB86_71AA_11D2_9DF6_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DriverPage.h : header file
//

#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CDriverPage dialog

class CDriverPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CDriverPage)

// Construction
public:
	CDriverPage();
	~CDriverPage();

protected:
// Dialog Data
	//{{AFX_DATA(CDriverPage)
	enum { IDD = IDD_FPSRV_DRIVER };
	CString	m_Path;
	CString	m_Options;
	BOOL	m_OpenPrompt;
	CSliderCtrl	m_PriorityCtrl;
	//}}AFX_DATA

	// registry keys
	CString	m_RegDriver;
	CString	m_RegDriverPath;
	CString	m_RegDriverOptions;
	CString	m_RegDriverOpenPrompt;
	CString	m_RegDriverPriority;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CDriverPage)
	public:
	virtual BOOL OnApply();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CDriverPage)
	afx_msg void OnBrowse();
	virtual BOOL OnInitDialog();
	afx_msg void OnGenericChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DRIVERPAGE_H__3054AB86_71AA_11D2_9DF6_444553540000__INCLUDED_)
