// TrickDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TrickDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTrickDlg dialog


CTrickDlg::CTrickDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTrickDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTrickDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTrickDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTrickDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTrickDlg, CDialog)
	//{{AFX_MSG_MAP(CTrickDlg)
	ON_BN_CLICKED(IDC_PUAH, OnPuah)
	ON_BN_CLICKED(IDC_NOTBAD, OnNotBad)
	ON_BN_CLICKED(IDC_MASTERPIECE, OnMasterPiece)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTrickDlg message handlers

BOOL CTrickDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	return FALSE;
}

void CTrickDlg::OnPuah() 
{
	OnCancel();
}

void CTrickDlg::OnNotBad() 
{
	OnCancel();
}

void CTrickDlg::OnOK() 
{
	CDialog::OnOK();
}

void CTrickDlg::OnMasterPiece() 
{
	OnCancel();
}

