#if !defined(AFX_FPSRVMAIN_H__7F0794AF_7055_11D2_9DF6_444553540000__INCLUDED_)
#define AFX_FPSRVMAIN_H__7F0794AF_7055_11D2_9DF6_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// FPSrvMain.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFPSrvMain window

class CFPSrvMain : public CWnd
{
	// driver thread properties
	static DWORD WINAPI	WaitForDriverTermination(LPVOID pParam);

	// input directory monitor properties
	static HANDLE m_MonitorThreadID;	
	static DWORD WINAPI	MonitorThread(LPVOID pParam);

// construction/destruction
public:
	CFPSrvMain(BOOL Inform = FALSE);
	virtual ~CFPSrvMain();

	// window creation
	BOOL Create(CWnd* pParentWnd = NULL);

// Attributes
protected:
	CString		m_WorkingDir;
	BOOL		m_ForceInform;
	CString		m_PriorityFileFilter;

	// monitor thread communication
	HANDLE		m_Stop;
	CString		m_StopEventName;

	// driver command file name
	CString		m_CmdFileName;
	CString		m_CmdFilePath;

	// driver stdout collector
	HANDLE		m_DumpFile;
	CString		m_DumpFilePath;

	// driver monitor thread properties	
	HANDLE m_DriverThreadID;	
	HANDLE m_DriverListenerThreadID;	

	CString m_InputFileName;
	CString m_InputFilePath;
	CString m_OutputFilePath;
	CString m_ErrorFilePath;

	// window properties
	HICON m_IdleIcon;
	HICON m_WaitIcon;
	HICON m_BusyIcon;

	CMenu m_ContextMenu;
	BOOL m_IsConfigDlgOpened;

	// running server flag
	BOOL m_Running;
	BOOL m_IsServing;

	// log file
	CString		m_LogFilePath;

	// parameters
	CString	m_InputDir;
	CString	m_OutputDir;
	CString	m_ErrorDir;
	BOOL	m_Overwrite;

	BOOL m_UseBMP;
	BOOL m_UseJPG;
	BOOL m_UseTGA;
	BOOL m_UseTIF;

	CString	m_DriverPath;
	CString	m_DriverOptions;
	BOOL	m_OpenPrompt;
	int		m_Priority;

	BOOL	m_MultiPrint;
	BOOL	m_AutoRotate;
	BOOL	m_AutoDPI;
	int		m_HorzDPI;
	int		m_VertDPI;
	BOOL	m_LockDPI;
	BOOL	m_AutoMargins;
	int		m_TopMargin;
	int		m_LeftMargin;
	BOOL	m_LockMargins;
	BOOL	m_AutoCut;
	int		m_CutHeight;
	int		m_CutGap;
	BOOL	m_Inform;
	BOOL	m_CreateLog;

	// image properties
	BOOL	m_IsImage;
	int		m_Copies;
	int		m_ImageHorzDPI;
	int		m_ImageVertDPI;
	double	m_ImageHorzSize;	// inches
	double	m_ImageVertSize;	// inches

protected:
	// logging function
	void LogString(LPCTSTR Line);

	// icon switching
	void ChangeIcon(HICON Icon, LPCTSTR ToolTip = NULL);

	// monitor start/stop
	BOOL StartMonitor(BOOL KillPrevious = TRUE);
	BOOL StopMonitor();

	// registry  configuration readers
	BOOL LoadDirs();
	BOOL LoadFormats();
	BOOL LoadDriverProperties();
	BOOL LoadAdvancedParameters();

	// file processing
	BOOL CreateCmdLine(LPTSTR CmdLine);
	BOOL ProcessNextFile(LPCTSTR FileExt = _T("*"));
	BOOL IsDriverResponseOk();

	// user defined message map
	afx_msg LONG OnFPSrvIconMsg(UINT wParam, LONG lParam);
	afx_msg LONG OnFPSrvMonitorMsg(UINT wParam, LONG lParam);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFPSrvMain)
	public:
	//}}AFX_VIRTUAL

// Implementation
public:

	// Generated message map functions
protected:

	//{{AFX_MSG(CFPSrvMain)
	afx_msg void OnFPSrvMultiPrint();
	afx_msg void OnFPSrvStartStop();
	afx_msg void OnFPSrvProperties();
	afx_msg void OnFPSrvClose();
	afx_msg void OnFPSrvAbout();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FPSRVMAIN_H__7F0794AF_7055_11D2_9DF6_444553540000__INCLUDED_)
