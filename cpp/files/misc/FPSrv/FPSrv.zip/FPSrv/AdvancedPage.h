#if !defined(AFX_ADVANCEDPAGE_H__30AE8C81_7435_11D2_9DF6_444553540000__INCLUDED_)
#define AFX_ADVANCEDPAGE_H__30AE8C81_7435_11D2_9DF6_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// AdvancedPage.h : header file
//

#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CAdvancedPage dialog

class CAdvancedPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CAdvancedPage)

// Construction
public:
	CAdvancedPage();
	~CAdvancedPage();

protected:
// Dialog Data
	//{{AFX_DATA(CAdvancedPage)
	enum { IDD = IDD_FPSRV_ADVANCED };
	BOOL	m_MultiPrint;
	BOOL	m_AutoRotate;
	BOOL	m_AutoDPI;
	int		m_HorzDPI;
	int		m_VertDPI;
	BOOL	m_LockDPI;
	BOOL	m_AutoMargins;
	int		m_TopMargin;
	int		m_LeftMargin;
	BOOL	m_LockMargins;
	BOOL	m_AutoCut;
	int		m_CutHeight;
	int		m_CutGap;
	BOOL	m_Inform;
	BOOL	m_CreateLog;
	//}}AFX_DATA

	CString m_RegAdv;
	CString	m_RegMultiPrint;
	CString	m_RegAutoRotate;
	CString	m_RegAutoDPI;
	CString	m_RegHorzDPI;
	CString	m_RegVertDPI;
	CString m_RegLockDPI;
	CString	m_RegAutoMargins;
	CString	m_RegTopMargin;
	CString	m_RegLeftMargin;
	CString m_RegLockMargins;
	CString	m_RegAutoCut;
	CString	m_RegCutHeight;
	CString	m_RegCutGap;
	CString	m_RegCreateLog;
	CString	m_RegInform;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CAdvancedPage)
	public:
	virtual BOOL OnApply();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CAdvancedPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnMultiPrint();
	afx_msg void OnDPI();
	afx_msg void OnLockDPI();
	afx_msg void OnMargins();
	afx_msg void OnLockMargins();
	afx_msg void OnCut();
	afx_msg void OnChangeHorzDPI();
	afx_msg void OnChangeTopMargin();
	afx_msg void OnGenericChange();
	afx_msg void OnInform();
	afx_msg void OnLog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADVANCEDPAGE_H__30AE8C81_7435_11D2_9DF6_444553540000__INCLUDED_)
