// DriverPage.cpp : implementation file
//

#include "stdafx.h"
#include "DriverPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDriverPage property page

IMPLEMENT_DYNCREATE(CDriverPage, CPropertyPage)

CDriverPage::CDriverPage() : CPropertyPage(CDriverPage::IDD)
{
	//{{AFX_DATA_INIT(CDriverPage)
	m_Path = _T("");
	m_Options = _T("");
	m_OpenPrompt = FALSE;
	//}}AFX_DATA_INIT

	// set exclamation mark icon for this page
	m_psp.dwFlags |= PSP_USEHICON;
	m_psp.hIcon = LoadIcon(NULL,IDI_EXCLAMATION);

	m_RegDriver.LoadString(IDS_REG_DRIVER);
	m_RegDriverPath.LoadString(IDS_REG_DRIVERPATH);
	m_RegDriverOptions.LoadString(IDS_REG_DRIVEROPTIONS);
	m_RegDriverOpenPrompt.LoadString(IDS_REG_DRIVEROPENPROMPT);
	m_RegDriverPriority.LoadString(IDS_REG_DRIVERPRIORITY);
}

CDriverPage::~CDriverPage()
{
}

void CDriverPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDriverPage)
	DDX_Text(pDX, IDC_PATH, m_Path);
	DDX_Text(pDX, IDC_OPTIONS, m_Options);
	DDX_Check(pDX, IDC_OPENPROMPT, m_OpenPrompt);
	DDX_Control(pDX, IDC_PRIORITY, m_PriorityCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDriverPage, CPropertyPage)
	//{{AFX_MSG_MAP(CDriverPage)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_BN_CLICKED(IDC_OPENPROMPT, OnGenericChange)
	ON_EN_CHANGE(IDC_OPTIONS, OnGenericChange)
	ON_EN_CHANGE(IDC_PATH, OnGenericChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDriverPage message handlers

BOOL CDriverPage::OnInitDialog() 
{
	// load driver properties
	m_Path = AfxGetApp()->GetProfileString(m_RegDriver,m_RegDriverPath);
	m_Options = AfxGetApp()->GetProfileString(m_RegDriver,m_RegDriverOptions);
	m_OpenPrompt = AfxGetApp()->GetProfileInt(m_RegDriver,m_RegDriverOpenPrompt,FALSE);
	
	CPropertyPage::OnInitDialog();

	m_PriorityCtrl.SetRange(0,3);
	m_PriorityCtrl.SetPos(AfxGetApp()->GetProfileInt(m_RegDriver,m_RegDriverPriority,0));

	return TRUE;
}

void CDriverPage::OnBrowse() 
{
	CFileDialog dlg(TRUE);
	
	if (dlg.DoModal() == IDOK)
	{
		m_Path = dlg.GetPathName();
		SetDlgItemText(IDC_PATH,m_Path);
	}

	SetModified(TRUE);
}

void CDriverPage::OnGenericChange() 
{
	SetModified(TRUE);
}

BOOL CDriverPage::OnApply() 
{
	// get the dialog data
	UpdateData(TRUE);

	// save driver properties
	AfxGetApp()->WriteProfileString(m_RegDriver,m_RegDriverPath,m_Path);
	AfxGetApp()->WriteProfileString(m_RegDriver,m_RegDriverOptions,m_Options);
	AfxGetApp()->WriteProfileInt(m_RegDriver,m_RegDriverOpenPrompt,m_OpenPrompt);
	AfxGetApp()->WriteProfileInt(m_RegDriver,m_RegDriverPriority,m_PriorityCtrl.GetPos());

	return CPropertyPage::OnApply();
}

