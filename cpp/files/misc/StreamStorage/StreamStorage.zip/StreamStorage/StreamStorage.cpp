// StreamStorage.cpp implementation file
/////////////////////////////////////////////////////////////////////////////


#include <ctype.h>
#include "streamstorage.h"
#include "streamstoragedialog.h"


/////////////////////////////////////////////////////////////////////////////
// DllMain

#include "afxdllx.h"

static AFX_EXTENSION_MODULE StreamStorageDLL = { NULL, NULL };

extern "C" int APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	UNREFERENCED_PARAMETER(lpReserved);

	if (dwReason == DLL_PROCESS_ATTACH)
	{
		// extension DLL one-time initialization
		if (!AfxInitExtensionModule(StreamStorageDLL, hInstance))
			return 0;

		// insert this DLL into the resource chain
		new CDynLinkLibrary(StreamStorageDLL);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		AfxTermExtensionModule(StreamStorageDLL);
	}

	return 1;
}










/////////////////////////////////////////////////////////////////////////////
// StreamStorage

// ==============================
// construction/destruction
// ==============================

StreamStorage::StreamStorage() :	SS_ROOT_STORAGE_NAME(_T('\\')),
								SS_STORAGE_SEPARATOR(_T('\\'))

{
	m_path.RemoveAll();
	m_FileName.Empty();
	m_FullFileName.Empty();

	m_openMode = (DWORD)0;

	m_pOpenedStream = NULL;
	m_OpenedStreamName.Empty();
	m_OpenedStreamFullName.Empty();

	m_IsFileOpened = FALSE;
	m_IsArchiveOpened = FALSE;
}

StreamStorage::~StreamStorage()
{
	// release the current opened file, if any
	DetachCompoundFile();
}



// ==============================
// compound file connection
// ==============================

BOOL StreamStorage::AttachCompoundFile
(
 LPCTSTR pCompFileName,
 SS_ACCESS_MODE accessMode
 )
{
	m_accessMode = accessMode;

	switch (accessMode)
	{
		case  SAVE :
			return AttachCompoundFile(pCompFileName,FALSE,TRUE);
		case  LOAD :
			return AttachCompoundFile(pCompFileName,TRUE,FALSE);
	}

	m_accessMode = UNDEF;
	return FALSE;
}

BOOL StreamStorage::AttachCompoundFile(LPCTSTR pCompFileName,
									  BOOL readOnly /*= TRUE*/,
									  BOOL create /*= FALSE*/)
{
	// enable T2COLE, OLE2TC macros
	USES_CONVERSION;
	m_FileName.Empty();
	m_FullFileName.Empty();

	// release the current opened file, if any
	DetachCompoundFile();

	// create the root interface
	IStorage* pRoot;
	m_openMode = STGM_SHARE_EXCLUSIVE | STGM_FAILIFTHERE;
	m_openMode |= readOnly ? STGM_READ : STGM_READWRITE;
	
	// open the compound file
	HRESULT res = ::StgOpenStorage(T2COLE(pCompFileName),NULL,m_openMode,NULL,0,&pRoot);

	// create if not found
	if ((res != S_OK) && create)
		res = ::StgCreateDocfile(T2COLE(pCompFileName),
					(m_openMode | STGM_CREATE),0,&pRoot);

	if (res != S_OK)
		// something's gone wrong
		return FALSE;

	// set root directory as default
	m_path.AddTail(pRoot);

	// extract the file name
	int pos;
	m_FileName = pCompFileName;
	m_FullFileName = pCompFileName;
	
	if ((pos = m_FileName.ReverseFind(SS_STORAGE_SEPARATOR)) != -1)
		m_FileName = m_FileName.Mid(pos + 1);

	return TRUE;
}

BOOL StreamStorage::DetachCompoundFile(BOOL defrag /*= FALSE*/)
{
	// any storage opened?
	if (m_path.IsEmpty())
		return FALSE;

	// close current opened archive
	if (m_IsArchiveOpened)
		CloseArchive();
	
	// close current opened file
	if (m_IsFileOpened)
		CloseFile();

	// release the current opened storage
	while (!m_path.IsEmpty())
		m_path.RemoveTail()->Release();

	if (defrag)
		DefragCompoundFile(m_FullFileName);

	return TRUE;
}

BOOL StreamStorage::DefragCompoundFile(LPCTSTR pCompFileName)
{
	// obtain a temporarly file name
	TCHAR tmpFileName[MAX_PATH];
	
	if (GetTempFileName(_T("."),_T("~ss"),(UINT)0,tmpFileName) == 0)
		return FALSE;

	// enable T2COLE, OLE2TC macros
	USES_CONVERSION;
	IStorage* pCompacted;
	IStorage* pFragmented;

	// open the fragmented compound file
	if (::StgOpenStorage(T2COLE(pCompFileName),NULL,
					STGM_READ | STGM_SHARE_EXCLUSIVE,
						NULL,0,&pFragmented) != S_OK)
		return FALSE;

	// create a temporarly compound file
	if (!::StgCreateDocfile(T2COLE(tmpFileName),
					STGM_READWRITE | STGM_SHARE_EXCLUSIVE | STGM_CREATE,
						0,&pCompacted) != S_OK)

	// copy the fragmented file into the temp one
	pFragmented->CopyTo(NULL,NULL,NULL,pCompacted);

	// release the compound files
	pCompacted->Release();
	pFragmented->Release();

	// swap the fragmented file with the compressed one
	CFile::Remove(pCompFileName);
	CFile::Rename(tmpFileName,pCompFileName);

	return TRUE;
}



// ==============================
// generic item properties
// ==============================

BOOL StreamStorage::ItemProperties(LPCTSTR pPath, SS_ITEM_INFO* pInfo)
{
	// check for a valid path
	if (!IsValidPath(pPath))
		return FALSE;

	// any storage opened?
	if (m_path.IsEmpty())
		return FALSE;

	// save current working storage
	STATSTG info;
	BOOL error = FALSE;
	CString curStg = ChDir();

	if (ChDir(pPath))
	{
		// item is a storage
		if (m_path.IsEmpty())
			error = TRUE;
		else
		{
			IStorage* pStg = m_path.GetTail();
			pStg->Stat(&info,STATFLAG_NONAME);
		}
	}
	else
	{
		// item should be a stream
		COleStreamFile* pDummy;
		if ((!OpenFile(pPath,&pDummy))
			|| (m_pOpenedStream == NULL))
			error = TRUE;
		else
		{
			m_pOpenedStream->Stat(&info,STATFLAG_NONAME);
			CloseFile();
		}
	}

	// obtain an absolute path
	CString absPath(pPath);
	if (absPath.GetAt(0) != SS_ROOT_STORAGE_NAME)
		absPath = ChDir() + absPath;

	if (!error)
	{
		// fill the SS_ITEM_INFO struct
		pInfo->name = absPath;
		
		if ((absPath.GetLength() == 1)
			&& (absPath.GetAt(0) == SS_ROOT_STORAGE_NAME))
			pInfo->type = SS_ROOT;
		else
		{
			if (info.type == STGTY_STORAGE)
				pInfo->type = SS_DIR;
			else if (info.type == STGTY_STREAM)
				pInfo->type = SS_FILE;
			else
				pInfo->type = SS_UNKNOWN;
		}

		pInfo->size = info.cbSize.LowPart;
		pInfo->created = info.ctime;
		pInfo->accessed = info.atime;
		pInfo->modified = info.mtime;
	}
			
	// restore old working storage
	ChDir(curStg);
	return error;
}



// ==============================
// storage browsing
// ==============================

BOOL StreamStorage::OpenBrowser(LPCTSTR pTitle /*= NULL*/)
{
	// any storage opened?
	if (m_path.IsEmpty())
		return FALSE;

	// open dialog box
	StreamStorageDialog dlg(this,pTitle);
	dlg.DoModal();

	return TRUE;
}

BOOL StreamStorage::ChDirRoot()
{
	// any storage opened?
	if (m_path.IsEmpty())
		return FALSE;

	// move to root storage 
	while (m_path.GetCount() > 1)
		m_path.RemoveTail()->Release();

	return TRUE;
}

BOOL StreamStorage::ChDirDotDot()
{
	// any storage opened beneath the root?
	if (m_path.GetCount() <= 1)
		return FALSE;

	// get back one level
	m_path.RemoveTail()->Release();
	return TRUE;
}

CString	StreamStorage::ChDir()
{
	CString cd;
	
	// retrieve the standard OLE memory allocator
	IMalloc* pAllocator;
	if (::CoGetMalloc(MEMCTX_TASK,&pAllocator) != S_OK)
		return cd;
	
	// travel the directory path
	POSITION pos = m_path.GetHeadPosition();
	
	// jump over the root storage
	if (pos != NULL)
	{
		m_path.GetNext(pos);
		cd += SS_ROOT_STORAGE_NAME;
	}

	// construct the directory path
	while (pos != NULL)
	{
		// request the storage name
		STATSTG info;
		IStorage* pStg = m_path.GetNext(pos);
		pStg->Stat(&info,STATFLAG_DEFAULT);
		cd += info.pwcsName;

		// another separator needed?
		if (pos != NULL)
			cd += SS_STORAGE_SEPARATOR;
		
		pAllocator->Free(info.pwcsName);
	}

	// unload the allocator interface
	pAllocator->Release();
	return cd;
}

BOOL StreamStorage::ChDir(LPCTSTR pDirPath)
{
	// check for a valid path
	if (!IsValidPath(pDirPath))
		return FALSE;

	// any storage opened?
	if (m_path.IsEmpty())
		return FALSE;

	// enable T2COLE, OLE2TC macros
	USES_CONVERSION;

	// is this an absolute path?
	CString pathName(pDirPath);
	if (pathName.GetAt(0) == SS_ROOT_STORAGE_NAME)
	{
		// disgard the root directory symbol
		pathName = pathName.Mid(1);
		
		// move to root storage 
		while (m_path.GetCount() > 1)
			m_path.RemoveTail()->Release();
	}

	// travel trough the storage structure
	int i;
	CString stgName;
	BOOL error = FALSE;

	IStorage* pCurrStg;
	IStorage* pLastStg = GetCurrStg();

	while ((pathName.GetLength() > 0) && (!error))
	{
		// extract the next storage name
		if ((i = pathName.Find(SS_STORAGE_SEPARATOR)) != -1)
		{
			stgName = pathName.Left(i);
			pathName = pathName.Mid(i + 1);
		}
		else
		{
			stgName = pathName;
			pathName.Empty();
		}

		// open the storage
		if ((!IsValidName(stgName))
			|| (pLastStg->OpenStorage(T2COLE(stgName),NULL,
						m_openMode,NULL,0,&pCurrStg) != S_OK))
		{
			// error
			error = TRUE;

			// back to the root
			while (m_path.GetCount() > 1)
				m_path.RemoveTail()->Release();
		}
		else
		{
			// save this step in the storage stack
			pLastStg = pCurrStg;
			m_path.AddTail(pCurrStg);
		}
	}

	return !error;
}

BOOL StreamStorage::MkDir(LPCTSTR pDirPath)
{
	// check for a valid path
	if (!IsValidPath(pDirPath))
		return FALSE;

	// step into the upper level storage
	CString path, dir;
	if (!SplitPath(pDirPath,&path,&dir))
		return FALSE;

	if (!path.IsEmpty())
		if (!ChDir(path))
			return FALSE;

	// is there a valid current storage?
	IStorage* pCurrStg = GetCurrStg();
	
	if (pCurrStg == NULL)
		return FALSE;

	// enable T2COLE, OLE2TC macros
	USES_CONVERSION;
	IStorage* pNewStg;

	HRESULT res = pCurrStg->CreateStorage(T2COLE(dir),m_openMode,0,0,&pNewStg);

	if (res == S_OK)
	{
		// storage successfully created
		pNewStg->Release();
	}
	
	return (res == S_OK);
}

BOOL StreamStorage::RmDir(LPCTSTR pDirPath)
{
	// check for a valid path
	if (!IsValidPath(pDirPath))
		return FALSE;

	// step into the upper level storage
	CString path, dir;
	if (!SplitPath(pDirPath,&path,&dir))
		return FALSE;

	if (!path.IsEmpty())
		if (!ChDir(path))
			return FALSE;

	return RemoveItem(dir,SS_DIR);
}

int StreamStorage::Dir(SS_ITEM_INFO* pItems, int* pCount)
{
	// is there a valid current storage?
	IStorage* pCurrStg = GetCurrStg();
	
	if (pCurrStg == NULL)
		return FALSE;

	// enable T2COLE, OLE2TC macros
	USES_CONVERSION;

	// retrieve the standard OLE memory allocator
	IMalloc* pAllocator;
	if (::CoGetMalloc(MEMCTX_TASK,&pAllocator) != S_OK)
		return FALSE;

	// get the enumerator interface
	IEnumSTATSTG* pEnumerator;
	if (pCurrStg->EnumElements(0,NULL,0,&pEnumerator) != S_OK)
	{
		// unload the OLE allocator interface
		pAllocator->Release();
		return FALSE;
	}
	
	BOOL result = TRUE;

	// retrieve the items
	STATSTG item;
	int count = 0;
	SS_ITEM_INFO* pStgItem;
	
	while (pEnumerator->Next(1,&item,NULL) == S_OK)
	{
		// ready for a new item
		if (pItems != NULL)
		{
			// pick the next item
			pStgItem = pItems + count;
			
			// write in the item data
			pStgItem->name = OLE2CT(item.pwcsName);
			
			if (item.type == STGTY_STORAGE)
				pStgItem->type = SS_DIR;
			else if (item.type == STGTY_STREAM)
				pStgItem->type = SS_FILE;
			else
				pStgItem->type = SS_UNKNOWN;

			pStgItem->size = item.cbSize.LowPart;
			pStgItem->created = item.ctime;
			pStgItem->accessed = item.atime;
			pStgItem->modified = item.mtime;
		}

		count++;

		// free OLE memory
		pAllocator->Free(item.pwcsName);
	}

	// unload the OLE allocator interface
	pAllocator->Release();
	pEnumerator->Release();

	if (pCount != NULL)
		*pCount = count;

	return result;
}	



// ==============================
// stream management
// ==============================

BOOL StreamStorage::OpenFile(LPCTSTR pFilePath,
							COleStreamFile** pFile,
							BOOL readOnly /*= TRUE*/,
							BOOL create /*= FALSE*/)
{
	// check for a valid path
	if (!IsValidPath(pFilePath))
		return FALSE;

	// is there an already opened stream?
	if (m_IsFileOpened && (m_pOpenedStream != NULL))
		return FALSE;

	m_OpenedStreamFullName = pFilePath;
	
	// step into the upper level storage
	CString dir, name;
	if (!SplitPath(pFilePath,&dir,&m_OpenedStreamName))
		return FALSE;

	if (!dir.IsEmpty())
		if (!ChDir(dir))
			return FALSE;

	// get the current storage
	IStorage* pCurrStg = GetCurrStg();
	
	if (pCurrStg == NULL)
		return FALSE;

	// enable T2COLE, OLE2TC macros
	USES_CONVERSION;

	// open the stream
	DWORD mode = STGM_SHARE_EXCLUSIVE | STGM_FAILIFTHERE;
	mode |= (readOnly) ? STGM_READ : STGM_READWRITE;

	// open the stream
	HRESULT res = pCurrStg->OpenStream(T2COLE(m_OpenedStreamName),
										NULL,mode,0,&m_pOpenedStream);
	
	// create the stream if requested
	if ((res != S_OK) && create)
	{
		mode &= ~STGM_FAILIFTHERE;
		mode |= STGM_CREATE;
		res = pCurrStg->CreateStream(T2COLE(m_OpenedStreamName),
										mode,0,0,&m_pOpenedStream);
	}

	if (res != S_OK)
	{
		m_pOpenedStream = NULL;
		return FALSE;
	}

	// wrap a CFile object to the stream
	m_OpenedStreamFile.Attach(m_pOpenedStream);
	*pFile = &m_OpenedStreamFile;
	m_IsFileOpened = TRUE;

	return TRUE;
}

BOOL StreamStorage::CloseFile(BOOL trunc /*= FALSE*/)
{
	if (m_IsFileOpened && (m_pOpenedStream != NULL))
	{
		if (trunc)
		{
			// cut the stream if opened in writing mode
			ULARGE_INTEGER pos;
			pos.LowPart = m_OpenedStreamFile.GetPosition();
			pos.HighPart = 0;
			m_pOpenedStream->SetSize(pos);
		}

		// detach file
		m_IsFileOpened = FALSE;
		m_OpenedStreamFile.Detach();

		// release stream
		m_pOpenedStream->Release();
		m_pOpenedStream = NULL;
		return TRUE;
	}

	return FALSE;
}

BOOL StreamStorage::OpenArchive(LPCTSTR pFilePath,
							   CArchive** pArchive,
							   BOOL load /*= TRUE*/,
							   BOOL create /*= FALSE*/)
{
	// is there an already opened archive?
	if (m_IsArchiveOpened && (m_pOpenedStreamArchive != NULL))
		return FALSE;

	// open the stream file
	COleStreamFile* pDummy;
	if (!OpenFile(pFilePath,&pDummy,load,create))
		return FALSE;

	// wrap a CArchive object to the opened file
	if (load)
		m_pOpenedStreamArchive = new CArchive(&m_OpenedStreamFile,CArchive::load);
	else
		m_pOpenedStreamArchive = new CArchive(&m_OpenedStreamFile,CArchive::store);
		
	// CArchive object successfully created?
	if (m_pOpenedStreamArchive == NULL)
		return FALSE;

	// return the archive
	*pArchive = m_pOpenedStreamArchive;
	m_IsArchiveOpened = TRUE;
	return TRUE;
}

BOOL StreamStorage::CloseArchive()
{
	if (m_IsArchiveOpened)
	{
		BOOL changed = m_pOpenedStreamArchive->IsStoring();

		// close archive
		m_IsArchiveOpened = FALSE;
		m_pOpenedStreamArchive->Close();

		// free memory
		if (m_pOpenedStreamArchive != NULL)
			delete m_pOpenedStreamArchive;
		
		// close related file
		CloseFile(changed);
		return TRUE;
	}

	return FALSE;
}

BOOL StreamStorage::Del(LPCTSTR pFilePath)
{
	// check for a valid path
	if (!IsValidPath(pFilePath))
		return FALSE;

	// step into the upper level storage
	CString dir, name;
	if (!SplitPath(pFilePath,&dir,&name))
		return FALSE;

	if (!dir.IsEmpty())
		if (!ChDir(dir))
			return FALSE;

	return RemoveItem(name,SS_FILE);
}

BOOL StreamStorage::Ren(LPCTSTR pFilePath, LPCTSTR pNewName)
{
	// check for a valid path
	if ((!IsValidPath(pFilePath)) || (!IsValidName(pNewName)))
		return FALSE;

	// step into the upper level storage
	CString dir, name;
	if (!SplitPath(pFilePath,&dir,&name))
		return FALSE;

	if (!dir.IsEmpty())
		if (!ChDir(dir))
			return FALSE;

	// get the current storage
	IStorage* pCurrStg = GetCurrStg();
	
	if (pCurrStg == NULL)
		return FALSE;

	// enable T2COLE, OLE2TC macros
	USES_CONVERSION;

	// rename the stream
	HRESULT res = pCurrStg->RenameElement(T2COLE(name),T2COLE(pNewName));

	return (res == S_OK);
}



// ==============================
// storage stack management
// ==============================

IStorage* StreamStorage::GetRootStg()
{
	return m_path.IsEmpty() ? NULL : m_path.GetHead();
}

IStorage* StreamStorage::GetCurrStg()
{
	return m_path.IsEmpty() ? NULL : m_path.GetTail();
}



// ==============================
// protected utilities
// ==============================

BOOL StreamStorage::RemoveItem(LPCTSTR pName, SS_ITEM_TYPE type)
{
	// is there a valid current storage?
	IStorage* pCurrStg = GetCurrStg();
	
	if (pCurrStg == NULL)
		return FALSE;

	// get the current directory items count
	int items;
	if (!Dir(NULL,&items) || (items == 0))
		return FALSE;

	// get the current directory items info
	SS_ITEM_INFO* pItems = new SS_ITEM_INFO[items];
	
	// alloc failed?
	if (pItems == NULL)
		return FALSE;

	if (Dir(pItems,&items))
	{	
		// search for the supplied item name
		int i = 0;
		BOOL found = FALSE;
		
		while ((i < items) && (!found))
		{
			// item found...
			found = ((pItems[i].type == type)
					&& (pItems[i].name.CompareNoCase(pName) == 0));
			i++;
		}

		if (found)
		{
			// enable T2COLE, OLE2TC macros
			USES_CONVERSION;
			HRESULT res = pCurrStg->DestroyElement(T2COLE(pName));
			
			// free memory
			delete [] pItems;

			return (res == S_OK);
		}
	}
	
	// free memory
	delete [] pItems;

	return FALSE;
}



// ==============================
// item name validation
// ==============================

BOOL StreamStorage::IsValidPath(LPCTSTR pPath)
{
	int i = 0;
	CString path(pPath);

	while ((i < path.GetLength())
	
			&&    ((_istalpha(path.GetAt(i)))
				|| (_istdigit(path.GetAt(i)))

				// any valid DOS symbol but '!'
				|| (path.GetAt(i) == _T('_'))
				|| (path.GetAt(i) == _T('^'))
				|| (path.GetAt(i) == _T('$'))
				|| (path.GetAt(i) == _T('~'))
	//			|| (path.GetAt(i) == _T('!'))	OLE rejects this...
				|| (path.GetAt(i) == _T('#'))
				|| (path.GetAt(i) == _T('%'))
				|| (path.GetAt(i) == _T('&'))
				|| (path.GetAt(i) == _T('-'))
				|| (path.GetAt(i) == _T('{'))
				|| (path.GetAt(i) == _T('}'))
				|| (path.GetAt(i) == _T('@'))
				|| (path.GetAt(i) == _T('`'))
				|| (path.GetAt(i) == _T('\''))
				|| (path.GetAt(i) == _T('('))
				|| (path.GetAt(i) == _T(')'))
	
				// name/extension separator
				|| (path.GetAt(i) == _T('.'))

				// root storage and storage separator
				|| (path.GetAt(i) == SS_ROOT_STORAGE_NAME)
				|| (path.GetAt(i) == SS_STORAGE_SEPARATOR)

				// 'extern object' markup character
				|| (path.GetAt(i) < TCHAR(' '))

				// OLE, like Win32, uses the space
				|| (path.GetAt(i) == _T(' '))))
		i++;

	return ((i != 0) && (i == path.GetLength()));
}

BOOL StreamStorage::IsValidName(LPCTSTR pName)
{
	CString name(pName);

	// a valid name is a path with no dir symbols
	if (!IsValidPath(pName))
		return FALSE;

	int i = 0;
	while ((i < name.GetLength())
		&& (name.GetAt(i) != SS_ROOT_STORAGE_NAME)
		&& (name.GetAt(i) != SS_STORAGE_SEPARATOR))
		i++;

	return ((i != 0) && (i == name.GetLength()));
}

BOOL StreamStorage::SplitPath(LPCTSTR pPath, CString* pDir, CString* pFile)
{
	int pos;
	CString path = pPath;

	// search for the last storage separator
	if ((pos = path.ReverseFind(SS_STORAGE_SEPARATOR)) != -1)
	{
		// do not remove the leading '\', if any
		*pDir = (pos == 0) ? path.Left(pos + 1) : path.Left(pos);
		*pFile = path.Mid(pos + 1);
	}
	else
	{
		*pFile = path;
		pDir->Empty();
	}

	// check the syntax				[NOTE: pDir could be null]
	return (IsValidName(*pFile));
}


BOOL StreamStorage::IsStoring()	
{ 
    return m_accessMode == SAVE; 
}

BOOL StreamStorage::IsLoading()
{ 
    return m_accessMode == LOAD; 
}
