// ShowItemPropertiesDialog.cpp : implementation file
//

#include "stdafx.h"
#include "streamstorage.h"
#include "showitempropertiesdialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// icon size 
#define SIPD_IMAGE_WIDTH		32
#define SIPD_IMAGE_HEIGHT		32


/////////////////////////////////////////////////////////////////////////////
// ShowItemPropertiesDialog dialog

ShowItemPropertiesDialog::ShowItemPropertiesDialog(StreamStorage::SS_ITEM_INFO* pInfo,
												   CWnd* pParent /*=NULL*/)
	: CDialog(ShowItemPropertiesDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(ShowItemPropertiesDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_pItemInfo = pInfo;
}

void ShowItemPropertiesDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ShowItemPropertiesDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(ShowItemPropertiesDialog, CDialog)
	//{{AFX_MSG_MAP(ShowItemPropertiesDialog)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// ShowItemPropertiesDialog message handlers

BOOL ShowItemPropertiesDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CString type;
	switch (m_pItemInfo->type)
	{
		case StreamStorage::SS_ROOT :
			type.LoadString(IDS_SIPD_ROOT_STORAGE);
			break;

		case StreamStorage::SS_DIR :
			type.LoadString(IDS_SIPD_STORAGE);
			break;

		case StreamStorage::SS_FILE :
			type.LoadString(IDS_SIPD_STREAM);
			break;

		case StreamStorage::SS_UNKNOWN :
			// fall through...

		default : 
			type.LoadString(IDS_SIPD_UNKNOWN);
			break;
	}

	// add size field if item is a stream
	if (m_pItemInfo->type == StreamStorage::SS_FILE)
	{
		CString size;
		size.Format(IDS_SIPD_SIZE_TEMPLATE,m_pItemInfo->size);
		type += size;
	}

	SetDlgItemText(IDC_NAME,m_pItemInfo->name);
	SetDlgItemText(IDC_TYPE,type);

	// set dates
	SetDlgItemText(IDC_CREATED,FileTimeToString(&m_pItemInfo->created));
	SetDlgItemText(IDC_MODIFIED,FileTimeToString(&m_pItemInfo->modified));

	return TRUE;
}

void ShowItemPropertiesDialog::OnPaint() 
{
	// retrieve bitmap destination location
	CRect frame;
	GetDlgItem(IDC_FRAME)->GetWindowRect(&frame);
	ScreenToClient(&frame);

	CPaintDC dc(this); 

	// load the icon bitmap
	CBitmap bmp;
	if (!bmp.LoadBitmap(IDB_SIPD_IMAGES))
		return;

	// load bitmap into mem DC
	CDC memDC;
	memDC.CreateCompatibleDC(&dc);
	CBitmap* pOldBitmap = memDC.SelectObject(&bmp);
	
	// transfer bitmap on the screen
	int xPos = 0;

	if (m_pItemInfo->type == StreamStorage::SS_ROOT)
		xPos = SIPD_IMAGE_WIDTH;
	else if (m_pItemInfo->type == StreamStorage::SS_DIR)
		xPos = 2*SIPD_IMAGE_WIDTH;
	else if (m_pItemInfo->type == StreamStorage::SS_FILE)
		xPos = 3*SIPD_IMAGE_WIDTH;

	dc.BitBlt(frame.left,frame.top,SIPD_IMAGE_WIDTH,SIPD_IMAGE_HEIGHT,&memDC,xPos,0,SRCCOPY);

	// release GDI objects
	memDC.SelectObject(pOldBitmap);
	bmp.DeleteObject();
	memDC.DeleteDC();
}

CString ShowItemPropertiesDialog::FileTimeToString(FILETIME* pFileTime)
{
	// is this a valid FileTime?
	if ((pFileTime->dwLowDateTime == 0)
		&& (pFileTime->dwLowDateTime == 0))
		return _T("-");

	// convert date to DosTime format
	WORD date = 0;
	WORD time = 0;

	if (!FileTimeToDosDateTime(pFileTime,&date,&time))
		return _T("-");

	int day = date & 0x001f;
	int month = (date & 0x01e0) >> 5;
	int year = ((date & 0xfe00) >> 9) + 1980;
	
	int sec = (time & 0x001f) * 2;
	int min = (time & 0x07e0) >> 5;
	int hrs = (time & 0xf800) >> 11;

	COleDateTime oleDate(year,month,day,hrs,min,sec);
	return oleDate.Format(_T("%d/%m/%Y   %H:%M:%S"));
}

