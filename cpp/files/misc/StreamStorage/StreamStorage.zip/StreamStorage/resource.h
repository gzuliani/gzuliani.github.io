//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by StreamStorage.rc
//
#define IDD_ASKITEMNAME                 331
#define IDD_STREAMSTORAGE               332
#define IDD_SHOWITEMPROPERTIES          333
#define IDD_VIEWSTREAMCONTENTS          334
#define IDB_SSD_IMAGES                  335
#define IDB_SIPD_IMAGES                 336
#define IDR_CONTEXT_MENU                337
#define IDS_SIPD_ROOT_STORAGE           301
#define IDS_SIPD_STORAGE                302
#define IDS_SIPD_STREAM                 303
#define IDS_SIPD_UNKNOWN                304
#define IDS_SIPD_SIZE_TEMPLATE          305
#define IDS_SSD_CHDIR_TITLE             306
#define IDS_SSD_CANNOT_CHDIR_MSG        307
#define IDS_SSD_MKDIR_TITLE             308
#define IDS_SSD_CANNOT_MKDIR_MSG        309
#define IDS_SSD_RMDIR_MSG_TEMPLATE      310
#define IDS_SSD_CANNOT_RMDIR_MSG        311
#define IDS_SSD_CREATE_TITLE            312
#define IDS_SSD_CANNOT_CREATE_MSG       313
#define IDS_SSD_DEL_MSG_TEMPLATE        314
#define IDS_SSD_CANNOT_DEL_MSG          315
#define IDS_SSD_REN_TITLE               316
#define IDS_SSD_CANNOT_REN_MSG          317
#define IDS_SSD_CANNOT_OPEN_MSG         318
#define IDS_SSD_CANNOT_EXPORT_MSG       319
#define IDS_SSD_CANNOT_IMPORT_MSG       320
#define IDS_SSD_NOT_FOUND_MSG           321
#define IDC_STRUCT                      1002
#define IDC_CHDIR                       1003
#define IDC_MKDIR                       1004
#define IDC_RMDIR                       1005
#define IDC_NEW                         1006
#define IDC_DEL                         1007
#define IDC_REN                         1008
#define IDC_VIEW                        1009
#define IDC_IMPORT                      1010
#define IDC_EXPORT                      1011
#define IDC_PROPERTIES                  1012
#define IDC_CD                          1013
#define IDC_NAME                        1015
#define IDC_TYPE                        1016
#define IDC_FRAME                       1017
#define IDC_CREATED                     1018
#define IDC_MODIFIED                    1019
#define IDC_SCROLLBAR                   1020


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        321
#define _APS_NEXT_COMMAND_VALUE         40000
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
