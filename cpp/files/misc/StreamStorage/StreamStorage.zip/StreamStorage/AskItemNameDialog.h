#if !defined(AFX_ASKITEMNAMEDIALOG_H__1A8EA6C1_0B3E_11D2_B636_444553540000__INCLUDED_)
#define AFX_ASKITEMNAMEDIALOG_H__1A8EA6C1_0B3E_11D2_B636_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// AskItemNameDialog.h : header file
//

#include "stdafx.h"
#include "resource.h"


/////////////////////////////////////////////////////////////////////////////
// AskItemNameDialog dialog

class AskItemNameDialog : public CDialog
{
// Construction
public:
	AskItemNameDialog(CString* pName,
						 LPCTSTR pTitle = NULL,
						 CWnd* pParent = NULL);
protected:
// Dialog Data
	//{{AFX_DATA(AskItemNameDialog)
	enum { IDD = IDD_ASKITEMNAME };
	CString	m_name;
	//}}AFX_DATA

	CString		m_title;
	CString*	m_pName;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(AskItemNameDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(AskItemNameDialog)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ASKITEMNAMEDIALOG_H__1A8EA6C1_0B3E_11D2_B636_444553540000__INCLUDED_)
