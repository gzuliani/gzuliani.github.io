// AskItemNameDialog.cpp : implementation file
/////////////////////////////////////////////////////////////////////////////


#include "askitemnamedialog.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// AskItemNameDialog dialog

AskItemNameDialog::AskItemNameDialog(CString* pName,
											LPCTSTR pTitle /*= NULL*/,
											CWnd* pParent /*= NULL*/)
	: CDialog(AskItemNameDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(AskItemNameDialog)
	m_name = _T("");
	//}}AFX_DATA_INIT

	m_name = *pName;

	// save data
	m_title = pTitle;
	m_pName = pName;
}

void AskItemNameDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(AskItemNameDialog)
	DDX_Text(pDX, IDC_NAME, m_name);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(AskItemNameDialog, CDialog)
	//{{AFX_MSG_MAP(AskItemNameDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// AskItemNameDialog message handlers

BOOL AskItemNameDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if (!m_title.IsEmpty())
		SetWindowText(m_title);

	return TRUE;
}

void AskItemNameDialog::OnOK() 
{
	// retrieve dialog data
	CDialog::OnOK();

	// return the item name
	*m_pName = m_name;
}

