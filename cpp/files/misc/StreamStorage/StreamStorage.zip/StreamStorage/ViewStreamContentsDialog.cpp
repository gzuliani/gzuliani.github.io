// ViewStreamContentsDialog.cpp : implementation file
//

#include "stdafx.h"
#include "streamstorage.h"
#include "viewstreamcontentsdialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// ViewStreamContentsDialog dialog


// table macros
#define VSCD_ADDR_FORMAT		_T("0x%8.8x")
#define VSCD_ADDR_STRING_LEN	10
#define VSCD_BYTE_FORMAT		_T("%02x ")
#define VSCD_BYTE_STRING_LEN	3
#define VSCD_CHAR_FORMAT		_T("%c")
#define VSCD_CHAR_STRING_LEN	1

// table row format is:
//
// |<- addr ->|   |<--- hex bytes --->|   |< ASC >|
// 0x0000000000   00 00 00 00 ... 00 00   aaaa...aa


ViewStreamContentsDialog::ViewStreamContentsDialog(COleStreamFile* pFile,
													CWnd* pParent /*=NULL*/)
	: CDialog(ViewStreamContentsDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(ViewStreamContentsDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_pFile = pFile;
	m_fileSize = 0;

	m_rows = 0;
	m_currRow = 0;
	m_rowHeight = 0;
	m_rowsPerPage = 0;
	m_bytesPerRow = 8;
}

void ViewStreamContentsDialog::OnClose() 
{
	// free allocated memory
	if (m_pBuffer != NULL)
		free(m_pBuffer);

	CDialog::OnClose();
}

void ViewStreamContentsDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ViewStreamContentsDialog)
	DDX_Control(pDX, IDC_SCROLLBAR, m_scrollBar);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(ViewStreamContentsDialog, CDialog)
	//{{AFX_MSG_MAP(ViewStreamContentsDialog)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_CLOSE()
	ON_WM_VSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ViewStreamContentsDialog message handlers

BOOL ViewStreamContentsDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// any data to read from file?
	CFileStatus fs;

	if (!m_pFile->GetStatus(fs))
		// file not opened...
		return TRUE;

	if (fs.m_size <= 0)
		// nothing to read...
		return TRUE;

	// file opened and non empty: read data 
	m_fileSize = fs.m_size;
	m_pBuffer = (BYTE*)malloc(m_fileSize);

	if (m_pBuffer == NULL)
		// allocation error...
		return TRUE;

	if (m_pFile->Read(m_pBuffer,m_fileSize) != (UINT)m_fileSize)
	{
		// file reading error...
		free(m_pBuffer);
		m_pBuffer = NULL;
		return TRUE;
	}

	// how many rows?
	m_rows = m_fileSize / m_bytesPerRow + 1;

	// set row height
	CClientDC dc(this);
	CString text(_T("ABC"));
	CSize textSize = dc.GetTextExtent(text);	
	m_rowHeight = textSize.cy;
	
	// how many rows to draw?
	CRect area;
	GetClientRect(area);
	m_rowsPerPage = (m_rowHeight != 0) ? (area.Height() / m_rowHeight + 1) : 1;

	// set scrollbar properties
	SCROLLINFO si;
	si.cbSize = sizeof(SCROLLINFO);
	si.fMask = SIF_PAGE | SIF_RANGE | SIF_POS;
	si.nMin = 0;
	si.nMax = m_rows;
	si.nPage = m_rowsPerPage;
	si.nPos = 0;
	m_scrollBar.SetScrollInfo(&si);

	return TRUE;
}

void ViewStreamContentsDialog::OnPaint() 
{
	CPaintDC dc(this);

	// get the drawing area
	CRect area,scrollBarRect;
	GetClientRect(area);
	m_scrollBar.GetWindowRect(scrollBarRect);
	area.right -= scrollBarRect.Width();

	// clip text area
	CRgn clipRgn;
	clipRgn.CreateRectRgnIndirect(area);
	dc.SelectClipRgn(&clipRgn);

	// paint the background
	CBrush bkBrush;
	bkBrush.CreateSolidBrush(GetSysColor(COLOR_ACTIVEBORDER));
	dc.FillRect(area,&bkBrush);
	
	CFont* pOldFont = dc.SelectObject(GetFont());
	COLORREF oldBkColor = dc.SetBkColor(GetSysColor(COLOR_ACTIVEBORDER));
	COLORREF oldTextColor = dc.SetTextColor(GetSysColor(COLOR_WINDOWTEXT));

	// create the text row
	CString textRow;
	TCHAR* pAddr = new TCHAR[VSCD_ADDR_STRING_LEN + 1];
	TCHAR* pAscii = new TCHAR[VSCD_CHAR_STRING_LEN*m_bytesPerRow + 1];
	TCHAR* pBytes = new TCHAR[VSCD_BYTE_STRING_LEN*m_bytesPerRow + 1];
	TCHAR aux[VSCD_CHAR_STRING_LEN + VSCD_BYTE_STRING_LEN];
	CString nullAscii(_T(' '),VSCD_CHAR_STRING_LEN);
	CString nullBytes(_T(' '),VSCD_BYTE_STRING_LEN);

	int row = 0;
	BOOL stop = FALSE;
	long addr = m_currRow*m_bytesPerRow;
	
	while ((row < m_rowsPerPage) && (addr < m_fileSize))
	{
		_tcscpy(pAscii,_T(""));
		_tcscpy(pBytes,_T(""));
		_stprintf(pAddr,VSCD_ADDR_FORMAT,addr);
		textRow = pAddr;
		textRow += _T("  ");

		// extract byte file and ascii char 
		for (int byte = 0; byte < m_bytesPerRow; byte++)
		{
			if ((addr + byte) < m_fileSize)
			{
				if (isprint(m_pBuffer[addr + byte]))
					_stprintf(aux,VSCD_CHAR_FORMAT,m_pBuffer[addr + byte]);
				else
					_stprintf(aux,VSCD_CHAR_FORMAT,_T('.'));
				
				_tcscat(pAscii,aux);
				_stprintf(aux,VSCD_BYTE_FORMAT,m_pBuffer[addr + byte]);
				_tcscat(pBytes,aux);
			}
			else
			{
				_tcscat(pAscii,nullAscii);
				_tcscat(pBytes,nullBytes);
			}
		}

		textRow += pBytes;
		textRow += _T("  ");
		textRow += pAscii;
		dc.TextOut(0,row*m_rowHeight,textRow);	

		row++;
		addr += m_bytesPerRow;
	}

	// free memory
	delete [] pAddr;
	delete [] pAscii;
	delete [] pBytes;

	// free gdi resources
	dc.SelectClipRgn(NULL);
	dc.SelectObject(pOldFont);
	dc.SetBkColor(oldBkColor);
	dc.SetTextColor(oldTextColor);
	bkBrush.DeleteObject();			

	ValidateRect(area);
}

void ViewStreamContentsDialog::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// verify the scrollbar identity
	if (pScrollBar != &m_scrollBar)
	{
		CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
		return;
	}

	// where is the cursor right now?
	m_currRow = m_scrollBar.GetScrollPos();

	switch (nSBCode)
	{	
		case SB_BOTTOM :
			nPos = m_rows - m_rowsPerPage + 1;
			break;

		case SB_PAGEDOWN :
			if ((m_currRow + m_rowsPerPage - 1) < (m_rows - m_rowsPerPage + 1))
				nPos = m_currRow + m_rowsPerPage - 1;
			else
				nPos = m_rows - m_rowsPerPage + 1;
			break;

		case SB_LINEDOWN :
			nPos = (m_currRow < (m_rows - m_rowsPerPage + 1)) ? m_currRow + 1 : m_currRow;
			break;

		case SB_LINEUP :
			nPos = (m_currRow > 0) ? m_currRow - 1 : 0;
			break;

		case SB_PAGEUP :
			if (m_currRow - m_rowsPerPage + 1 > 0)
				nPos = m_currRow - m_rowsPerPage + 1;
			else
				nPos = 0;
			break;

		case SB_TOP :
			nPos = 0;
			break;

		case SB_THUMBTRACK :
		case SB_THUMBPOSITION :
			// nothing to do!
			break;

		case SB_ENDSCROLL :
			break;

		default :
			nPos = m_currRow;
	}

	// update the cursor position if changed
	if ((nSBCode != SB_ENDSCROLL) && (m_currRow != (long)nPos))
	{
		m_currRow = nPos;
		m_scrollBar.SetScrollPos(m_currRow,FALSE);
		RedrawWindow(NULL,NULL,RDW_INVALIDATE | RDW_UPDATENOW);
	}
}

void ViewStreamContentsDialog::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	// move the scroll bar to the left side of client area
	if (IsWindow(m_scrollBar.GetSafeHwnd()))
	{
		CRect scrollBarRect;
		m_scrollBar.GetWindowRect(scrollBarRect);
		m_scrollBar.MoveWindow(cx - scrollBarRect.Width(),0,scrollBarRect.Width(),cy - 1);	

		// how many rows to draw?
		m_rowsPerPage = (m_rowHeight != 0) ? (cy / m_rowHeight + 1) : 1;

		// set scrollbar properties
		SCROLLINFO si;
		si.cbSize = sizeof(SCROLLINFO);
		si.fMask = SIF_PAGE;
		si.nPage = m_rowsPerPage;
		m_scrollBar.SetScrollInfo(&si);
		m_scrollBar.EnableWindow(m_rowsPerPage <= m_rows);
	}
}
