// StreamStorage.h : declaration file
/////////////////////////////////////////////////////////////////////////////


#ifndef __STREAM_STORAGE__
#define __STREAM_STORAGE__


#include <afxole.h>
#include <afxconv.h>
#include <afxtempl.h>


/////////////////////////////////////////////////////////////////////////////
// StreamStorage

class AFX_EXT_CLASS StreamStorage
{
protected:
	const TCHAR SS_ROOT_STORAGE_NAME;
	const TCHAR SS_STORAGE_SEPARATOR;

public:
	enum SS_ACCESS_MODE	{ SAVE, LOAD, UNDEF, };
	enum SS_ITEM_TYPE	{ SS_ROOT, SS_DIR, SS_FILE, SS_UNKNOWN, };

	struct SS_ITEM_INFO
	{
		CString			name;
		SS_ITEM_TYPE	type;
		DWORD			size;
		FILETIME		created; 
		FILETIME		accessed; 
		FILETIME		modified; 
	};

	// construction
	StreamStorage();
	~StreamStorage();


	// ==============================
	// compound file connection
    BOOL    AttachCompoundFile 
            (
            LPCTSTR pCompFileName, 
            SS_ACCESS_MODE accessMode
            );

	BOOL DetachCompoundFile(BOOL defrag = FALSE);

	CString	GetFileName()		{ return m_FileName; } 
	CString	GetFullFileName()	{ return m_FullFileName; } 

	BOOL	DefragCompoundFile(LPCTSTR pCompFileName);

	BOOL	IsStoring();
	BOOL	IsLoading();

	// ==============================
	// generic item properties
	BOOL ItemProperties(LPCTSTR pPath, SS_ITEM_INFO* pInfo);


	// ==============================
	// storage browsing
	BOOL OpenBrowser(LPCTSTR pTitle = NULL);

	BOOL	ChDirRoot();
	BOOL	ChDirDotDot();
	CString	ChDir();
	BOOL	ChDir(LPCTSTR pDirPath);
	BOOL	MkDir(LPCTSTR pDirPath);
	BOOL	RmDir(LPCTSTR pDirPath);
	BOOL	Dir(SS_ITEM_INFO* pItems, int* pCount);


	// ==============================
	// stream management
	BOOL	OpenFile(LPCTSTR pFilePath,
					 COleStreamFile** pFile,
					 BOOL readOnly = TRUE,
					 BOOL create = FALSE);
	BOOL	CloseFile(BOOL trunc = FALSE);
	
	BOOL	OpenArchive(LPCTSTR pFilePath,
						CArchive** pArchive,
						BOOL load = TRUE,
						BOOL create = FALSE);
	BOOL	CloseArchive();
	
	BOOL	Del(LPCTSTR pFilePath);
	BOOL	Ren(LPCTSTR pFilePath, LPCTSTR pNewName);
	

protected:
	typedef CTypedPtrList<CPtrList,IStorage*> STORAGE_LIST;

	BOOL	AttachCompoundFile(LPCTSTR pCompFileName,
							   BOOL readOnly = TRUE,
							   BOOL create = FALSE);

	// ==============================
	// storage stack management
	IStorage* GetRootStg();
	IStorage* GetCurrStg();

	STORAGE_LIST	m_path;

	IStream*		m_pOpenedStream;
	CString			m_OpenedStreamName;
	CString			m_OpenedStreamFullName;

	BOOL			m_IsFileOpened;
	COleStreamFile	m_OpenedStreamFile;

	BOOL			m_IsArchiveOpened;
	CArchive*		m_pOpenedStreamArchive;

	// ==============================
	// protected utilities
	BOOL	RemoveItem(LPCTSTR pName, SS_ITEM_TYPE type);


	// ==============================
	// item name validation
	BOOL	IsValidPath(LPCTSTR pPath);
	BOOL	IsValidName(LPCTSTR pName);
	BOOL	SplitPath(LPCTSTR pPath, CString* pDir, CString* pFile);


	// compound file opening mode
	DWORD			m_openMode;
	SS_ACCESS_MODE	m_accessMode;

	// compound file path name
	CString	m_FileName;
	CString	m_FullFileName;
	
};

#endif	// __STREAM_STORAGE__
