#if !defined(AFX_STREAMSTORAGEDIALOG_H__49C926A1_0A70_11D2_B636_444553540000__INCLUDED_)
#define AFX_STREAMSTORAGEDIALOG_H__49C926A1_0A70_11D2_B636_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// StreamStorageDialog.h : header file
//

#include <afxcmn.h>
#include "resource.h"
#include "streamstorage.h"


/////////////////////////////////////////////////////////////////////////////
// StreamStorageDialog dialog

class StreamStorageDialog : public CDialog
{
protected:

	// images IDs - see IDB_SSD_IMAGES resource
	enum {	IMG_UNKNOWN = 0,
			IMG_UNKNOWN_SEL, 
			IMG_ROOT,
			IMG_ROOT_SEL,
			IMG_OPEN_ROOT,
			IMG_OPEN_ROOT_SEL,
			IMG_DIR,
			IMG_DIR_SEL,
			IMG_OPEN_DIR,
			IMG_OPEN_DIR_SEL,
			IMG_FILE,
			IMG_FILE_SEL, };

// Construction
public:
	StreamStorageDialog(StreamStorage* pStreamStorage,
					   LPCTSTR pTitle = NULL,
					   CWnd* pParent = NULL);

protected:
// Dialog Data
	//{{AFX_DATA(StreamStorageDialog)
	enum { IDD = IDD_STREAMSTORAGE };
	CTreeCtrl	m_tree;
	//}}AFX_DATA

	// interface data
	CString			m_title;

	CImageList		m_images;
	StreamStorage*	m_pStreamStorage;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(StreamStorageDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// =============================
	// storage tree construction
	void InitTree();
	void InitTreeAux(StreamStorage* pSSystem, HTREEITEM append);
	void SplitPath(LPCTSTR pPath, CString* pDir, CString* pFile);
	void ExpandPath(CString path);

	// Generated message map functions
	//{{AFX_MSG(StreamStorageDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnStructSelChanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnStructExpanded(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnStructDoubleClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnStructRightClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnChDir();
	afx_msg void OnMkDir();
	afx_msg void OnRmDir();
	afx_msg void OnNew();
	afx_msg void OnDel();
	afx_msg void OnRename();
	afx_msg void OnView();
	afx_msg void OnImport();
	afx_msg void OnExport();
	afx_msg void OnProperties();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STREAMSTORAGEDIALOG_H__49C926A1_0A70_11D2_B636_444553540000__INCLUDED_)
