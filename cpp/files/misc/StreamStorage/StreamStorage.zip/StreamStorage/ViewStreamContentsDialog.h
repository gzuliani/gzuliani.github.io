#if !defined(AFX_VIEWSTREAMCONTENTSDIALOG_H__F9553560_128F_11D2_B636_0000B45C6B2C__INCLUDED_)
#define AFX_VIEWSTREAMCONTENTSDIALOG_H__F9553560_128F_11D2_B636_0000B45C6B2C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ViewStreamContentsDialog.h : header file
//

#include "stdafx.h"
#include "resource.h"


/////////////////////////////////////////////////////////////////////////////
// ViewStreamContentsDialog dialog

class ViewStreamContentsDialog : public CDialog
{
// Construction
public:
	ViewStreamContentsDialog(COleStreamFile* pFile, CWnd* pParent = NULL);

protected:
// Dialog Data
	//{{AFX_DATA(ViewStreamContentsDialog)
	enum { IDD = IDD_VIEWSTREAMCONTENTS };
	CScrollBar	m_scrollBar;
	//}}AFX_DATA

	COleStreamFile* m_pFile;
	long			m_fileSize;

	BYTE*			m_pBuffer;

	long			m_rows;
	long			m_currRow;
	int				m_rowHeight;
	int				m_rowsPerPage;
	int				m_bytesPerRow;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ViewStreamContentsDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ViewStreamContentsDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnClose();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VIEWSTREAMCONTENTSDIALOG_H__F9553560_128F_11D2_B636_0000B45C6B2C__INCLUDED_)
