// StreamStorageDialog.cpp : implementation file
/////////////////////////////////////////////////////////////////////////////


#include "streamstoragedialog.h"
#include "askitemnamedialog.h"
#include "showitempropertiesdialog.h"
#include "viewstreamcontentsdialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// flags used for node identification
#define SSD_UNKNOWN				0x00000001
#define SSD_ROOT				0x00000002
#define SSD_STORAGE				0x00000004
#define SSD_STREAM				0x00000008

// context submenu identifiers
#define SSD_UNKNOWN_MENU		0
#define SSD_ROOT_MENU			1
#define SSD_STORAGE_MENU		2
#define SSD_STREAM_MENU			3

/////////////////////////////////////////////////////////////////////////////
// StreamStorageDialog dialog

StreamStorageDialog::StreamStorageDialog(StreamStorage* pStreamStorage,
									   LPCTSTR pTitle /*= NULL*/,
									   CWnd* pParent /*= NULL*/)
	: CDialog(StreamStorageDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(StreamStorageDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_title = pTitle;
	m_pStreamStorage = pStreamStorage;
}

void StreamStorageDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(StreamStorageDialog)
	DDX_Control(pDX, IDC_STRUCT, m_tree);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(StreamStorageDialog, CDialog)
	//{{AFX_MSG_MAP(StreamStorageDialog)
	ON_NOTIFY(TVN_SELCHANGED, IDC_STRUCT, OnStructSelChanged)
	ON_NOTIFY(TVN_ITEMEXPANDED, IDC_STRUCT, OnStructExpanded)
	ON_NOTIFY(NM_DBLCLK, IDC_STRUCT, OnStructDoubleClick)
	ON_NOTIFY(NM_RCLICK, IDC_STRUCT, OnStructRightClick)
	ON_BN_CLICKED(IDC_CHDIR, OnChDir)
	ON_BN_CLICKED(IDC_MKDIR, OnMkDir)
	ON_BN_CLICKED(IDC_RMDIR, OnRmDir)
	ON_BN_CLICKED(IDC_NEW, OnNew)
	ON_BN_CLICKED(IDC_DEL, OnDel)
	ON_BN_CLICKED(IDC_REN, OnRename)
	ON_BN_CLICKED(IDC_VIEW, OnView)
	ON_BN_CLICKED(IDC_IMPORT, OnImport)
	ON_BN_CLICKED(IDC_EXPORT, OnExport)
	ON_BN_CLICKED(IDC_PROPERTIES, OnProperties)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// StreamStorageDialog message handlers

BOOL StreamStorageDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// set dialog box title
	if (!m_title.IsEmpty())
		SetWindowText(m_title);

	// load tree images
	m_images.Create(IDB_SSD_IMAGES,16,1,RGB(0xff,0xff,0xff));
	m_tree.SetImageList(&m_images,TVSIL_NORMAL);

	InitTree();
	return TRUE;
}



// =============================
// tree control notifications
// =============================

void StreamStorageDialog::OnStructSelChanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	
	// create path name	
	CString path;
	TCHAR buffer[256];

	TV_ITEM info;
	info.hItem = pNMTreeView->itemNew.hItem;

	// enable the buttons accordingly to the node type
	info.mask = TVIF_PARAM;
	BOOL isStreamSelected = FALSE;

	if (m_tree.GetItem(&info))
	{
		isStreamSelected = (info.lParam == SSD_STREAM);
		GetDlgItem(IDC_RMDIR)->EnableWindow(info.lParam == SSD_STORAGE);
		GetDlgItem(IDC_DEL)->EnableWindow(isStreamSelected);
		GetDlgItem(IDC_REN)->EnableWindow(isStreamSelected);
		GetDlgItem(IDC_VIEW)->EnableWindow(isStreamSelected);
		GetDlgItem(IDC_EXPORT)->EnableWindow(isStreamSelected);
	}

	// browse the storage tree upwards
	info.hItem = pNMTreeView->itemNew.hItem;

	while ((info.hItem != NULL) && (info.hItem != m_tree.GetRootItem()))
	{
		info.pszText = buffer;
		info.cchTextMax = sizeof(buffer);
		info.mask = TVIF_HANDLE | TVIF_TEXT;
		
		if (m_tree.GetItem(&info))
		{
			path = info.pszText + path;
			path = _T("\\") + path;
		}
		
		// another step up...
		info.hItem = m_tree.GetNextItem(info.hItem,TVGN_PARENT);
	}

	// set the path name
	if (path.IsEmpty())
		path = _T("\\");

	SetDlgItemText(IDC_CD,path);

	// update the current docfile directory
	if (isStreamSelected)
	{
		CString dir,name;
		SplitPath(path,&dir,&name);
		m_pStreamStorage->ChDir(dir);
	}
	else
		m_pStreamStorage->ChDir(path);

	*pResult = 0;
}

void StreamStorageDialog::OnStructExpanded(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	HTREEITEM item = pNMTreeView->itemNew.hItem;

	if (item != NULL)
	{
		// item is collapsed
		if (pNMTreeView->action == TVE_COLLAPSE)
		{
			switch (m_tree.GetItemData(item))
			{
				case SSD_ROOT:
					m_tree.SetItemImage(item,IMG_ROOT,IMG_ROOT_SEL);
					break;

				case SSD_STORAGE:
					m_tree.SetItemImage(item,IMG_DIR,IMG_DIR_SEL);
					break;

				case SSD_STREAM:
					m_tree.SetItemImage(item,IMG_FILE,IMG_FILE_SEL);
					break;

				case SSD_UNKNOWN:
					// fall through...

				default:
					m_tree.SetItemImage(item,IMG_UNKNOWN,IMG_UNKNOWN_SEL);
					break;
			}
		}

		// item is expanded
		if (pNMTreeView->action == TVE_EXPAND)
		{
			switch (m_tree.GetItemData(item))
			{
				case SSD_ROOT:
					m_tree.SetItemImage(item,IMG_OPEN_ROOT,IMG_OPEN_ROOT_SEL);
					break;

				case SSD_STORAGE:
					m_tree.SetItemImage(item,IMG_OPEN_DIR,IMG_OPEN_DIR_SEL);
					break;

				case SSD_STREAM:
					// streams cannot be expanded...
					m_tree.SetItemImage(item,IMG_FILE,IMG_FILE_SEL);
					break;

				case SSD_UNKNOWN:
					// fall through...

				default:
					m_tree.SetItemImage(item,IMG_UNKNOWN,IMG_UNKNOWN_SEL);
					break;
			}
		}
	}

	*pResult = 0;
}

void StreamStorageDialog::OnStructDoubleClick(NMHDR *pNMHDR, LRESULT *pResult)
{
	OnView();
	*pResult = 0;
}

void StreamStorageDialog::OnStructRightClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CPoint clickPos;
	GetCursorPos(&clickPos);
	CPoint clientPt(clickPos);
	m_tree.ScreenToClient(&clientPt);
	
	UINT hitInfo;
	HTREEITEM item = m_tree.HitTest(clientPt,&hitInfo);

	// retrieve tree item info
	TV_ITEM info;
	TCHAR buffer[256];
	info.hItem = item;
	info.pszText = buffer;
	info.cchTextMax = sizeof(buffer);
	info.mask = TVIF_HANDLE | TVIF_TEXT;
				
	// any item clicked?
	if ((item != NULL)
		&& (m_tree.GetItem(&info)))
	{
		// select the clicked item
		m_tree.SelectItem(item);

		// open the context menu
		switch(m_tree.GetItemData(item))
		{	
			case SSD_ROOT:
			{
				CMenu context;
				context.LoadMenu(IDR_CONTEXT_MENU);
				CMenu* pContextMenu = context.GetSubMenu(SSD_ROOT_MENU);
				pContextMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_LEFTBUTTON|TPM_RIGHTBUTTON,clickPos.x,clickPos.y,this);
				break;
			}
			
			case SSD_STORAGE:
			{
				CMenu context;
				context.LoadMenu(IDR_CONTEXT_MENU);
				CMenu* pContextMenu = context.GetSubMenu(SSD_STORAGE_MENU);
				pContextMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_LEFTBUTTON|TPM_RIGHTBUTTON,clickPos.x,clickPos.y,this);
				break;
			}
			
			case SSD_STREAM:
			{
				CMenu context;
				context.LoadMenu(IDR_CONTEXT_MENU);
				CMenu* pContextMenu = context.GetSubMenu(SSD_STREAM_MENU);
				pContextMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_LEFTBUTTON|TPM_RIGHTBUTTON,clickPos.x,clickPos.y,this);
				break;
			}

			case SSD_UNKNOWN:
			{
				CMenu context;
				context.LoadMenu(IDR_CONTEXT_MENU);
				CMenu* pContextMenu = context.GetSubMenu(SSD_UNKNOWN_MENU);
				pContextMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_LEFTBUTTON|TPM_RIGHTBUTTON,clickPos.x,clickPos.y,this);
				break;
			}
			
			default:
				break;
		}
	}

	*pResult = 0;
}



// =============================
// storage tree construction
// =============================

void StreamStorageDialog::InitTree()
{
	// remove all items
	if (m_tree.GetCount() > 0)
		m_tree.DeleteAllItems();
		
	// start with the main storage
	if (!m_pStreamStorage->ChDirRoot())
		return;

	// create the storage tree from the root
	HTREEITEM root = m_tree.InsertItem(m_pStreamStorage->GetFileName(),IMG_ROOT,IMG_ROOT_SEL);
	m_tree.SetItemData(root,SSD_ROOT);
	InitTreeAux(m_pStreamStorage,root);
}

void StreamStorageDialog::InitTreeAux(StreamStorage* pSSystem, HTREEITEM root)
{
	// get the current storage items count
	int items;
	if (!m_pStreamStorage->Dir(NULL,&items) || (items == 0))
		return;

	// get the current storage items info
	StreamStorage::SS_ITEM_INFO* pItems = 
		new StreamStorage::SS_ITEM_INFO[items];
	
	// alloc failed?
	if (pItems == NULL)
		return;

	if (m_pStreamStorage->Dir(pItems,&items))
	{	
		// recursively visit the storage items list
		for (int i = 0; i < items; i++)
		{
			// append current item
			if (pItems[i].type == StreamStorage::SS_DIR)
			{
				// append current item sub-items, if any
				HTREEITEM insPos = m_tree.InsertItem(pItems[i].name,IMG_DIR,IMG_DIR_SEL,root,TVI_SORT);
				m_tree.SetItemData(insPos,SSD_STORAGE);

				// get into the substorage
				if (!pSSystem->ChDir(pItems[i].name))
					break;

				InitTreeAux(pSSystem,insPos);
	
				// back to the current storage
				if (!pSSystem->ChDirDotDot())
					break;
			}
			else if (pItems[i].type == StreamStorage::SS_FILE)
			{
				HTREEITEM item = m_tree.InsertItem(pItems[i].name,IMG_FILE,IMG_FILE_SEL,root,TVI_SORT);
				m_tree.SetItemData(item,SSD_STREAM);
			}
			else
			{
				HTREEITEM item = m_tree.InsertItem(pItems[i].name,IMG_UNKNOWN,IMG_UNKNOWN_SEL,root,TVI_SORT);
				m_tree.SetItemData(item,SSD_UNKNOWN);
			}
		}
	}

	// free memory
	delete [] pItems;
}

void StreamStorageDialog::ExpandPath(CString path)
{
	// start with the root
	HTREEITEM item = m_tree.GetRootItem();

	if (path.GetAt(0) == _T('\\'))
		path = path.Mid(1);

	// open the path on the tree 
	int pos;
	CString dir;

	while ((item != NULL) && (!path.IsEmpty()))
	{
		// get next substorage name
		if ((pos = path.Find(_T('\\'))) != -1)
		{
			dir = path.Left(pos);
			path = path.Mid(pos + 1);
		}
		else
		{
			dir = path;
			path.Empty();
		}

		// is there a node named as the current storage?
		TV_ITEM info;
		TCHAR buffer[256];

		BOOL found = FALSE;
		HTREEITEM sub = m_tree.GetChildItem(item);

		while ((sub != NULL) && (!found))
		{
			// retrieve children info
			info.hItem = sub;
			info.pszText = buffer;
			info.cchTextMax = sizeof(buffer);
			info.mask = TVIF_HANDLE | TVIF_TEXT;
				
			if (m_tree.GetItem(&info))
				found = (dir.CompareNoCase(info.pszText) == 0);

			// ready for the next node
			sub = m_tree.GetNextSiblingItem(sub);
		}

		// expand the selected item
		if (found)
		{
			item = info.hItem;
			m_tree.Expand(item,TVE_EXPAND);
			m_tree.SelectItem(info.hItem);
		}
		else
			// node not found: exit
			item = NULL;
	}
}

void StreamStorageDialog::SplitPath(LPCTSTR pPath, CString* pDir, CString* pFile)
{
	int pos;
	CString path = pPath;

	// search for the last storage separator
	if ((pos = path.ReverseFind(_T('\\'))) != -1)
	{
		// do not remove the leading '\', if any
		*pDir = (pos == 0) ? path.Left(pos + 1) : path.Left(pos);
		*pFile = path.Mid(pos + 1);
	}
	else
	{
		*pFile = path;
		pDir->Empty();
	}
}



// =============================
// buttons management
// =============================

void StreamStorageDialog::OnChDir() 
{
	// ask for the new storage name
	CString path;
	CString msg((LPCTSTR)IDS_SSD_CHDIR_TITLE);
	AskItemNameDialog dlg(&path,msg);
		
	if (dlg.DoModal() == IDOK)
	{
		// create an absolute path
		if ((path.IsEmpty()) || (path.GetAt(0) != _T('\\')))
		{
			// use the current storage
			CString cd;
			GetDlgItemText(IDC_CD,cd);
			cd += _T('\\');
			path = cd + path;
		}

		if (!m_pStreamStorage->ChDir(path))
		{
			CString msg((LPCTSTR)IDS_SSD_CANNOT_CHDIR_MSG);
			AfxMessageBox(msg,MB_ICONSTOP);
		}
		else
			// explode the tree 
			ExpandPath(path);
	}
}

void StreamStorageDialog::OnMkDir() 
{
	// get the path name
	CString path;
	GetDlgItemText(IDC_CD,path);

	// ask for the new storage name
	CString dir;
	CString msg((LPCTSTR)IDS_SSD_MKDIR_TITLE);
	AskItemNameDialog dlg(&dir,msg);
		
	if (dlg.DoModal() == IDOK)
	{
		if (dir.GetLength() > 0)
		{
			// ensure this is an absolute path
			if (dir.GetAt(0) != _T('\\'))
			{
				path += _T('\\');
				dir = path + dir;
			}
		}	
		else
			return;

		if (!m_pStreamStorage->MkDir(dir))
		{
			CString msg((LPCTSTR)IDS_SSD_CANNOT_MKDIR_MSG);
			AfxMessageBox(msg,MB_ICONSTOP);
		}
		else
		{
			// extract the path to the newly created storage
			CString name;
			SplitPath(dir,&path,&name);

			ExpandPath(path);
			HTREEITEM root = m_tree.GetSelectedItem();

			if (root != NULL)
			{
				// insert the new item and show it
				HTREEITEM item = m_tree.InsertItem(name,IMG_DIR,IMG_DIR_SEL,root,TVI_SORT);
				m_tree.SetItemData(item,SSD_STORAGE);
				m_tree.Expand(root,TVE_EXPAND);
					
				if (item != NULL)
					m_tree.SelectItem(item);
			}
			else
				InitTree();
		}
	}
}

void StreamStorageDialog::OnRmDir() 
{
	// get the path name
	CString path;
	GetDlgItemText(IDC_CD,path);

	// confirm
	CString msg,tmp((LPCTSTR)IDS_SSD_RMDIR_MSG_TEMPLATE);
	msg.Format(tmp,path);

	if (AfxMessageBox(msg,MB_ICONQUESTION | MB_YESNO) != IDYES)
		return;

	// remove the selected substorage
	if (!m_pStreamStorage->RmDir(path))
	{
		CString msg((LPCTSTR)IDS_SSD_CANNOT_RMDIR_MSG);
		AfxMessageBox(msg,MB_ICONSTOP);
	}
	else
	{
		// update tree branches
		HTREEITEM item = m_tree.GetSelectedItem();

		if (item != NULL)
		{
			// remove the selected item
			HTREEITEM parent = m_tree.GetParentItem(item);
			m_tree.DeleteItem(item);
					
			if (parent != NULL)
				m_tree.SelectItem(parent);
		}
		else
			InitTree();
	}
}



// =============================
// file system management
// =============================

void StreamStorageDialog::OnNew() 
{
	// ask for the stream name
	CString name;
	CString msg((LPCTSTR)IDS_SSD_CREATE_TITLE);
	AskItemNameDialog dlg(&name,msg);
	
	if (dlg.DoModal() == IDOK)
	{
		// get the path name
		CString path;
		GetDlgItemText(IDC_CD,path);

		if (name.GetLength() > 0)
		{
			// ensure this is an absolute path
			if (name.GetAt(0) != _T('\\'))
			{
				path += _T('\\');
				name = path + name;
			}
		}	
		else
			return;

		// create the submitted stream
		COleStreamFile* pFile;
		if (!m_pStreamStorage->OpenFile(name,&pFile,FALSE,TRUE))
		{
			CString msg((LPCTSTR)IDS_SSD_CANNOT_CREATE_MSG);
			AfxMessageBox(msg,MB_ICONSTOP);
			return;
		}

		// close the stream
		m_pStreamStorage->CloseFile();

		// create the related tree item
		CString dir;
		path = name;
		SplitPath(path,&dir,&name);

		ExpandPath(dir);
		HTREEITEM root = m_tree.GetSelectedItem();

		if (root != NULL)
		{
			// insert the new item and show it
			HTREEITEM item = m_tree.InsertItem(name,IMG_FILE,IMG_FILE_SEL,root,TVI_SORT);
			m_tree.SetItemData(item,SSD_STREAM);
			m_tree.Expand(root,TVE_EXPAND);
					
			if (item != NULL)
				m_tree.SelectItem(item);
		}
		else
			InitTree();
	}
}

void StreamStorageDialog::OnDel() 
{
	// get the path name
	CString path;
	GetDlgItemText(IDC_CD,path);

	// confirm
	CString msg,tmp((LPCTSTR)IDS_SSD_DEL_MSG_TEMPLATE);
	msg.Format(tmp,path);

	if (AfxMessageBox(msg,MB_ICONQUESTION | MB_YESNO) != IDYES)
		return;

	// remove the selected stream
	if (!m_pStreamStorage->Del(path))
	{
		CString msg((LPCTSTR)IDS_SSD_CANNOT_DEL_MSG);
		AfxMessageBox(msg,MB_ICONSTOP);
	}
	else
	{
		// update tree branches
		HTREEITEM item = m_tree.GetSelectedItem();

		if (item != NULL)
		{
			// remove the selected item
			HTREEITEM parent = m_tree.GetParentItem(item);
			m_tree.DeleteItem(item);
					
			if (parent != NULL)
				m_tree.SelectItem(parent);
		}
		else
			InitTree();
	}
}

void StreamStorageDialog::OnRename() 
{
	// ask for the new stream name
	CString name;
	CString msg((LPCTSTR)IDS_SSD_REN_TITLE);
	AskItemNameDialog dlg(&name,msg);
	
	if (dlg.DoModal() == IDOK)
	{
		// get the path name
		CString path;
		GetDlgItemText(IDC_CD,path);

		// rename the selected stream
		if (!m_pStreamStorage->Ren(path,name))
		{
			CString msg((LPCTSTR)IDS_SSD_CANNOT_REN_MSG);
			AfxMessageBox(msg,MB_ICONSTOP);
		}
		else
		{
			// update tree item name
			HTREEITEM item = m_tree.GetSelectedItem();
			
			if (item != NULL)
				m_tree.SetItemText(item,name);
			else
				InitTree();
		}
	}
}

void StreamStorageDialog::OnView() 
{
	// get the selected tree item name
	CString name;
	HTREEITEM item = m_tree.GetSelectedItem();

	if ((item != NULL)
		&& (m_tree.GetItemData(item) == SSD_STREAM))
	{
		// open the selected stream 
		CString path;
		GetDlgItemText(IDC_CD,path);
		COleStreamFile* pStream;
		
		if (m_pStreamStorage->OpenFile(path,&pStream))
		{
			ViewStreamContentsDialog dlg(pStream);
			dlg.DoModal();
			m_pStreamStorage->CloseFile();
			return;
		}
	}
}

void StreamStorageDialog::OnImport() 
{
	// get the selected tree item name
	CString name;
	HTREEITEM item = m_tree.GetSelectedItem();

	if (item != NULL)
		name = m_tree.GetItemText(item);

	// open the "file open" dialog
	CFileDialog dlg(TRUE,NULL,name);

	if (dlg.DoModal() == IDOK)
	{
		// ask for a new stream name
		CString stream(dlg.GetFileName());
		CString msg((LPCTSTR)IDS_SSD_CREATE_TITLE);
		AskItemNameDialog dlgAux(&stream,msg);
		
		if (dlgAux.DoModal() != IDOK)
			return;

		// create an absolute path
		if ((stream.IsEmpty()) || (stream.GetAt(0) != _T('\\')))
		{
			// use the current storage
			CString cd;
			GetDlgItemText(IDC_CD,cd);
			cd += _T('\\');
			stream = cd + stream;
		}

		CFile ImportFile;
		COleStreamFile* pStream;
		
		// open the selected stream 
		if (!m_pStreamStorage->OpenFile(stream,&pStream,FALSE,TRUE))
		{
			CString msg((LPCTSTR)IDS_SSD_CANNOT_OPEN_MSG);
			AfxMessageBox(msg,MB_ICONSTOP);
			return;
		}

		// open the specified file
		if (!ImportFile.Open(dlg.GetPathName(),CFile::modeRead))
		{
			CString msg((LPCTSTR)IDS_SSD_CANNOT_IMPORT_MSG);
			AfxMessageBox(msg,MB_ICONSTOP);
			m_pStreamStorage->CloseFile();
			return;
		}

		// transfer data
		CFileStatus fs;
		if (ImportFile.GetStatus(fs) && (fs.m_size > 0))
		{
			BYTE* pBuffer = new BYTE[fs.m_size];
			
			if (pBuffer != NULL)
			{
				ImportFile.Read(pBuffer,fs.m_size);
				pStream->Write(pBuffer,fs.m_size);
				delete [] pBuffer;
			}
			else
			{
				CString msg((LPCTSTR)IDS_SSD_CANNOT_IMPORT_MSG);
				AfxMessageBox(msg,MB_ICONSTOP);
			}
		}

		// close file and stream
		ImportFile.Close();
		m_pStreamStorage->CloseFile();

		// create the related tree item
		CString dir, name;
		SplitPath(stream,&dir,&name);

		ExpandPath(dir);
		HTREEITEM root = m_tree.GetSelectedItem();

		if (root != NULL)
		{
			// insert the new item and show it
			HTREEITEM item = m_tree.InsertItem(name,IMG_FILE,IMG_FILE_SEL,root,TVI_SORT);
			m_tree.SetItemData(item,SSD_STREAM);
			m_tree.Expand(root,TVE_EXPAND);
					
			if (item != NULL)
				m_tree.SelectItem(item);
		}
		else
			InitTree();
	}
}

void StreamStorageDialog::OnExport() 
{
	// get the selected tree item name
	CString name;
	HTREEITEM item = m_tree.GetSelectedItem();

	if (item != NULL)
		name = m_tree.GetItemText(item);

	// open the "file save" dialog
	CFileDialog dlg(FALSE,NULL,name);

	if (dlg.DoModal() == IDOK)
	{
		CString path;
		GetDlgItemText(IDC_CD,path);

		CFile ExportFile;
		COleStreamFile* pStream;
		
		// open the selected stream 
		if (!m_pStreamStorage->OpenFile(path,&pStream))
		{
			CString msg((LPCTSTR)IDS_SSD_CANNOT_OPEN_MSG);
			AfxMessageBox(msg,MB_ICONSTOP);
			return;
		}

		// open the specified file
		if (!ExportFile.Open(dlg.GetPathName(),CFile::modeWrite | CFile::modeCreate))
		{
			CString msg((LPCTSTR)IDS_SSD_CANNOT_EXPORT_MSG);
			AfxMessageBox(msg,MB_ICONSTOP);
			m_pStreamStorage->CloseFile();
			return;
		}

		// transfer data
		CFileStatus fs;
		if (pStream->GetStatus(fs) && (fs.m_size > 0))
		{
			BYTE* pBuffer = new BYTE[fs.m_size];
			
			if (pBuffer != NULL)
			{
				pStream->Read(pBuffer,fs.m_size);
				ExportFile.Write(pBuffer,fs.m_size);
				delete [] pBuffer;
			}
			else
			{
				CString msg((LPCTSTR)IDS_SSD_CANNOT_EXPORT_MSG);
				AfxMessageBox(msg,MB_ICONSTOP);
			}
		}

		// close file and stream
		ExportFile.Close();
		m_pStreamStorage->CloseFile();
	}
}

void StreamStorageDialog::OnProperties() 
{
	// get the selected tree item name
	HTREEITEM item = m_tree.GetSelectedItem();

	if (item != NULL)
	{
		// get the item name and location
		StreamStorage::SS_ITEM_INFO info;
		CString dir(m_pStreamStorage->ChDir());

		// add the stream name to the path
		if (m_tree.GetItemData(item) == SSD_STREAM)
		{
			if (dir.GetAt(dir.GetLength() - 1) != _T('\\'))
				dir += _T('\\');
			
			dir += m_tree.GetItemText(item);
		}

		// get the item properties
		if (!m_pStreamStorage->ItemProperties(dir,&info))
		{
			// remove the path 
			CString dir,name;
			SplitPath(info.name,&dir,&name);
			info.name = name.IsEmpty() ? _T("\\") : name;

			// open properties box
			ShowItemPropertiesDialog dlg(&info);
			dlg.DoModal();
		}
		else
		{
			CString msg((LPCTSTR)IDS_SSD_NOT_FOUND_MSG);
			AfxMessageBox(msg,MB_ICONSTOP);
		}
	}
}


