#if !defined(AFX_SHOWITEMPROPERTIESDIALOG_H__58D00E42_0FF5_11D2_B636_0000B45C6B2C__INCLUDED_)
#define AFX_SHOWITEMPROPERTIESDIALOG_H__58D00E42_0FF5_11D2_B636_0000B45C6B2C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ShowItemPropertiesDialog.h : header file
//

#include "stdafx.h"
#include "resource.h"
#include "streamstorage.h"


/////////////////////////////////////////////////////////////////////////////
// ShowItemPropertiesDialog dialog

class ShowItemPropertiesDialog : public CDialog
{
// Construction
public:
	ShowItemPropertiesDialog(StreamStorage::SS_ITEM_INFO* pInfo,
							 CWnd* pParent = NULL);   // standard constructor
protected:
// Dialog Data
	//{{AFX_DATA(ShowItemPropertiesDialog)
	enum { IDD = IDD_SHOWITEMPROPERTIES };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// interface data
	StreamStorage::SS_ITEM_INFO*	m_pItemInfo;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ShowItemPropertiesDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	CString FileTimeToString(FILETIME* pFileTime);

	// Generated message map functions
	//{{AFX_MSG(ShowItemPropertiesDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHOWITEMPROPERTIESDIALOG_H__58D00E42_0FF5_11D2_B636_0000B45C6B2C__INCLUDED_)
