#ifndef DUMMY_H
#define DUMMY_H

#include "NTService.h"

//#############################################################################################
//		CLASS Dummy

class Dummy : public NTService
{
// Constructors/Destructors
public:
	Dummy ();

// Methods
protected:
	// Service main loop
	virtual void Run ();

};

#endif // DUMMY_H
