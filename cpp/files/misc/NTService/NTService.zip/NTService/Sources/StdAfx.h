// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#pragma warning (disable: 4786)

#define VC_EXTRALEAN			// Exclude rarely-used stuff from Windows headers
#include <windows.h>

#include <algorithm>
#include <fstream>
#include <map>
#include <string>
#include <vector>

using namespace std;

// To be ISO compliant
#define for if (0); else for
