#ifndef NTSERVICE_H
#define NTSERVICE_H

#include <string>
using namespace std;

#include <windows.h>

//#############################################################################################
//		CLASS NTService

class NTService
{
// Types
public:
	enum Action
	{
		e_install,
		e_run,
		e_report,
		e_uninstall,
	};

// Static data
protected:
	static NTService* m_pTheService;

// Static member functions
protected:
	// The service entry point
	static void WINAPI ServiceMain (
		DWORD dwArgc,
		LPTSTR* lpszArgv
	);
	
	// The command handler
	static void WINAPI Handler (
		DWORD fdwControl
	);

// Constructors/destructors
protected:
	// no default constructor available
	NTService ();

public:
	NTService (
		const string& serviceName,
		const string& serviceDisplayName,
		unsigned int majorVersion = 1,
		unsigned int minorVersion = 0
	);

	virtual ~NTService ();

// Methods
public:
	// Main interface
	bool Start (
		Action whatToDo = e_run,
		bool verbose = true
	);

	// Returns the service status
	int Result ()
		{ return static_cast<int> (m_status.dwWin32ExitCode); }

protected:
	// Installs the service
	bool Install ();

	// Uninstalls the service
	bool Uninstall ();

	// Checks wether the service has been installed
	bool IsInstalled ();

	// Initializes the service
	bool Initialize ();

	// Starts the service
	bool StartService ();

	// Updates the service state
	void SetStatus (
		DWORD state
	);

	// Service main loop
	virtual void Run ();

	// ***** virtual command handlers *****

	// Initialization handler
	virtual bool OnInit ();
	
	// Stop request handler
	virtual void OnStop ();
	
	// Interrogate request handler
	virtual void OnInterrogate ();
	
	// Pause request handler
	virtual void OnPause ();
	
	// Continue request handler
	virtual void OnContinue ();
	
	// Shutdown request handler
	virtual void OnShutdown ();
	
	// User defined request handler
	virtual bool OnUserControl (
		DWORD fdwControl
	);

	// System logging helper
	void LogEvent (
		WORD type,
		DWORD id
	);

	// Tracing helper
	void Trace (
		const string& message
	);

// Data members
protected:
	SERVICE_STATUS				m_status;
	SERVICE_STATUS_HANDLE	m_serviceStatus;

	bool							m_run;

	string						m_serviceName;
	string						m_serviceDisplayName;
	int							m_majorVersion;
	int							m_minorVersion;
};

#endif // NTSERVICE_H
