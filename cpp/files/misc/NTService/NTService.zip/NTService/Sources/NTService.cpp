// precompiled headers
#include "StdAfx.h"

#include "NTService.h"

// ***** Standard *****
#include <stdio.h>
#include <tchar.h>

#include "messages.h"

//=============================================================================================
//		CONSTANTS

// registry keys
const string k_eventLogKey					=	TEXT ("SYSTEM\\CurrentControlSet\\Services\\EventLog\\Application\\");
const string k_messageFileEntry			=	TEXT ("EventMessageFile");
const string k_supportedEventsEntry		=	TEXT ("TypesSupported");

// user control command ids
const int k_minUserControlCode			=	128;
const int k_maxUserControlCode			=	256;

//#############################################################################################
//		CLASS NTService

//=============================================================================================
//		Static data
NTService* NTService::m_pTheService = NULL;

//=============================================================================================
//		Static members

//---------------------------------------------------------------------------------------------
// NTService::ServiceMain
// The service entry point
//
// RETURNS: -
//---------------------------------------------------------------------------------------------

void NTService::ServiceMain (
	DWORD dwArgc,		// -> number of arguments
	LPTSTR* lpszArgv)	// -> array of arguments
{
	// retrieve the C++ object
	NTService* pService = m_pTheService;
	pService -> Trace (TEXT ("Entering NTService::ServiceMain..."));

	// register the control request handler
	pService -> m_serviceStatus = ::RegisterServiceCtrlHandler (pService -> m_serviceName.c_str (), Handler);

	if (pService -> m_serviceStatus == 0)
	{
		// the service wasn't installed...
		pService -> m_serviceStatus = NULL;
		pService -> LogEvent (EVENTLOG_ERROR_TYPE, EVMSG_HANDLERNOTINSTALLED);
	}
	else
	{
		// start the service
		if (pService -> Initialize ())
		{
			pService -> m_status.dwWin32ExitCode = 0;
			pService -> m_status.dwCheckPoint = 0;
			pService -> m_status.dwWaitHint = 0;

			pService -> m_run = true;
			pService -> Run ();
		 }
	}

	// service is stopped now
	pService -> SetStatus (SERVICE_STOPPED);
	pService -> Trace (TEXT ("Exiting NTService::ServiceMain..."));

} // NTService::ServiceMain

//---------------------------------------------------------------------------------------------
// NTService::Handler
// The command handler
//
// RETURNS: -
//---------------------------------------------------------------------------------------------

void NTService::Handler (
	DWORD fdwControl)	// -> command id
{
	// retrieve the C++ object
	NTService* pService = m_pTheService;
	pService -> Trace (TEXT ("Entering NTService::Handler..."));
    
	switch (fdwControl)
	{
		case SERVICE_CONTROL_STOP:
		{
			pService -> Trace (TEXT ("Handling a SERVICE_CONTROL_STOP command..."));
			pService -> SetStatus (SERVICE_STOP_PENDING);
			pService -> OnStop ();
			pService -> m_run = false;
			pService -> LogEvent (EVENTLOG_INFORMATION_TYPE, EVMSG_STOPPED);
			break;
		}

		case SERVICE_CONTROL_PAUSE:
		{
			pService -> Trace (TEXT ("Handling a SERVICE_CONTROL_PAUSE command..."));
			pService -> OnPause ();
			break;
		}

		case SERVICE_CONTROL_CONTINUE:
		{
			pService -> Trace (TEXT ("Handling a SERVICE_CONTROL_CONTINUE command..."));
			pService -> OnContinue ();
			break;
		}

		case SERVICE_CONTROL_INTERROGATE:
		{
			pService -> Trace (TEXT ("Handling a SERVICE_CONTROL_INTERROGATE command..."));
			pService -> OnInterrogate ();
			break;
		}

		case SERVICE_CONTROL_SHUTDOWN:
		{
			pService -> Trace (TEXT ("Handling a SERVICE_CONTROL_SHUTDOWN command..."));
			pService -> OnShutdown ();
			break;
		}

		default:
		{
			TCHAR buffer [8];
			string msg = TEXT ("Handling a user command (fdwControl = ");
			msg +=_itot (fdwControl, buffer, 10);
			msg += TEXT (")...");
			pService -> Trace (msg);
		
			if ((fdwControl >= k_minUserControlCode) && (fdwControl <= k_maxUserControlCode))
			{
				if (! pService -> OnUserControl (fdwControl))
					pService -> LogEvent (EVENTLOG_WARNING_TYPE, EVMSG_UNEXPECTEDCMD);
			}
			else
				pService -> LogEvent (EVENTLOG_ERROR_TYPE, EVMSG_INVALIDCMD);

			break;
		}
	}

	// update current status
	::SetServiceStatus (pService -> m_serviceStatus, &pService -> m_status);
	pService -> Trace (TEXT ("Exiting NTService::Handler..."));

} // NTService::Handler

//=============================================================================================
//		Constructors/Destructors

//---------------------------------------------------------------------------------------------
// NTService::NTService
// Default constructor
//
// RETURNS: -
//---------------------------------------------------------------------------------------------

NTService::NTService (
	const string& serviceName,				// -> service name
	const string& serviceDisplayName,	// -> service display name
	unsigned int majorVersion,				// -> service major version
	unsigned int minorVersion)				// -> service minor version
{
	if (m_pTheService != NULL)
		return;

	Trace (TEXT ("Entering NTService::NTService..."));

	m_pTheService = this;

	// set up the service status 
	m_status.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
	m_status.dwCurrentState = SERVICE_DEMAND_START;
	m_status.dwControlsAccepted = SERVICE_ACCEPT_STOP;
	m_status.dwWin32ExitCode = NO_ERROR;
	m_status.dwServiceSpecificExitCode = 0;
	m_status.dwCheckPoint = 0;
	m_status.dwWaitHint = 0;

	m_serviceStatus = NULL;

	// other data
	m_serviceName = serviceName;
	m_serviceDisplayName = serviceDisplayName;
	m_majorVersion = majorVersion;
	m_minorVersion = minorVersion;

	Trace (TEXT ("Exiting NTService::NTService..."));

} // NTService::NTService

NTService::~NTService ()
{
	Trace (TEXT ("Entering NTService::~NTService..."));
	Trace (TEXT ("Exiting NTService::~NTService..."));

} // NTService::~NTService

//=============================================================================================
//		Methods

//---------------------------------------------------------------------------------------------
// NTService::Start
// Main interface
//
//	RETURNS: bool -> true if command was executed, false otherwise
//---------------------------------------------------------------------------------------------

bool NTService::Start (
	NTService::Action whatToDo,	// -> requested action
	bool verbose)						// -> user-interface flag
{
	Trace (TEXT ("Entering NTService::Start..."));
	bool success = false;

	switch (whatToDo)
	{
		case e_report:
		{
			Trace (TEXT ("Handling a REPORT request..."));
		
			if (verbose)
			{
				_tprintf (TEXT ("%s v. %d.%d\n"), m_serviceDisplayName.c_str (), m_majorVersion, m_minorVersion);
				_tprintf (TEXT ("Service is currently %s installed.\n"), IsInstalled () ? TEXT ("") : TEXT ("not"));
			}

			success = true;
			break;
		}

		case e_install:
		{
			Trace (TEXT ("Handling an INSTALL request..."));

			if (IsInstalled ())
			{
				if (verbose)
					_tprintf (TEXT ("The service <%s> is already installed.\n"), m_serviceDisplayName.c_str ());
		
				success = true;
			}
			else
			{
				success = Install ();
			
				if (verbose)
				{
					if (success)
						_tprintf (TEXT ("The service <%s> has been installed.\n"), m_serviceDisplayName.c_str ());
					else
						_tprintf (TEXT ("The service <%s> could not be installed.\n"), m_serviceDisplayName.c_str ());
				}
			}

			break;
		}

		case e_uninstall:
		{
			Trace (TEXT ("Handling an UNINSTALL request..."));

			if (! IsInstalled ())
			{
				if (verbose)
					_tprintf (TEXT ("The service <%s> is not installed.\n"), m_serviceDisplayName.c_str ());
	
				success = true;
			}
			else
			{
				success = Uninstall ();
					
				if (verbose)
				{
					if (success)
						_tprintf (TEXT ("The service <%s> has been removed.\n"), m_serviceDisplayName.c_str ());
					else
						_tprintf (TEXT ("The service <%s> could not be removed.\n"), m_serviceDisplayName.c_str ());
				}
			}

			break;
		}

		case e_run:
		{			
			Trace (TEXT ("Handling a RUN request..."));
			success = StartService ();
			break;
		}

		default:	
		{
			Trace (TEXT ("Handling an unknown request..."));

			if (verbose)
				_tprintf (TEXT ("Service <%s>: unrecognized command.\n"), m_serviceDisplayName.c_str ());

			success = true;
		}
	}

	Trace (TEXT ("Exiting NTService::Start..."));
	return success;

} // NTService::Start

//=============================================================================================
//		Methods - Protected interface

//---------------------------------------------------------------------------------------------
// NTService::Install
// Installs the service
//
//	RETURNS: bool -> true if service was installed, false otherwise
//---------------------------------------------------------------------------------------------

bool NTService::Install ()
{
	Trace (TEXT ("Entering NTService::Install..."));

	// get the executable file path
	TCHAR path [_MAX_PATH];
	if (::GetModuleFileName (NULL, path, sizeof (path)) == 0)
	{
		Trace (TEXT ("Exiting NTService::Install 'cause ::GetModuleFileName failed..."));
		return false;
	}

	// open the "Service Control Manager" on the local machine
	SC_HANDLE theManager = ::OpenSCManager (NULL, NULL, SC_MANAGER_ALL_ACCESS);

	if (theManager == NULL)
	{
		Trace (TEXT ("Exiting NTService::Install 'cause ::OpenSCManager failed..."));
		return false;
	}

	// create the service
	SC_HANDLE theService = ::CreateService (theManager, m_serviceName.c_str (), m_serviceDisplayName.c_str (),
															SERVICE_ALL_ACCESS, SERVICE_WIN32_OWN_PROCESS, SERVICE_DEMAND_START,
															SERVICE_ERROR_NORMAL, path, NULL, NULL, NULL, NULL, NULL);
	if (theService == NULL)
	{
		Trace (TEXT ("Exiting NTService::Install 'cause ::CreateService failed..."));
		::CloseServiceHandle (theManager);
		return false;
	}

	// register the service as a logging application
	// this will let Windows map the message strings on the supplied ids
	HKEY key = NULL;
	TCHAR keyName [_MAX_PATH];
	_tcscpy(keyName, k_eventLogKey.c_str ());
	_tcscat(keyName, m_serviceName.c_str ());

	if (::RegCreateKey (HKEY_LOCAL_MACHINE, keyName, &key) != ERROR_SUCCESS)
	{
		Trace (TEXT ("Exiting NTService::Install 'cause ::RegCreateKey failed..."));
		::CloseServiceHandle (theService);
		::CloseServiceHandle (theManager);
		return false;
	}
 
	// register the executable file as the message strings repository
	if (::RegSetValueEx (key, k_messageFileEntry.c_str (), 0, REG_EXPAND_SZ, (CONST BYTE*)path, (_tcslen(path) + 1) * sizeof (TCHAR)) != ERROR_SUCCESS)
	{
		Trace (TEXT ("Exiting NTService::Install 'cause ::RegSetValueEx (1) failed..."));
		::CloseServiceHandle (theService);
		::CloseServiceHandle (theManager);
		::RegCloseKey (key);
		return false;
	}

	// register the supported log events
	DWORD dwData = EVENTLOG_ERROR_TYPE | EVENTLOG_WARNING_TYPE | EVENTLOG_INFORMATION_TYPE;

	if (::RegSetValueEx(key, k_supportedEventsEntry.c_str (), 0, REG_DWORD, (CONST BYTE*)&dwData, sizeof(DWORD)) != ERROR_SUCCESS)
	{
		Trace (TEXT ("Exiting NTService::Install 'cause ::RegSetValueEx (2) failed..."));
		::CloseServiceHandle (theService);
		::CloseServiceHandle (theManager);
		::RegCloseKey (key);
		return false;
	}

	// free handles
	::CloseServiceHandle (theService);
	::CloseServiceHandle (theManager);
	::RegCloseKey (key);

	LogEvent (EVENTLOG_INFORMATION_TYPE, EVMSG_INSTALLED);
	Trace (TEXT ("Exiting NTService::Install..."));
	return true;

} // NTService::Install

//---------------------------------------------------------------------------------------------
// NTService::Uninstall
// Uninstalls the service
//
//	RETURNS: bool -> true if service was uninstalled, false otherwise
//---------------------------------------------------------------------------------------------

bool NTService::Uninstall ()
{
	Trace (TEXT ("Entering NTService::Uninstall..."));

	// open the "Service Control Manager" on the local machine
	SC_HANDLE theManager = ::OpenSCManager (NULL, NULL, SC_MANAGER_ALL_ACCESS);

	if (theManager == NULL)
	{
		Trace (TEXT ("Exiting NTService::Uninstall 'cause ::OpenSCManager failed..."));
		return false;
	}

	// prepare to remove the service
	SC_HANDLE theService = ::OpenService (theManager, m_serviceName.c_str (), DELETE);

	if (theService == NULL)
	{
		Trace (TEXT ("Exiting NTService::Uninstall 'cause ::OpenService failed..."));
		::CloseServiceHandle (theManager);
		return false;
	}

	// remove the service
	if (::DeleteService (theService))
		LogEvent (EVENTLOG_INFORMATION_TYPE, EVMSG_REMOVED);
	else
		LogEvent (EVENTLOG_INFORMATION_TYPE, EVMSG_NOTREMOVED);

	// free handles
	::CloseServiceHandle (theService);
	::CloseServiceHandle (theManager);

	Trace (TEXT ("Exiting NTService::Uninstall..."));
	return true;

} // NTService::Uninstall

//---------------------------------------------------------------------------------------------
// NTService::IsInstalled
// Checks wether the service has been installed
//
//	RETURNS: bool -> true if service is installed, false otherwise
//---------------------------------------------------------------------------------------------

bool NTService::IsInstalled ()
{
	Trace (TEXT ("Entering NTService::IsInstalled..."));

	// open the "Service Control Manager" on the local machine
	SC_HANDLE theManager = ::OpenSCManager (NULL, NULL, SC_MANAGER_ALL_ACCESS);

	if (theManager == NULL)
	{
		Trace (TEXT ("Exiting NTService::IsInstalled 'cause ::OpenSCManager failed..."));
		return false;
	}

	// prepare to remove the service
	SC_HANDLE theService = ::OpenService (theManager, m_serviceName.c_str (), SERVICE_QUERY_CONFIG);

	if (theService == NULL)
	{
		// the service does not exists
		Trace (TEXT ("Exiting NTService::IsInstalled 'cause ::OpenService failed..."));
		::CloseServiceHandle (theManager);
		return false;
	}

	// free handles
	::CloseServiceHandle (theService);
	::CloseServiceHandle (theManager);

	Trace (TEXT ("Exiting NTService::IsInstalled..."));
	return true;

} // NTService::IsInstalled

//---------------------------------------------------------------------------------------------
// NTService::Initialize
// Initializes the service
//
//	RETURNS: bool -> true if service was initialized, false otherwise
//---------------------------------------------------------------------------------------------

bool NTService::Initialize ()
{
	Trace (TEXT ("Entering NTService::Initialize..."));

	// start the initialization
	SetStatus (SERVICE_START_PENDING);
    
	// initialize
	bool success = OnInit (); 
    
	// set service final state
	m_status.dwWin32ExitCode = GetLastError ();

	if (! success)
	{
		Trace (TEXT ("Exiting NTService::Initialize 'cause OnInit failed..."));
		LogEvent (EVENTLOG_ERROR_TYPE, EVMSG_INITFAILED);
		SetStatus (SERVICE_STOPPED);
		return false;
	}
    
	LogEvent (EVENTLOG_INFORMATION_TYPE, EVMSG_STARTED);
	SetStatus (SERVICE_RUNNING);
 
	Trace (TEXT ("Exiting NTService::Initialize..."));
	return true;

} // NTService::Initialize

//---------------------------------------------------------------------------------------------
// NTService::StartService
// Starts the service
//
//	RETURNS: bool -> true if service was started, false otherwise
//---------------------------------------------------------------------------------------------

bool NTService::StartService ()
{
	Trace (TEXT ("Entering NTService::StartService..."));

	TCHAR serviceName [_MAX_PATH];
	_tcscpy (serviceName, m_serviceName.c_str ());

	SERVICE_TABLE_ENTRY services [] =
	{
		{ serviceName, NTService::ServiceMain },
		{ NULL, NULL }
	};

	if (! ::StartServiceCtrlDispatcher (services))
	{
		Trace (TEXT ("Exiting NTService::StartService 'cause ::StartServiceCtrlDispatcher failed..."));
		LogEvent (EVENTLOG_ERROR_TYPE, EVMSG_NOTSTARTED);
		return false;
	}

	Trace (TEXT ("Exiting NTService::StartService..."));
	return true;

} // NTService::StartService

//---------------------------------------------------------------------------------------------
// NTService::SetStatus
// Updates the service state
//
//	RETURNS: -
//---------------------------------------------------------------------------------------------

void NTService::SetStatus (
	DWORD state)	// -> new state
{
 	Trace (TEXT ("Entering NTService::StartService..."));

	m_status.dwCurrentState = state;
	::SetServiceStatus (m_serviceStatus, &m_status);

 	Trace (TEXT ("Exiting NTService::StartService..."));

} // NTService::SetStatus

//---------------------------------------------------------------------------------------------
// NTService::Run
// Service main loop
//
//	RETURNS: -
//---------------------------------------------------------------------------------------------

void NTService::Run ()
{
 	Trace (TEXT ("Entering NTService::Run..."));

	while (m_run)
		Sleep (1000);

 	Trace (TEXT ("Exiting NTService::Run..."));

} // NTService::Run

//=============================================================================================
//		Methods - Virtual command handlers

//---------------------------------------------------------------------------------------------
// NTService::OnInit
// Initialization handler
//
//	RETURNS: bool -> true if the initialization was successfull, false otherwise
//---------------------------------------------------------------------------------------------

bool NTService::OnInit ()
{
	Trace (TEXT ("Executing NTService::OnInit..."));
	return true;

} // NTService::OnInit

//---------------------------------------------------------------------------------------------
// NTService::OnStop
// Stop request handler
//
//	RETURNS: -
//---------------------------------------------------------------------------------------------

void NTService::OnStop ()
{
	Trace (TEXT ("Executing NTService::OnStop..."));

} // NTService::OnStop

//---------------------------------------------------------------------------------------------
// NTService::OnInterrogate
// Interrogate request handler
//
//	RETURNS: -
//---------------------------------------------------------------------------------------------

void NTService::OnInterrogate ()
{
	Trace (TEXT ("Executing NTService::OnInterrogate..."));

} // NTService::OnInterrogate

//---------------------------------------------------------------------------------------------
// NTService::OnPause
// Pause request handler
//
//	RETURNS: -
//---------------------------------------------------------------------------------------------

void NTService::OnPause ()
{
	Trace (TEXT ("Executing NTService::OnPause..."));

} // NTService::OnPause

//---------------------------------------------------------------------------------------------
// NTService::OnContinue
// Continue request handler
//
//	RETURNS: -
//---------------------------------------------------------------------------------------------

void NTService::OnContinue ()
{
	Trace (TEXT ("Executing NTService::OnContinue..."));

} // NTService::OnContinue

//---------------------------------------------------------------------------------------------
// NTService::OnShutdown
// Shutdown request handler
//
//	RETURNS: -
//---------------------------------------------------------------------------------------------

void NTService::OnShutdown ()
{
	Trace (TEXT ("Executing NTService::OnShutdown..."));

} // NTService::OnShutdown

//---------------------------------------------------------------------------------------------
// NTService::OnUserControl
// User defined request handler
//
//	RETURNS: -
//---------------------------------------------------------------------------------------------

bool NTService::OnUserControl (
	DWORD fdwControl)	// -> command id
{
	Trace (TEXT ("Executing NTService::OnShutdown..."));
	return false;

} // NTService::OnUserControl

//---------------------------------------------------------------------------------------------
// NTService::LogEvent
// Logging helper
//
//	RETURNS: -
//---------------------------------------------------------------------------------------------

void NTService::LogEvent (
	WORD type,	// event type
	DWORD id)	// event id
{
	// prepare the event message prologue
	TCHAR description [_MAX_PATH];
	_stprintf(description, TEXT ("%s v. %d.%d"), m_serviceDisplayName.c_str (), m_majorVersion, m_minorVersion);

	// create the strings table
	LPCTSTR strings [1];
	strings [0] = description;

	// open the event log
	HANDLE event = ::RegisterEventSource (NULL, m_serviceName.c_str ());

	if (event != NULL)
	{
		// write the event message
		::ReportEvent (event, type, 0, id, NULL, 1, 0, strings, NULL);
		::DeregisterEventSource (event);
	}

} // NTService::LogEvent

//---------------------------------------------------------------------------------------------
// NTService::Trace
// Tracing helper
//
//	RETURNS: -
//---------------------------------------------------------------------------------------------

void NTService::Trace (
	const string& message)	// tracing message
{
	string output = m_serviceDisplayName + TEXT (" - ") + message + TEXT ("\n");
	::OutputDebugString (output.c_str ());

} // NTService::Trace
