// precompiled headers
#include "StdAfx.h"

#include "Dummy.h"

// ***** Standard *****
#include <stdio.h>
#include <tchar.h>

//---------------------------------------------------------------------------------------------
// ::main
// The service start-up routine
//
// RETURNS: int -> the exit code of the service
//---------------------------------------------------------------------------------------------

int main (
	int argc,		// -> number of arguments
	char* argv[])	// -> array of arguments
{
	// create the service object
	Dummy service;
	NTService::Action action = NTService::e_run;

	if ((argc > 1) && ((*argv [1] == '-') || (*argv [1] == '/')))
	{
		if (*(argv [1] + 1) == 'i')
			action = NTService::e_install;
		else if (*(argv [1] + 1) == 'u')
			action = NTService::e_uninstall;
		else if (*(argv [1] + 1) == 's')
			action = NTService::e_report;
		else if ((*(argv [1] + 1) == 'h') || (*(argv [1] + 1) == '?'))
		{
			_tprintf (TEXT ("\n"));
			_tprintf (TEXT ("use the following flags:\n"));
			_tprintf (TEXT  ("\n"));
			_tprintf (TEXT ("   -i to install the service\n"));
			_tprintf (TEXT ("   -u to uninstall the service\n"));
			_tprintf (TEXT ("   -s to show the service status\n"));
			_tprintf (TEXT ("\n"));
			return 0;
		}
	}

	// start the service
	int error = 0;

	if (! service.Start (action))
		error = ::GetLastError ();
	else 
		error = service.Result ();
	
	return error;
}
