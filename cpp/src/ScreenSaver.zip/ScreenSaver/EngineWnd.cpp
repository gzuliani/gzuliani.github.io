// EngineWnd.cpp : implementation file
//

#include "stdafx.h"

#include "resource.h"
#include "EngineWnd.h"


#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// EngineWnd

EngineWnd::EngineWnd(UINT timeout, BOOL bAutoDelete)
{
	m_timer = EW_TIMER_ID;
	m_timeout = timeout;
	m_bAutoDelete = bAutoDelete;
}

BOOL EngineWnd::Create(CWnd* pParentWnd)
{
	CString className;
	BOOL creation = FALSE;

	// avoid cursor painting
	HCURSOR	NullCursor = AfxGetApp()->LoadCursor(IDC_NULLCURSOR);
   	className = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW,NullCursor);

	if (pParentWnd != NULL)
	{
		// create a child window
		CRect wnd;
		pParentWnd->GetClientRect(wnd);

		creation = CWnd::Create(className, _T("ScreenSaver"),
								WS_CHILD | WS_VISIBLE,
								wnd, pParentWnd, (UINT)1);
	}
	else
	{
		// create a top window
		CRect wnd;
		CWnd::GetDesktopWindow()->GetClientRect(wnd);

		creation = CWnd::CreateEx(WS_EX_TOPMOST,
								  className, _T("ScreenSaver"),
								  WS_POPUP | WS_VISIBLE,
								  wnd.left, wnd.top, wnd.Width(), wnd.Height(),
								  NULL, (HMENU)NULL);
	}

	// start timer
	if (creation)
		m_timerID = SetTimer(m_timer,m_timeout,NULL);
	
	return creation;
}

BOOL EngineWnd::DestroyWindow() 
{
	if (m_timerID != 0)
		KillTimer(m_timerID);
	
	return CWnd::DestroyWindow();
}

void EngineWnd::PostNcDestroy() 
{
	if (m_bAutoDelete)
		delete this;
}

EngineWnd::~EngineWnd()
{
}

BEGIN_MESSAGE_MAP(EngineWnd, CWnd)
	//{{AFX_MSG_MAP(EngineWnd)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_LBUTTONDOWN()
	ON_WM_MBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_KEYDOWN()
	ON_WM_ACTIVATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// EngineWnd message handlers

void EngineWnd::OnPaint() 
{
	CPaintDC dc(this);

	// paint the background
	CRect rect;
	GetClientRect(rect);
	dc.SelectStockObject(BLACK_BRUSH);
	dc.Rectangle(rect);
}

void EngineWnd::OnTimer(UINT nIDEvent) 
{
	if (nIDEvent == m_timerID)
	{
		CRect wnd;
		GetClientRect(wnd);
	}
	else
		CWnd::OnTimer(nIDEvent);
}


