// ScreenSaver.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"

#include "ScreenSaver.h"
#include "ConfigDlg.h"
#include "EngineWnd.h"
#include "FrontWnd.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CScreenSaverApp

BEGIN_MESSAGE_MAP(CScreenSaverApp, CWinApp)
	//{{AFX_MSG_MAP(CScreenSaverApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScreenSaverApp construction

CScreenSaverApp::CScreenSaverApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// CScreenSaverApp initialization

BOOL CScreenSaverApp::InitInstance()
{
	// ====================
	// command line options:

	// p -> preview
	// c -> configure
	// s -> start screen saver

	CString cmdLine = m_lpCmdLine;
	
	if (cmdLine.IsEmpty())
		cmdLine = _T("s");
//		return FALSE;
	
	// throw away the option char
	if ((cmdLine[0] == _T('/'))
		|| (cmdLine[0] == _T('-')))
		cmdLine = cmdLine.Mid(1);

	if (cmdLine[0] == _T('c'))
	{
		// open configuration dialog
		ConfigDlg dlg;
		dlg.DoModal();
		return FALSE;
	}
	
	if (cmdLine[0] == _T('p'))
	{
		// open configuration dialog
		cmdLine = cmdLine.Mid(1);
		CWnd* pParent = CWnd::FromHandle((HWND)atol(cmdLine));

		if (pParent == NULL)	
			return FALSE;

		if ((m_pMainWnd = new EngineWnd) == NULL)
			return FALSE;
	
		if (!((EngineWnd*)m_pMainWnd)->Create(pParent))
			return FALSE;

		return TRUE;
	}
	
	if (cmdLine[0] == _T('s'))
	{	
		// start screen saver
		if ((m_pMainWnd = new FrontWnd(10)) == NULL)
			return FALSE;
	
		if (!((FrontWnd*)m_pMainWnd)->Create())
			return FALSE;

//		m_pMainWnd->Invalidate();
//		m_pMainWnd->UpdateWindow();
		return TRUE;
	}

	// something gone wrong...
	return FALSE;
}



/////////////////////////////////////////////////////////////////////////////
// The one and only CScreenSaverApp object

CScreenSaverApp theApp;

