// ConfigDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ScreenSaver.h"
#include "ConfigDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// ConfigDlg dialog

ConfigDlg::ConfigDlg(CWnd* pParent /*=NULL*/)
	: CDialog(ConfigDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(ConfigDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void ConfigDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ConfigDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ConfigDlg, CDialog)
	//{{AFX_MSG_MAP(ConfigDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ConfigDlg message handlers

BOOL ConfigDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	return TRUE;
}

void ConfigDlg::OnOK() 
{
	CDialog::OnOK();
}
