// FrontWnd.h: interface for the FrontWnd class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FRONTWND_H__3C8D39A7_25F1_11D2_B636_0000B45C6B2C__INCLUDED_)
#define AFX_FRONTWND_H__3C8D39A7_25F1_11D2_B636_0000B45C6B2C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


#include "EngineWnd.h"


/////////////////////////////////////////////////////////////////////////////
// FrontWnd window

class FrontWnd : public EngineWnd  
{
public:
	FrontWnd(UINT timeout = EW_TIMER_TICK,
			 BOOL bAutoDelete = TRUE);
	virtual ~FrontWnd();
	
	BOOL Create(CWnd* pParentWnd = NULL);

protected:
	CPoint m_LastMouseMove;

	//{{AFX_MSG(FrontWnd)
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnClose();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_FRONTWND_H__3C8D39A7_25F1_11D2_B636_0000B45C6B2C__INCLUDED_)
