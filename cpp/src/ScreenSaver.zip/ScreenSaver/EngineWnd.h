// EngineWnd.h : header file
//

#if !defined(AFX_ENGINEWND_H__3C8D39A7_25F1_11D2_B636_0000B45C6B2C__INCLUDED_)
#define AFX_ENGINEWND_H__3C8D39A7_25F1_11D2_B636_0000B45C6B2C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000



#include "stdafx.h"

/////////////////////////////////////////////////////////////////////////////
// EngineWnd window

#define EW_TIMER_ID		1
#define EW_TIMER_TICK	100


class EngineWnd : public CWnd
{
// Construction
public:
	EngineWnd(UINT timeout = EW_TIMER_TICK,
			  BOOL bAutoDelete = TRUE);
	
	virtual ~EngineWnd();
	
	BOOL Create(CWnd* pParentWnd);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(EngineWnd)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
protected:
	UINT m_timer;
	UINT m_timeout;
	UINT m_timerID;
	BOOL m_bAutoDelete;

	// Generated message map functions
protected:
	//{{AFX_MSG(EngineWnd)
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_ENGINEWND_H__3C8D39A7_25F1_11D2_B636_0000B45C6B2C__INCLUDED_)
