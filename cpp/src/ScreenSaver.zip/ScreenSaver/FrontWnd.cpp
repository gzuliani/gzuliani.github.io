// FrontWnd.cpp: implementation of the FrontWnd class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "FrontWnd.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

FrontWnd::FrontWnd(UINT timeout, BOOL bAutoDelete)
	: EngineWnd(timeout,bAutoDelete)
{
	m_timeout = timeout;
	m_bAutoDelete = bAutoDelete;
	m_LastMouseMove = CPoint(-1,-1);
}

BOOL FrontWnd::Create(CWnd* pParentWnd)
{
	BOOL res = EngineWnd::Create(pParentWnd);
	return res;
}

void FrontWnd::OnClose() 
{
	EngineWnd::OnClose();
}

FrontWnd::~FrontWnd()
{
}

BEGIN_MESSAGE_MAP(FrontWnd, EngineWnd)
	//{{AFX_MSG_MAP(FrontWnd)
	ON_WM_ACTIVATE()
	ON_WM_LBUTTONDOWN()
	ON_WM_MBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_KEYDOWN()
	ON_WM_CLOSE()
	ON_WM_SETCURSOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////
// Message handlers

void FrontWnd::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
	CWnd::OnActivate(nState, pWndOther, bMinimized);

	if (nState == WA_INACTIVE)
		PostMessage(WM_CLOSE);
}

void FrontWnd::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CWnd::OnLButtonDown(nFlags, point);
	PostMessage(WM_CLOSE);
}

void FrontWnd::OnMButtonDown(UINT nFlags, CPoint point) 
{
	CWnd::OnMButtonDown(nFlags, point);
	PostMessage(WM_CLOSE);
}

void FrontWnd::OnRButtonDown(UINT nFlags, CPoint point) 
{
	CWnd::OnRButtonDown(nFlags, point);
	PostMessage(WM_CLOSE);
}

void FrontWnd::OnMouseMove(UINT nFlags, CPoint point) 
{
	CWnd::OnMouseMove(nFlags, point);

	// store mouse position
	if (m_LastMouseMove == CPoint(-1,-1))
		m_LastMouseMove = point;
	
	// mouse really moved?
	if (m_LastMouseMove != point)
		PostMessage(WM_CLOSE);
}

void FrontWnd::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
	PostMessage(WM_CLOSE);
}

BOOL FrontWnd::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	SetCursor(NULL);
	return EngineWnd::OnSetCursor(pWnd, nHitTest, message);
}
