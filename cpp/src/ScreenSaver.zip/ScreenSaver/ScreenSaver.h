// ScreenSaver.h : main header file for the PROVA application
//

#if !defined(AFX_PROVA_H__3C8D399C_25F1_11D2_B636_0000B45C6B2C__INCLUDED_)
#define AFX_PROVA_H__3C8D399C_25F1_11D2_B636_0000B45C6B2C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


/////////////////////////////////////////////////////////////////////////////
// CScreenSaverApp:
// See ScreenSaver.cpp for the implementation of this class
//

class CScreenSaverApp : public CWinApp
{
public:
	CScreenSaverApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScreenSaverApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CScreenSaverApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROVA_H__3C8D399C_25F1_11D2_B636_0000B45C6B2C__INCLUDED_)

