// ComSetupDialog.cpp : implementation file
//

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#include "ComSetupDialog.h"


// ==============================
// baud rates code<->name tables

static DWORD BAUD_RATES[] = 
	{	
		CBR_110,		CBR_300,		CBR_600,		CBR_1200,
		CBR_2400,		CBR_4800,		CBR_9600,		CBR_14400,
		CBR_19200,		CBR_38400,		CBR_56000,		CBR_57600,
		CBR_115200,		CBR_128000,		CBR_256000,
	};

static const TCHAR* BAUD_RATE_NAMES[] = 
	{
		_T("110"),		_T("300"),		_T("600"),		_T("1200"),
		_T("2400"),		_T("4800"),		_T("9600"),		_T("14400"),
		_T("19200"),	_T("38400"),	_T("56000"),	_T("57600"),
		_T("115200"),	_T("128000"),	_T("256000"), 
	};

static int BAUD_RATE_ITEMS = sizeof(BAUD_RATE_NAMES)/sizeof(const TCHAR*);


/////////////////////////////////////////////////////////////////////////////
// ComSetupDialog dialog

ComSetupDialog::ComSetupDialog(CString* pPortName,
								DWORD* pBaudRate,
								BYTE* pParity,
								BYTE* pByteSize,
								BYTE* pStopBits,
								BOOL* pRtsCts,
								BOOL* pDtrDsr,
								BOOL* pXonXoff,
								CWnd* pParent /*=NULL*/)
	: CDialog(ComSetupDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(ComSetupDialog)
	//}}AFX_DATA_INIT
	m_PortName = *pPortName;

	m_pBaudRate = pBaudRate;
	m_pParity = pParity;
	m_pByteSize = pByteSize;
	m_pStopBits = pStopBits;

	m_pRtsCts = pRtsCts;
	m_pDtrDsr = pDtrDsr;
	m_pXonXoff = pXonXoff;
}

void ComSetupDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ComSetupDialog)
	DDX_Control(pDX, IDC_BAUDRATE, m_ctrlBaudRate);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(ComSetupDialog, CDialog)
	//{{AFX_MSG_MAP(ComSetupDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// ComSetupDialog message handlers

BOOL ComSetupDialog::OnInitDialog() 
{
	// append com port name to window title
	if (!m_PortName.IsEmpty())
	{
		CString title;
		GetWindowText(title);
		title += _T(" - ");
		title += m_PortName;
		SetWindowText(title);
	}

	// ==============================
	// set parity buttons
	switch (*m_pParity)
	{
		case EVENPARITY:
			((CButton*)GetDlgItem(IDC_EVEN))->SetCheck(1);
			break;
		case MARKPARITY:
			((CButton*)GetDlgItem(IDC_MARK))->SetCheck(1);
			break;
		case NOPARITY:
			((CButton*)GetDlgItem(IDC_NONE))->SetCheck(1);
			break;
		case ODDPARITY:
			((CButton*)GetDlgItem(IDC_ODD))->SetCheck(1);
			break;
		case SPACEPARITY:
			((CButton*)GetDlgItem(IDC_SPACE))->SetCheck(1);
			break;
		default:
			((CButton*)GetDlgItem(IDC_NONE))->SetCheck(1);
			break;
	}


	// ==============================
	// set data word width buttons
	switch (*m_pByteSize)
	{
		case 4:
			((CButton*)GetDlgItem(IDC_DATA4))->SetCheck(1);
			break;
		case 5:
			((CButton*)GetDlgItem(IDC_DATA5))->SetCheck(1);
			break;
		case 6:
			((CButton*)GetDlgItem(IDC_DATA6))->SetCheck(1);
			break;
		case 7:
			((CButton*)GetDlgItem(IDC_DATA7))->SetCheck(1);
			break;
		case 8:
			((CButton*)GetDlgItem(IDC_DATA8))->SetCheck(1);
			break;
		default:
			((CButton*)GetDlgItem(IDC_DATA8))->SetCheck(1);
			break;
	}


	// ==============================
	// set stop bits buttons
	switch (*m_pStopBits)
	{
		case ONESTOPBIT:
			((CButton*)GetDlgItem(IDC_STOP1))->SetCheck(1);
			break;
		case ONE5STOPBITS:
			((CButton*)GetDlgItem(IDC_STOP15))->SetCheck(1);
			break;
		case TWOSTOPBITS:
			((CButton*)GetDlgItem(IDC_STOP2))->SetCheck(1);
			break;
		default:
			((CButton*)GetDlgItem(IDC_STOP1))->SetCheck(1);
			break;
	}


	// ==============================
	// set handshake buttons
	((CButton*)GetDlgItem(IDC_DTRDSR))->SetCheck(*m_pDtrDsr);
	((CButton*)GetDlgItem(IDC_RTSCTS))->SetCheck(*m_pRtsCts);
	((CButton*)GetDlgItem(IDC_XONXOFF))->SetCheck(*m_pXonXoff);


	CDialog::OnInitDialog();
	

	// ==============================
	// load baud rates
	for (int i=0; i<BAUD_RATE_ITEMS; i++)
	{
		m_ctrlBaudRate.AddString(BAUD_RATE_NAMES[i]);
		m_ctrlBaudRate.SetItemData(i,BAUD_RATES[i]);

		if (BAUD_RATES[i] == *m_pBaudRate)
			m_ctrlBaudRate.SetCurSel(i);
	}

	if ((m_ctrlBaudRate.GetCurSel() == CB_ERR)
		&& (m_ctrlBaudRate.GetCount() > 0))
		m_ctrlBaudRate.SetCurSel(0);

	return TRUE;
}

void ComSetupDialog::OnOK() 
{
	// ==============================
	// retrieve parity code
	if (((CButton*)GetDlgItem(IDC_EVEN))->GetCheck() == 1)
		*m_pParity = EVENPARITY;
	if (((CButton*)GetDlgItem(IDC_MARK))->GetCheck() == 1)
		*m_pParity = MARKPARITY;
	if (((CButton*)GetDlgItem(IDC_NONE))->GetCheck() == 1)
		*m_pParity = NOPARITY;
	if (((CButton*)GetDlgItem(IDC_ODD))->GetCheck() == 1)
		*m_pParity = ODDPARITY;
	if (((CButton*)GetDlgItem(IDC_SPACE))->GetCheck() == 1)
		*m_pParity = SPACEPARITY;


	// ==============================
	// retrieve data word width code
	if (((CButton*)GetDlgItem(IDC_DATA4))->GetCheck() == 1)
		*m_pByteSize = 4;
	if (((CButton*)GetDlgItem(IDC_DATA5))->GetCheck() == 1)
		*m_pByteSize = 5;
	if (((CButton*)GetDlgItem(IDC_DATA6))->GetCheck() == 1)
		*m_pByteSize = 6;
	if (((CButton*)GetDlgItem(IDC_DATA7))->GetCheck() == 1)
		*m_pByteSize = 7;
	if (((CButton*)GetDlgItem(IDC_DATA8))->GetCheck() == 1)
		*m_pByteSize = 8;


	// ==============================
	// retrieve stop bits code
	if (((CButton*)GetDlgItem(IDC_STOP1))->GetCheck() == 1)
		*m_pStopBits = ONESTOPBIT;
	if (((CButton*)GetDlgItem(IDC_STOP15))->GetCheck() == 1)
		*m_pStopBits = ONE5STOPBITS;
	if (((CButton*)GetDlgItem(IDC_STOP2))->GetCheck() == 1)
		*m_pStopBits = TWOSTOPBITS;


	// ==============================
	// retrieve handshake flags
	*m_pDtrDsr = (((CButton*)GetDlgItem(IDC_DTRDSR))->GetCheck() == 1);
	*m_pRtsCts = (((CButton*)GetDlgItem(IDC_RTSCTS))->GetCheck() == 1);
	*m_pXonXoff = (((CButton*)GetDlgItem(IDC_XONXOFF))->GetCheck() == 1);
	
	
	// ==============================
	// retrieve baud rate code
	int selBaudRate = m_ctrlBaudRate.GetCurSel();
	if (selBaudRate != CB_ERR)
		*m_pBaudRate = m_ctrlBaudRate.GetItemData(selBaudRate);


	CDialog::OnOK();
}

