// ComTransferSendDialog.cpp : implementation file
//

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#include "ComTransferSendDialog.h"


/////////////////////////////////////////////////////////////////////////////
// ComTransferSendDialog dialog

#define FTSD_CLOCK_ID			1
#define FTSD_CLOCK_RESOLUTION	1000

ComTransferSendDialog::ComTransferSendDialog(ComTransfer* pComTransfer, CWnd* pParent /*=NULL*/)
	: CDialog(ComTransferSendDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(ComTransferSendDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_TimerID = 0;
	m_pComTransfer = pComTransfer;
}

void ComTransferSendDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ComTransferSendDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ComTransferSendDialog, CDialog)
	//{{AFX_MSG_MAP(ComTransferSendDialog)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ComTransferSendDialog message handlers

BOOL ComTransferSendDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// initialize the dialog data
	m_BytesToSend = m_pComTransfer->BytesToSend();
	SetDlgItemInt(IDC_TOTAL,m_BytesToSend);
	SetDlgItemInt(IDC_SENT,m_pComTransfer->SentBytes());
	SetDlgItemInt(IDC_TOSEND,m_pComTransfer->BytesLeftToSend());

	// set file name or hide the control
	CString filename = m_pComTransfer->SendingFileName();

	if (!filename.IsEmpty())
		SetDlgItemText(IDC_FILENAME,filename);
	else
	{
		GetDlgItem(IDC_FILENAME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_FILENAME_LABEL)->ShowWindow(SW_HIDE);
	}

	// initialize the dialog clock
	m_StartTime = CTime::GetCurrentTime();
	m_TimerID = SetTimer(FTSD_CLOCK_ID,FTSD_CLOCK_RESOLUTION,NULL);

	return TRUE;
}

void ComTransferSendDialog::OnTimer(UINT nIDEvent) 
{
	// file successfully sent?
	if (!m_pComTransfer->IsSending())
	{
		KillTimer(m_TimerID);
		PostMessage(WM_CLOSE);
		return;
	}
	
	if (nIDEvent == (UINT)m_TimerID)
	{
		// time to update the dialog data
		DWORD SentBytes = m_pComTransfer->SentBytes();
		DWORD BytesLeftToSend = m_pComTransfer->BytesLeftToSend();
		SetDlgItemInt(IDC_SENT,SentBytes);
		SetDlgItemInt(IDC_TOSEND,BytesLeftToSend);
		((CProgressCtrl*)GetDlgItem(IDC_PROGRESSBAR))->SetPos((int)((double)SentBytes/m_BytesToSend * 100));

		// update the timer
		CTime CurrTime = CTime::GetCurrentTime();
		CTimeSpan ElapsedTime = CurrTime - m_StartTime;
		SetDlgItemText(IDC_ELAPSED,ElapsedTime.Format(_T("%H:%M:%S")));

		// how many time to the end of the process?
		TCHAR buffer[16];
		LONG ElapsedSeconds = ElapsedTime.GetTotalSeconds();
		LONG EstimatedSeconds = (SentBytes != 0) ? (LONG)((double)ElapsedSeconds*m_BytesToSend/SentBytes): 0;

		LONG EstimatedHours = EstimatedSeconds / 3600;
		LONG EstimatedMinutes = (EstimatedSeconds / 60) % 60;
		EstimatedSeconds %= 60;

		if (EstimatedHours > 99)
			_stprintf(buffer,_T("--:--:--"));
		else
			_stprintf(buffer,_T("%02d:%02d:%02d"),EstimatedHours,EstimatedMinutes,EstimatedSeconds);

		SetDlgItemText(IDC_ESTIMATED,buffer);
	}
	else
		CDialog::OnTimer(nIDEvent);
}

void ComTransferSendDialog::OnCancel() 
{
	// user abortion
	m_pComTransfer->AbortTransfer();
	KillTimer(m_TimerID);
	CDialog::OnOK();
}
