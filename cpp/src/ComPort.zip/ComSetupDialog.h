#if !defined(AFX_OMSETUPDIALOG_H__11691CE1_DDDC_11D1_B636_444553540000__INCLUDED_)
#define AFX_OMSETUPDIALOG_H__11691CE1_DDDC_11D1_B636_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ComSetupDialog.h : header file
//

#include "resource.h"


/////////////////////////////////////////////////////////////////////////////
// ComSetupDialog dialog

class ComSetupDialog : public CDialog
{
// Construction
public:
	ComSetupDialog(CString* pPortName,
					DWORD* pBaudRate,
					BYTE* pParity,
					BYTE* pByteSize,
					BYTE* pStopBits,
					BOOL* pRtsCts,
					BOOL* pDtrDsr,
					BOOL* pXonXoff,
					CWnd* pParent = NULL);

protected:
// Dialog Data
	//{{AFX_DATA(ComSetupDialog)
	enum { IDD = IDD_COMPORT_SETUP };
	CComboBox	m_ctrlBaudRate;
	//}}AFX_DATA

	// interface data
	CString	m_PortName;

	DWORD*	m_pBaudRate;
	BYTE*	m_pParity;
	BYTE*	m_pByteSize;
	BYTE*	m_pStopBits;
	
	BOOL*	m_pRtsCts;
	BOOL*	m_pDtrDsr;
	BOOL*	m_pXonXoff;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ComSetupDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ComSetupDialog)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OMSETUPDIALOG_H__11691CE1_DDDC_11D1_B636_444553540000__INCLUDED_)
