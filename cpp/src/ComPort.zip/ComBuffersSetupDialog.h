#if !defined(AFX_COMBUFFERSSETUPDIALOG_H__D89C7E41_DEB0_11D1_B636_444553540000__INCLUDED_)
#define AFX_COMBUFFERSSETUPDIALOG_H__D89C7E41_DEB0_11D1_B636_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ComBuffersSetupDialog.h : header file
//

#include "comport.h"
#include "resource.h"


/////////////////////////////////////////////////////////////////////////////
// ComBuffersSetupDialog dialog

class ComBuffersSetupDialog : public CDialog
{
// Construction
public:
	ComBuffersSetupDialog(ComPort* pComPort, CWnd* pParent = NULL);   // standard constructor

protected:
// Dialog Data
	//{{AFX_DATA(ComBuffersSetupDialog)
	enum { IDD = IDD_COMPORT_SETBUFFERS };
	DWORD	m_InputSize;
	DWORD	m_OutputSize;
	//}}AFX_DATA

	// interface data
	ComPort* m_pComPort;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ComBuffersSetupDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ComBuffersSetupDialog)
	afx_msg void OnApply();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMBUFFERSSETUPDIALOG_H__D89C7E41_DEB0_11D1_B636_444553540000__INCLUDED_)
