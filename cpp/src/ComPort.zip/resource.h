//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ComPort.rc
//
#define IDD_COMPORT_SETUP               135
#define IDD_COMPORT_SETBUFFERS          136
#define IDD_COMTRANSFER_SEND            137
#define IDD_COMTRANSFER_RECEIVE         138
#define IDD_COMTRANSFER_RECEIVE_SIZEUNKNOWN 139
#define IDC_PORT                        1000
#define IDC_DATA5                       1001
#define IDC_DATA7                       1002
#define IDC_DATA8                       1003
#define IDC_DATA4                       1004
#define IDC_DATA6                       1005
#define IDC_RTSCTS                      1006
#define IDC_BAUDRATE                    1007
#define IDC_APPLY                       1008
#define IDC_ACTUALINPUT                 1009
#define IDC_ACTUALOUTPUT                1010
#define IDC_INPUT                       1011
#define IDC_DTRDSR                      1012
#define IDC_OUTPUT                      1013
#define IDC_XONXOFF                     1014
#define IDC_MAXINPUT                    1015
#define IDC_STOP15                      1016
#define IDC_MAXOUTPUT                   1017
#define IDC_PROGRESSBAR                 1018
#define IDC_STOP1                       1019
#define IDC_FILENAME                    1020
#define IDC_STOP2                       1021
#define IDC_TOTAL                       1022
#define IDC_ODD                         1023
#define IDC_SENT                        1024
#define IDC_NONE                        1025
#define IDC_TOSEND                      1026
#define IDC_SPACE                       1027
#define IDC_ELAPSED                     1028
#define IDC_EVEN                        1029
#define IDC_ESTIMATED                   1030
#define IDC_RECEIVED                    1031
#define IDC_MARK                        1032
#define IDC_TORECEIVE                   1034
#define IDC_FILENAME_LABEL              1035
#define IDS_CBSD_COM_NOT_AVAILABLE      2000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
