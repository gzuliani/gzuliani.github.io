// ComTransfer.cpp: implementation of the ComTransfer class.
//
//////////////////////////////////////////////////////////////////////

#include "ComTransfer.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#include "ComTransferSendDialog.h"
#include "ComTransferReceiveDialog.h"
#include "ComTransferReceiveSizeUnknownDialog.h"

/////////////////////////////////////////////////////////////////////////////
// ComTransfer

// ==============================
// construction
// ==============================

ComTransfer::ComTransfer(ComPort* pPort)
{
	m_pPort = pPort;
	m_pPort->SetEventHandler(EventHandler,(DWORD)this);

	m_pModelessDialog = NULL;

	m_RxInProgress = FALSE;
	m_TxInProgress = FALSE;
	m_TxSuccessfull = FALSE;
	m_RxSuccessfull = FALSE;
	m_ReceivingFile = FALSE;

	m_pTxBuffer = NULL;	
	m_FreeTxBuffer = FALSE;
	m_TxBufferSize = 0;	
	m_TxBufferPos = 0;	

	m_pRxBuffer = NULL;	
	m_IsRxUnbound = FALSE;
	m_RxBufferSize = 0;	
	m_RxBufferPos = 0;	
	m_RxBufferPageSize = 4096;
	m_pUserBuffer = NULL;
	m_ppUserBuffer = NULL;
	m_pUserBufferLength = NULL;

	m_TxFileName = _T("");
	m_RxFileName = _T("");
}

ComTransfer::~ComTransfer()
{
	// any modeless dialog still in memory?
	if (m_pModelessDialog != NULL)
		delete m_pModelessDialog;
}



// ==============================
// main interface
// ==============================

void ComTransfer::AbortTransfer()
{
	if (m_TxInProgress)
	{
		// stop file transfer
		CloseTx();
		m_TxSuccessfull = FALSE;
		return;
	}

	if (m_RxInProgress)
	{
		// stop file transfer
		CloseRx();
		m_RxSuccessfull = FALSE;
		return;
	}
}

BOOL ComTransfer::Send(LPCTSTR pFileName,
					   BOOL OpenDialog /*= FALSE*/,
					   BOOL OpenModal /*= TRUE*/)
{
	// try to open the file
	HANDLE FileToSend = CreateFile(pFileName,
								   GENERIC_READ,
								   FILE_SHARE_READ,
								   NULL,
								   OPEN_EXISTING,
								   FILE_ATTRIBUTE_NORMAL,
								   NULL);

	if (FileToSend == INVALID_HANDLE_VALUE)
		return FALSE;

	// file opened, try to send it...
	BOOL result = Send(FileToSend,pFileName,OpenDialog,OpenModal);
	CloseHandle(FileToSend);

	return result;
}

BOOL ComTransfer::Send(HANDLE File,
					   LPCTSTR pBufferName /*= NULL*/,
					   BOOL OpenDialog /*= FALSE*/,
					   BOOL OpenModal /*= TRUE*/)
{
	// retrieve file size
	DWORD FileSize = GetFileSize(File,NULL);

	if (FileSize == 0xFFFFFFFF)
		return FALSE;

	// read the file
	m_pTxBuffer = (BYTE*)malloc(FileSize * sizeof(BYTE));
	
	if (m_pTxBuffer == NULL)
		return FALSE;

	DWORD ReadBytes;
	ReadFile(File,m_pTxBuffer,FileSize,&ReadBytes,NULL);
	
	if (ReadBytes != FileSize)
	{
		free(m_pTxBuffer);
		m_pTxBuffer = NULL;
		return FALSE;
	}
	
	// ready to send the file
	m_FreeTxBuffer = TRUE;
	return Send(m_pTxBuffer,FileSize,pBufferName,FALSE,OpenDialog,OpenModal);
}

BOOL ComTransfer::Send(BYTE* pBuffer,
					   DWORD BufferLength,
					   LPCTSTR pBufferName /*= NULL*/,
					   BOOL CopyBuffer /*= FALSE*/,
					   BOOL OpenDialog /*= FALSE*/,
					   BOOL OpenModal /*= TRUE*/)
{
	// port already in use?
	if (m_RxInProgress || m_TxInProgress)
		return FALSE;

	// port must be opened
	if (!m_pPort->IsOpened())
		return FALSE;

	// must ensure exclusive access
	if (!m_pPort->Lock(FALSE))
		return FALSE;

	// start transfer
	if (CopyBuffer)
	{
		// copy incoming data
		m_pTxBuffer = (BYTE*)malloc(BufferLength * sizeof(BYTE));

		if (m_pTxBuffer == NULL)
			return FALSE;

		memcpy(m_pTxBuffer,pBuffer,BufferLength);
	}
	else
		m_pTxBuffer = pBuffer;

	m_TxBufferPos = 0;	
	m_TxBufferSize = BufferLength;
	m_TxInProgress = TRUE;
	m_FreeTxBuffer |= CopyBuffer;
	m_TxFileName = pBufferName;

	// start the com process
	m_pPort->Write(m_pTxBuffer,1);
	m_TxBufferPos = 1;	

	// dialog box requested?
	if (OpenDialog)
	{
		if (OpenModal)
		{
			ComTransferSendDialog dlg(this);
			dlg.DoModal();	
		}
		else
		{
			// any modeless dialog still in memory?
			if (m_pModelessDialog != NULL)
				delete m_pModelessDialog;

			m_pModelessDialog = new ComTransferSendDialog(this);
			
			if (m_pModelessDialog != 0)
				if (m_pModelessDialog->Create(IDD_COMTRANSFER_SEND)) 
					m_pModelessDialog->ShowWindow(SW_SHOW);
				else
					m_pModelessDialog = NULL;
			else
				m_pModelessDialog = NULL;
		}
	}

	return TRUE;
}

BOOL ComTransfer::Receive(LPCTSTR pFileName,
						  DWORD FileSize /*= MAXDWORD*/,
						  BOOL OpenDialog /*= FALSE*/,
						  BOOL OpenModal /*= TRUE*/)
{
	m_ReceivingFile = TRUE;
	m_RxFileName = pFileName;

	m_pUserBuffer = NULL;
	m_ppUserBuffer = NULL;
	m_pUserBufferLength = NULL;

	return StartReceiving(FileSize,OpenDialog,OpenModal);
}

BOOL ComTransfer::Receive(BYTE* pBuffer,		
						  DWORD BufferSize /*= MAXDWORD*/,
						  LPCTSTR pBufferName /*= NULL*/,
						  BOOL OpenDialog /*= FALSE*/,
						  BOOL OpenModal /*= TRUE*/)
{
	// store user buffer data
	m_pUserBuffer = pBuffer;
	m_ppUserBuffer = NULL;
	m_pUserBufferLength = NULL;
	m_RxFileName = pBufferName;

	return StartReceiving(BufferSize,OpenDialog,OpenModal);
}

BOOL ComTransfer::Receive(BYTE** ppBuffer,		
						  DWORD BufferSize /*= MAXDWORD*/,
						  DWORD* pBufferData /*= NULL*/,
						  LPCTSTR pBufferName /*= NULL*/,
						  BOOL OpenDialog /*= FALSE*/,
						  BOOL OpenModal /*= TRUE*/)
{
	// store user buffer data
	m_pUserBuffer = NULL;
	m_ppUserBuffer = ppBuffer;
	m_pUserBufferLength = pBufferData;
	m_RxFileName = pBufferName;

	return StartReceiving(BufferSize,OpenDialog,OpenModal);
}

BOOL ComTransfer::StartReceiving(DWORD BufferSize /*= MAXDWORD*/,
								 BOOL OpenDialog /*= FALSE*/,
								 BOOL OpenModal /*= TRUE*/)
{
	// port already in use?
	if (m_RxInProgress || m_TxInProgress)
		return FALSE;

	// port must be opened
	if (!m_pPort->IsOpened())
		return FALSE;

	// must ensure exclusive access
	if (!m_pPort->Lock(FALSE))
		return FALSE;

	if (m_IsRxUnbound = (BufferSize == MAXDWORD))
	{
		// start with a minimal buffer
		m_RxBufferSize = m_RxBufferPageSize;
		m_pRxBuffer = (BYTE*)malloc(m_RxBufferPageSize * sizeof(BYTE));
	}
	else
	{
		// reserve a well sized buffer
		m_RxBufferSize = BufferSize;
		m_pRxBuffer = (BYTE*)malloc(BufferSize * sizeof(BYTE));
	}
		
	if (m_pRxBuffer == NULL)
	{
		// free com port
		m_pPort->Unlock();
		return FALSE;
	}

	// ready to receive the data
	m_RxBufferPos = 0;	
	m_RxInProgress = TRUE;

	// dialog box requested?
	if (OpenDialog)
	{
		if (OpenModal)
		{
			if (m_IsRxUnbound)
			{
				ComTransferReceiveSizeUnknownDialog dlg(this);
				dlg.DoModal();	
			}
			else
			{
				ComTransferReceiveDialog dlg(this);
				dlg.DoModal();	
			}
		}
		else
		{
			// any modeless dialog still in memory?
			if (m_pModelessDialog != NULL)
				delete m_pModelessDialog;

			if (m_IsRxUnbound)
			{
				// unbound transaction
				m_pModelessDialog = new ComTransferReceiveSizeUnknownDialog(this);
			
				if (m_pModelessDialog != 0)
					if (m_pModelessDialog->Create(IDD_COMTRANSFER_RECEIVE_SIZEUNKNOWN)) 
						m_pModelessDialog->ShowWindow(SW_SHOW);
					else
						m_pModelessDialog = NULL;
				else
					m_pModelessDialog = NULL;
			}
			else
			{
				// known size transaction
				m_pModelessDialog = new ComTransferReceiveDialog(this);
			
				if (m_pModelessDialog != 0)
					if (m_pModelessDialog->Create(IDD_COMTRANSFER_RECEIVE)) 
						m_pModelessDialog->ShowWindow(SW_SHOW);
					else
						m_pModelessDialog = NULL;
				else
					m_pModelessDialog = NULL;
			}
		}
	}

	return TRUE;
}

BOOL ComTransfer::DataReceived()
{
	// works only for unbounded transactions
	if (!m_IsRxUnbound)
		return FALSE;

	// close transmission
	CloseRx();
	m_IsRxUnbound = FALSE;
	m_RxSuccessfull = TRUE;
	return TRUE;
}

BOOL ComTransfer::FileReceived()
{
	// works only with files
	if (!m_ReceivingFile)
		return FALSE;

	// save the received file
	DWORD WrittenBytes = 0;
	HANDLE SavingFile = CreateFile(m_RxFileName,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	
	if (SavingFile != INVALID_HANDLE_VALUE)
		WriteFile(SavingFile,m_pRxBuffer,m_RxBufferPos,&WrittenBytes,NULL);

	CloseHandle(SavingFile);

	// close transmission
	DataReceived();
	m_RxSuccessfull = (m_RxBufferPos == WrittenBytes);

	return TRUE;
}



// ==============================
// protected functions
// ==============================

void ComTransfer::CloseTx()
{
	if (m_TxInProgress)
	{
		// stop file transfer
		m_TxInProgress = FALSE;

		// free memory
		if (m_FreeTxBuffer && (m_pTxBuffer != NULL))
			free(m_pTxBuffer);

		m_TxBufferPos = 0;	
		m_TxBufferSize = 0;
		m_FreeTxBuffer = FALSE;
		m_TxFileName = _T("");
		m_pPort->Unlock();
		return;
	}
}

void ComTransfer::CloseRx()
{
	if (m_RxInProgress)
	{
		// stop file transfer
		m_RxInProgress = FALSE;

		// copy data to user buffer
		if(m_pUserBufferLength != NULL)
			*m_pUserBufferLength = m_RxBufferPos;

		if (m_pUserBuffer != NULL)
			memcpy(m_pUserBuffer,m_pRxBuffer,m_RxBufferSize);

		if (m_ppUserBuffer != NULL)
		{
			// allocate the buffer, if requested
			if ((*m_ppUserBuffer = new BYTE[m_RxBufferSize]) == NULL)
				return;

			// transfer data
			memcpy((*m_ppUserBuffer),m_pRxBuffer,m_RxBufferSize);
		}

		// free memory
		if (m_pRxBuffer != NULL)
			free(m_pRxBuffer);

		m_RxBufferPos = 0;	
		m_RxBufferSize = 0;
		m_RxFileName = _T("");
		m_ReceivingFile = FALSE;
		m_pPort->Unlock();
		return;
	}
}



// ==============================
// COM event handler
// ==============================

void ComTransfer::EventHandler(HANDLE ComPort,DWORD Event,DWORD Param)
{
	ComTransfer* pCFT = (ComTransfer*)Param;

	if (!pCFT->m_pPort->IsOpened())
	{
		// port closed
		pCFT->AbortTransfer();
		return;
	}

	// ==============================
	// file receiving 
	if (pCFT->m_RxInProgress && (Event & EV_RXCHAR))
	{
		if (pCFT->m_IsRxUnbound)
		{
			// retrieve the incoming bytes
			BYTE* pTmp = NULL;
			DWORD RxBufferSize = pCFT->m_pPort->GetInputBufferSize();
		
			if ((pTmp = new BYTE[RxBufferSize]) == NULL)
			{
				// memory low: close transmission
				pCFT->AbortTransfer();
				return;
			}

			DWORD ReadBytes = pCFT->m_pPort->Read(pTmp,RxBufferSize);

			// enough free space to store the new data?
			if ((pCFT->m_RxBufferSize - pCFT->m_RxBufferPos) < ReadBytes)
			{
				// ask for new space
				BYTE* pNewRxBuffer = (BYTE*)realloc(pCFT->m_pRxBuffer,(pCFT->m_RxBufferSize + pCFT->m_RxBufferPageSize));
	
				if (pNewRxBuffer != NULL)
				{
					pCFT->m_pRxBuffer = pNewRxBuffer;
					pCFT->m_RxBufferSize += pCFT->m_RxBufferPageSize;
				}
				else
				{
					pCFT->AbortTransfer();
					free(pTmp);
					return;
				}
			}

			// store read data
			memcpy((pCFT->m_pRxBuffer + pCFT->m_RxBufferPos),pTmp,ReadBytes);
			pCFT->m_RxBufferPos += ReadBytes;
			free(pTmp);
		}
		else
		{
			// try fill the whole buffer
			DWORD RxFreeSpace = pCFT->m_RxBufferSize - pCFT->m_RxBufferPos;
			DWORD ReadBytes = pCFT->m_pPort->Read(pCFT->m_pRxBuffer + pCFT->m_RxBufferPos,RxFreeSpace);
			pCFT->m_RxBufferPos += ReadBytes;

			// transaction completed?
			if (pCFT->m_RxBufferSize == pCFT->m_RxBufferPos)
			{
				// save the received file
				pCFT->m_IsRxUnbound = TRUE;
				
				if (pCFT->ReceivingFileName().IsEmpty())
					pCFT->DataReceived();
				else
					pCFT->FileReceived();
			}
		}
	}

	// ==============================
	// file sending
	if (pCFT->m_TxInProgress && (Event & EV_TXEMPTY))
	{
		// how many bytes to transmit?
		DWORD FreeBufferSpace = pCFT->m_pPort->GetOutputBufferFreeSpace();
		DWORD BytesLeftToTransmit = pCFT->m_TxBufferSize - pCFT->m_TxBufferPos;
		DWORD BytesToTransmit = min(FreeBufferSpace,BytesLeftToTransmit);

		if (BytesLeftToTransmit == 0)
		{
			// transfer done
			pCFT->CloseTx();
			pCFT->m_TxSuccessfull = TRUE;
		}
		else
		{
			// fill the transmission buffer
			DWORD TransmittedBytes = pCFT->m_pPort->Write((pCFT->m_pTxBuffer + pCFT->m_TxBufferPos),BytesToTransmit);
			pCFT->m_TxBufferPos += TransmittedBytes;
		}
	}
}
