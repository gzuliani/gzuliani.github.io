// ComPort.cpp implementation file
/////////////////////////////////////////////////////////////////////////////


#include <conio.h>					// _inp, _outp

#include "ComPort.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#include "ComSetupDialog.h"
#include "ComBuffersSetupDialog.h"


/////////////////////////////////////////////////////////////////////////////
// DllMain

#include "afxdllx.h"

static AFX_EXTENSION_MODULE ComPortDLL = { NULL, NULL };

extern "C" int APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	UNREFERENCED_PARAMETER(lpReserved);

	if (dwReason == DLL_PROCESS_ATTACH)
	{
		// extension DLL one-time initialization
		if (!AfxInitExtensionModule(ComPortDLL, hInstance))
			return 0;

		// insert this DLL into the resource chain
		new CDynLinkLibrary(ComPortDLL);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		AfxTermExtensionModule(ComPortDLL);
	}

	return 1;
}










/////////////////////////////////////////////////////////////////////////////
// ComMutex

ComMutex::ComMutex() : m_Semaphore(1,1)
{
	m_ComOpened = FALSE;
	m_ThreadAlive = FALSE;

	m_ComPort = INVALID_HANDLE_VALUE;

	m_pNotificationWnd = NULL;

	m_pEventHandler = NULL;
	m_EventHandlerCertificate = 0;
}

ComMutex::~ComMutex()
{
}



// ==============================
// opened port flag
// ==============================

BOOL ComMutex::IsComOpened()
{
	CSingleLock Sync(&m_Semaphore);
	Sync.Lock();
	BOOL result = m_ComOpened;
	Sync.Unlock();
	return result;
}

void ComMutex::SetComFlag(BOOL ComOpened)
{
	CSingleLock Sync(&m_Semaphore);
	Sync.Lock();
	m_ComOpened = ComOpened;
	Sync.Unlock();
}



// ==============================
// listener thread running flag
// ==============================

BOOL ComMutex::IsThreadAlive()
{
	CSingleLock Sync(&m_Semaphore);
	Sync.Lock();
	BOOL result = m_ThreadAlive;
	Sync.Unlock();
	return result;
}

void ComMutex::SetThreadFlag(BOOL ThreadAlive)
{
	CSingleLock Sync(&m_Semaphore);
	Sync.Lock();
	m_ThreadAlive = ThreadAlive;
	Sync.Unlock();
}



// ==============================
// COM handler id
// ==============================

HANDLE ComMutex::GetComHandle()
{
	CSingleLock Sync(&m_Semaphore);
	Sync.Lock();
	HANDLE result = m_ComPort;
	Sync.Unlock();
	return result;
}

void ComMutex::SetComHandle(HANDLE ComPort)
{
	CSingleLock Sync(&m_Semaphore);
	Sync.Lock();
	m_ComPort = ComPort;
	Sync.Unlock();
}



// ==============================
// notification window
// ==============================

CWnd* ComMutex::GetNotificationWnd()
{
	CSingleLock Sync(&m_Semaphore);
	Sync.Lock();
	CWnd* result = m_pNotificationWnd;
	Sync.Unlock();
	return result;
}

void ComMutex::SetNotificationWnd(CWnd* pNotificationWnd)
{
	CSingleLock Sync(&m_Semaphore);
	Sync.Lock();
	m_pNotificationWnd = pNotificationWnd;
	Sync.Unlock();
}



// ==============================
// communication event handler
// ==============================

LPCOMEVENTHANDLER ComMutex::GetEventHandler()
{
	CSingleLock Sync(&m_Semaphore);
	Sync.Lock();
	LPCOMEVENTHANDLER result = m_pEventHandler;
	Sync.Unlock();
	return result;
}

DWORD ComMutex::GetEventHandlerCertificate()
{
	CSingleLock Sync(&m_Semaphore);
	Sync.Lock();
	DWORD result = m_EventHandlerCertificate;
	Sync.Unlock();
	return result;
}

void ComMutex::SetEventHandler(LPCOMEVENTHANDLER pEventHandler,
							   DWORD Certificate /*= 0*/)
{
	CSingleLock Sync(&m_Semaphore);
	Sync.Lock();
	m_pEventHandler = pEventHandler;
	m_EventHandlerCertificate = Certificate;
	Sync.Unlock();
}








/////////////////////////////////////////////////////////////////////////////
// ComPort

// ==============================
// static members initialization
// ==============================

unsigned short ComPort::UART_THR = 0x00;
unsigned short ComPort::UART_RBR = 0x00;
unsigned short ComPort::UART_IER = 0x01;
unsigned short ComPort::UART_IIR = 0x02;
unsigned short ComPort::UART_FCR = 0x02;
unsigned short ComPort::UART_LCR = 0x03;
unsigned short ComPort::UART_MCR = 0x04;
unsigned short ComPort::UART_LSR = 0x05;
unsigned short ComPort::UART_MSR = 0x06;
unsigned short ComPort::UART_SCR = 0x07;

CSemaphore ComPort::m_UARTSync(1,1,_T("CP_UARTSemaphore"));


// ==============================
// port construction
// ==============================

ComPort::ComPort()
{
	m_Status = 0;
	m_PortID = INVALID_HANDLE_VALUE;
	m_UARTType = UART_NOT_AVAILABLE;

	m_LockerID = 0;
	m_IsLocked = FALSE;
	m_ThreadLocked = TRUE;

	m_PortName = _T("");
	m_BaudRate = 0;
	m_Parity = 0;
	m_ByteSize = 0;
	m_StopBits = 0;

	m_UseRtsCts = FALSE;
	m_UseDtrDsr = FALSE;
	m_UseXonXoff = FALSE;

	m_SuggestedInputBufferSize = 4096;
	m_SuggestedOutputBufferSize = 4096;
}

ComPort::~ComPort()
{
	if (m_PortID != INVALID_HANDLE_VALUE)
	{
		// port still opened: close it
		m_IsLocked = FALSE;
		Close();
	}
}



// ==============================
// low level functions
// ==============================

HANDLE ComPort::GetHandle()
{
	return m_PortID;
}

ComPort::CP_UART_TYPE ComPort::DetectUARTType(unsigned short PortAddr /*= 0*/)
{
	if (!IsOpened())
	{
		m_UARTType = UART_NOT_AVAILABLE;
		return m_UARTType;
	}

	if (m_UARTType != UART_NOT_AVAILABLE)
		// UART already detected
		return m_UARTType;
	
	m_UARTType = UART_UNKNOWN;

	// works only in WIN95/98
	OSVERSIONINFO os;
	os.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if ((!GetVersionEx(&os))
		|| (os.dwPlatformId != VER_PLATFORM_WIN32_WINDOWS))
		return m_UARTType;

	// set I/O port address according to PC 97 ISA assignments
	if (PortAddr == 0)
	{
		if (m_PortName.CompareNoCase(_T("COM1")) == 0)
			PortAddr = 0x03f8;
		else if (m_PortName.CompareNoCase(_T("COM2")) == 0)
			PortAddr = 0x02f8;
		else if (m_PortName.CompareNoCase(_T("COM3")) == 0)
			PortAddr = 0x03e8;
		else if (m_PortName.CompareNoCase(_T("COM4")) == 0)
			PortAddr = 0x02e8;
	}
	
	// no address available
	if (PortAddr == 0)
		return m_UARTType;

	// *************************
	// start of critical section
	// *************************
	
	CSingleLock Sync(&m_UARTSync);
	Sync.Lock();

	// reset the FIFO buffers
	_outp(PortAddr + UART_FCR,0);
	int tmp = _inp(PortAddr + UART_IIR);

	if ((tmp & 0xf8) != 0)
	{
		// this is not a 8250/16550 compliant UART,
		// bits 3 to 7 of IIR should be always zero
		m_UARTType = UART_UNKNOWN;
	}
	else
	{
		// enable the FIFO buffers usage
		_outp(PortAddr + UART_FCR,0xcf);

		// FIFO supported only if bits 6 and 7 of IIR are set
		tmp = _inp(PortAddr + UART_IIR);

		switch ((tmp & 0xf8) >> 6)
		{
			case 0 :	// IIR = 00xxxxxx -> 8250/16450 chips
						m_UARTType = UART_8250;
					
						// does SCR (scratch register) exist?
						_outp(PortAddr + UART_SCR,0xaa);
						if (_inp(PortAddr + UART_SCR) == 0xaa)
						{
							_outp(PortAddr + UART_SCR,0x55);
							if (_inp(PortAddr + UART_SCR) == 0x55)
	
								// if so, UART is a 16450 chip
								m_UARTType = UART_16450;
						}
						
						break;

			case 1 :	// IIR = 01xxxxxx -> should never occour
						m_UARTType = UART_UNKNOWN;
						break;

			case 2 :	// IIR = 10xxxxxx -> 16550 (bugged) chip
						m_UARTType = UART_16550;
						break;

			case 3 :	// IIR = 11xxxxxx -> 16550AF chip
						m_UARTType = UART_16550AF;
						break;
		}

		// disable the FIFO buffers usage (default for all UARTs)
		_outp(PortAddr + UART_FCR,0);
	}
	
	// ***********************
	// end of critical section
	// ***********************
	Sync.Unlock();
	return m_UARTType;
}



// ==============================
// port opening and closing
// ==============================

BOOL ComPort::Open(CP_COM_SETTINGS* pComSettings,
				   DWORD InputBufferSize	/*= 4096*/,
				   DWORD OutputBufferSize	/*= 4096*/)
{
	return Open(pComSettings->csPortName,
				pComSettings->csBaudRate,
				pComSettings->csParity,
				pComSettings->csByteSize,
				pComSettings->csStopBits,
				pComSettings->csUseRtsCtsHandshake,
				pComSettings->csUseDtrDsrHandshake,
				pComSettings->csUseXonXoffHandshake,
				InputBufferSize,
				OutputBufferSize);
}

BOOL ComPort::Open(LPCTSTR pPort			/* = _T("COM1")      */,
				   DWORD BaudRate			/* = CBR_9600        */,
				   BYTE Parity				/* = NOPARITY        */,
				   BYTE ByteSize			/* = 8               */,
				   BYTE StopBits			/* = ONESTOPBIT      */,
				   BOOL RtsCtsHandshake		/* = FALSE           */,
				   BOOL DtrDsrHandshake		/* = FALSE           */,
				   BOOL XonXoffHandshake	/* = FALSE           */,
				   DWORD InputBufferSize	/* = 4096            */,
				   DWORD OutputBufferSize	/* = 4096            */)
{
	// port il locked, try again...
	if (IsLocked())
		return FALSE;

	// close previously opened port
	if (IsOpened())
		Close();

	if ((_tcslen(pPort) != 4)
		|| ((pPort[0] != _T('c')) && (pPort[0] != _T('C')))
		|| ((pPort[1] != _T('o')) && (pPort[1] != _T('O')))
		|| ((pPort[2] != _T('m')) && (pPort[2] != _T('M')))
		|| (pPort[3] < _T('0'))
		|| (pPort[3] > _T('9')))
		return FALSE;

	m_PortName = pPort;

	// try to open the port
	m_PortID = CreateFile(m_PortName,
				GENERIC_READ | GENERIC_WRITE,
				0,
				NULL,
				OPEN_EXISTING,
				FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED,
				NULL);

	m_ComMutex.SetComHandle(m_PortID);
	m_ComMutex.SetComFlag(m_PortID != INVALID_HANDLE_VALUE);

	if (m_PortID == INVALID_HANDLE_VALUE)
		return FALSE;

	// initialize overlapped structures
	DetectUARTType();
	memset(&m_ReadStruct,0,sizeof(OVERLAPPED));
	memset(&m_WriteStruct,0,sizeof(OVERLAPPED));

	// setup communication parameters
	m_BaudRate = BaudRate;
	m_Parity = Parity;
	m_ByteSize = ByteSize;
	m_StopBits = StopBits;
	m_UseRtsCts = RtsCtsHandshake;
	m_UseDtrDsr = DtrDsrHandshake;
	m_UseXonXoff = XonXoffHandshake;
	Setup(m_BaudRate,m_Parity,m_ByteSize,m_StopBits,m_UseRtsCts,m_UseDtrDsr,m_UseXonXoff);

	// set I/O buffers size
	m_SuggestedInputBufferSize = InputBufferSize;
	m_SuggestedOutputBufferSize = OutputBufferSize;
	SetupComm(m_PortID,m_SuggestedInputBufferSize,m_SuggestedOutputBufferSize);

	// setup timeouts   
	m_ComTimeouts.ReadIntervalTimeout = MAXDWORD;
	m_ComTimeouts.ReadTotalTimeoutMultiplier = 0;
	m_ComTimeouts.ReadTotalTimeoutConstant = 1000;

	// timeout is double the expected character time (9600 is approximately 1byte/ms)
	m_ComTimeouts.WriteTotalTimeoutMultiplier = 2*CBR_9600/BaudRate;
	m_ComTimeouts.WriteTotalTimeoutConstant = 0;

	SetCommTimeouts(m_PortID,&m_ComTimeouts);

	// clear I/O buffers
	SetCommMask(m_PortID,(EV_BREAK|EV_CTS|EV_DSR|EV_ERR|EV_RLSD|EV_RING|EV_RXCHAR|EV_TXEMPTY));
	PurgeComm(m_PortID,PURGE_TXCLEAR|PURGE_TXABORT|PURGE_RXCLEAR|PURGE_RXABORT);

	// ready
	EnableDtr();

	// start the listener thread
	DWORD ThreadID;
	HANDLE Listener = CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)CommWatchProc,&m_ComMutex,0,&ThreadID);
	SetThreadPriority(Listener,THREAD_PRIORITY_HIGHEST); 
	return TRUE;
}

BOOL ComPort::IsOpened()
{
	return (m_PortID != INVALID_HANDLE_VALUE);
}

BOOL ComPort::Close()
{
	// cannot close a locked port
	if (IsLocked())
		return FALSE;

	if (m_PortID != INVALID_HANDLE_VALUE)
	{
		m_ComMutex.SetComFlag(FALSE);
		m_ComMutex.SetComHandle(INVALID_HANDLE_VALUE);

		// this will create an event for the listener 
		// thread and let it exit from its main loop...
		SetCommMask(m_PortID,0);

		while (m_ComMutex.IsThreadAlive())
			;

		DisableDtr();

		PurgeComm(m_PortID,PURGE_TXCLEAR|PURGE_TXABORT|PURGE_RXCLEAR|PURGE_RXABORT);
		CloseHandle(m_PortID);

		m_PortID = INVALID_HANDLE_VALUE;
		m_UARTType = UART_NOT_AVAILABLE;
		m_PortName = _T("");
	}

	return (m_PortID == INVALID_HANDLE_VALUE);
}



// ==============================
// port locking
// ==============================

BOOL ComPort::Lock(BOOL ThreadLocked /*= TRUE*/)
{ 
	// cannot lock a locked port!
	if (IsLocked())
		return FALSE;

	if (ThreadLocked)
		m_LockerID = GetCurrentThreadId();
	else
		m_LockerID = GetCurrentProcessId();

	m_IsLocked = TRUE;
	m_ThreadLocked = ThreadLocked;
	return TRUE;
}

BOOL ComPort::Unlock()
{
	if (!IsLocked())
		return TRUE;

	// only the locker can unlock!
	if (m_ThreadLocked)
	{
		if (m_LockerID != GetCurrentThreadId())
			return FALSE;
	}
	else
	{
		if (m_LockerID != GetCurrentProcessId())
			return FALSE;
	}

	m_LockerID = 0;
	m_IsLocked = FALSE;
	return TRUE;
}

BOOL ComPort::IsLocked()
{
	return m_IsLocked;
}



// ==============================
// port setting
// ==============================

BOOL ComPort::Setup(CP_COM_SETTINGS* pComSettings)
{
	return Setup(pComSettings->csBaudRate,
				 pComSettings->csParity,
				 pComSettings->csByteSize,
				 pComSettings->csStopBits,
				 pComSettings->csUseRtsCtsHandshake,
				 pComSettings->csUseDtrDsrHandshake,
				 pComSettings->csUseXonXoffHandshake);
				
}

BOOL ComPort::Setup(DWORD BaudRate			/* = CBR_9600		*/,
					BYTE Parity				/* = NOPARITY		*/,
					BYTE ByteSize			/* = 8				*/,
					BYTE StopBits			/* = ONESTOPBIT		*/,
					BOOL RtsCtsHandshake	/* = FALSE			*/,
					BOOL DtrDsrHandshake	/* = FALSE			*/,
					BOOL XonXoffHandshake	/* = FALSE			*/)
{
	if (!IsOpened())
		return FALSE;

	// setup communication parameters
	DCB CommDCB;
	GetCommState(m_PortID,&CommDCB);
	SetDCBFromSettings(&CommDCB);	
	SetCommState(m_PortID,&CommDCB);
	return TRUE;
}

BOOL ComPort::GetComSetup(CP_COM_SETTINGS* pComSettings)
{
	return GetComSetup(&pComSettings->csPortName,
					   &pComSettings->csBaudRate,
					   &pComSettings->csParity,
					   &pComSettings->csByteSize,
					   &pComSettings->csStopBits,
					   &pComSettings->csUseRtsCtsHandshake,
					   &pComSettings->csUseDtrDsrHandshake,
					   &pComSettings->csUseXonXoffHandshake);
}

BOOL ComPort::GetComSetup(CString* pPortName,
						  DWORD* pBaudRate,
						  BYTE* pParity,
						  BYTE* pByteSize,
						  BYTE* pStopBits,
						  BOOL* pUseRtsCtsHandshake,
						  BOOL* pUseDtrDsrHandshake,
						  BOOL* pUseXonXoffHandshake)
{
	if (pPortName != NULL)
		*pPortName = m_PortName;

	if (pBaudRate != NULL)
		*pBaudRate = m_BaudRate;

	if (pParity != NULL)
		*pParity = m_Parity;

	if (pByteSize != NULL)
		*pByteSize = m_ByteSize;

	if (pStopBits != NULL)
		*pStopBits = m_StopBits;

	if (pUseRtsCtsHandshake != NULL)
		*pUseRtsCtsHandshake = m_UseRtsCts;

	if (pUseDtrDsrHandshake != NULL)
		*pUseDtrDsrHandshake = m_UseDtrDsr;

	if (pUseXonXoffHandshake != NULL)
		*pUseXonXoffHandshake = m_UseXonXoff;

	return IsOpened();
}

BOOL ComPort::SetComTimeout(COMMTIMEOUTS* pComTimeouts)
{
	if (!IsOpened())
		return FALSE;

	m_ComTimeouts = *pComTimeouts;
	return SetCommTimeouts(m_PortID,&m_ComTimeouts);
}

BOOL ComPort::GetComTimeout(COMMTIMEOUTS* pComTimeouts)
{
	if (!IsOpened())
		return FALSE;

	return GetCommTimeouts(m_PortID,pComTimeouts);
}

BOOL ComPort::OpenSetupDialog()
{
	if (!IsOpened())
		return FALSE;

	// make a safe copy of settings
	CString PortName = m_PortName;

	DWORD BaudRate = m_BaudRate;
	BYTE Parity = m_Parity;
	BYTE ByteSize = m_ByteSize;
	BYTE StopBits = m_StopBits;

	BOOL RtsCts = m_UseRtsCts;
	BOOL DtrDsr = m_UseDtrDsr;
	BOOL XonXoff = m_UseXonXoff;

	ComSetupDialog dlg(&PortName,&BaudRate,&Parity,&ByteSize,&StopBits,&RtsCts,&DtrDsr,&XonXoff);
	
	if (dlg.DoModal() == IDOK)
	{
		// retrieve confirmed data
		m_BaudRate = BaudRate;
		m_Parity = Parity;
		m_ByteSize = ByteSize;
		m_StopBits = StopBits;

		m_UseRtsCts = RtsCts;
		m_UseDtrDsr = DtrDsr;
		m_UseXonXoff = XonXoff;

		if (PortName.CompareNoCase(m_PortName)==0)
			// port is not changed
			Setup(m_BaudRate,m_Parity,m_ByteSize,m_StopBits,m_UseRtsCts,m_UseDtrDsr,m_UseXonXoff);
		else
			// port has changed: open the new one
			Open(PortName,m_BaudRate,m_Parity,m_ByteSize,m_StopBits,m_UseRtsCts,m_UseDtrDsr,m_UseXonXoff);
	}

	return TRUE;
}

BOOL ComPort::OpenCommonSetupDialog()
{
	if (!IsOpened())
		return FALSE;

	DWORD dwSize;
	COMMCONFIG CommConfig;

	// retrieve current settings
	if (!GetCommConfig(m_PortID,&CommConfig,&dwSize))
		return FALSE;

	SetDCBFromSettings(&CommConfig.dcb);	

	if (CommConfigDialog(m_PortName,NULL,&CommConfig))
	{
		// setup the comm port
		ExtractSettingsFromDCB(&CommConfig.dcb);
		Setup(m_BaudRate,m_Parity,m_ByteSize,m_StopBits,m_UseRtsCts,m_UseDtrDsr,m_UseXonXoff);
		return TRUE;
	}
	else
		return FALSE;
}

BOOL ComPort::OpenBuffersSetupDialog()
{
	if (!IsOpened())
		return FALSE;

	ComBuffersSetupDialog dlg(this);
	dlg.DoModal();
	return TRUE;
}



// ==============================
// low level settings
// ==============================

void ComPort::SetDCBFromSettings(DCB* pDCB)
{
	// setup communication parameters
	pDCB->DCBlength = sizeof(DCB);
	pDCB->BaudRate = m_BaudRate;
	pDCB->ByteSize = m_ByteSize;
	pDCB->Parity = m_Parity;
	pDCB->StopBits = m_StopBits;
	
	// RTS/CTS (hardware) handshaking
	if (m_UseRtsCts)
	{
		pDCB->fOutxCtsFlow = 1;
		pDCB->fRtsControl = RTS_CONTROL_HANDSHAKE;
	}
	else
	{
		pDCB->fOutxCtsFlow = 0;
		pDCB->fRtsControl = RTS_CONTROL_ENABLE;
	}
	
	// DTR/DSR (hardware) handshaking
	if (m_UseDtrDsr)
	{
		pDCB->fOutxDsrFlow = 1;
		pDCB->fDtrControl = DTR_CONTROL_HANDSHAKE;
	}
	else
	{
		pDCB->fOutxDsrFlow = 0;
		pDCB->fDtrControl = DTR_CONTROL_ENABLE;
	}
	
	// XON/XOFF (software) handhaking
	if (m_UseXonXoff)
	{
		pDCB->fInX = 1;
		pDCB->fOutX = 1;
	}
	else
	{
		pDCB->fInX = 0;
		pDCB->fOutX = 0;
	}

	pDCB->XonChar = 0x11;
	pDCB->XoffChar = 0x13;
	pDCB->XonLim = 100;
	pDCB->XoffLim = 100;

	// other various settings
	pDCB->fBinary = TRUE;
	pDCB->fParity = TRUE;
}

void ComPort::ExtractSettingsFromDCB(DCB* pDCB)
{
	// retrieve communication parameters
	m_BaudRate = pDCB->BaudRate;
	m_ByteSize = pDCB->ByteSize;
	m_Parity = pDCB->Parity;
	m_StopBits = pDCB->StopBits;
	
	// retrieve handshake parameters
	m_UseRtsCts = (pDCB->fOutxCtsFlow == 1);
	m_UseDtrDsr = (pDCB->fOutxDsrFlow == 1);
	m_UseXonXoff = (pDCB->fInX == 1) && (pDCB->fOutX == 1);	
}



// ==============================
// I/O buffers management
// ==============================

BOOL ComPort::SetSuggestedInputBufferSize(DWORD InBufferSize)
{
	if (!IsOpened())
		return FALSE;

	m_SuggestedInputBufferSize = InBufferSize;
	return SetupComm(m_PortID,m_SuggestedInputBufferSize,m_SuggestedOutputBufferSize);
}

BOOL ComPort::SetSuggestedOutputBufferSize(DWORD OutBufferSize)
{
	if (!IsOpened())
		return FALSE;

	m_SuggestedOutputBufferSize = OutBufferSize;
	return SetupComm(m_PortID,m_SuggestedInputBufferSize,m_SuggestedOutputBufferSize);
}

DWORD ComPort::GetMaxInputBufferSize()
{
	if (!IsOpened())
		return MAXDWORD;

	COMMPROP CommProp;
	GetCommProperties(m_PortID,&CommProp);
	return CommProp.dwMaxRxQueue;
}

DWORD ComPort::GetMaxOutputBufferSize()
{
	if (!IsOpened())
		return MAXDWORD;

	COMMPROP CommProp;
	GetCommProperties(m_PortID,&CommProp);
	return CommProp.dwMaxTxQueue;
}

DWORD ComPort::GetInputBufferSize()
{
	if (!IsOpened())
		return MAXDWORD;

	COMMPROP CommProp;
	GetCommProperties(m_PortID,&CommProp);
	return CommProp.dwCurrentRxQueue;
}

DWORD ComPort::GetOutputBufferSize()
{
	if (!IsOpened())
		return MAXDWORD;

	COMMPROP CommProp;
	GetCommProperties(m_PortID,&CommProp);
	return CommProp.dwCurrentTxQueue;
}

DWORD ComPort::GetInputBufferFreeSpace()
{
	if (!IsOpened())
		return MAXDWORD;

	COMSTAT ComStat;
	COMMPROP CommProp;
	DWORD currentStatus = 0;

	GetCommProperties(m_PortID,&CommProp);
	ClearCommError(m_PortID,&currentStatus,&ComStat);
	m_Status |= currentStatus;

	return (CommProp.dwCurrentRxQueue - ComStat.cbInQue);
}

DWORD ComPort::GetOutputBufferFreeSpace()
{
	if (!IsOpened())
		return MAXDWORD;

	COMSTAT ComStat;
	COMMPROP CommProp;
	DWORD currentStatus = 0;

	GetCommProperties(m_PortID,&CommProp);
	ClearCommError(m_PortID,&currentStatus,&ComStat);
	m_Status |= currentStatus;

	return (CommProp.dwCurrentTxQueue - ComStat.cbOutQue);
}

BOOL ComPort::PurgeBuffers()
{
	return (PurgeInputBuffer() && PurgeOutputBuffer());
}

BOOL ComPort::PurgeInputBuffer()
{
	if (!IsOpened())
		return FALSE;

	return PurgeComm(m_PortID,PURGE_RXABORT | PURGE_RXCLEAR);
}

BOOL ComPort::PurgeOutputBuffer()
{
	if (!IsOpened())
		return FALSE;

	return PurgeComm(m_PortID,PURGE_TXABORT | PURGE_TXCLEAR);
}



// ==============================
// error status
// ==============================

BOOL ComPort::CheckError(DWORD Error, BOOL Clear)
{
	// retrieve port status
	DWORD currentStatus = 0;
	ClearCommError(m_PortID,&currentStatus,NULL);
	m_Status |= currentStatus;

	BOOL result = ((m_Status & Error) == Error);

	if (Clear)
		m_Status &= ~Error;

	return result;
}

BOOL ComPort::BreakDetected(BOOL Clear /*= TRUE*/)
{
	return CheckError(CE_BREAK,Clear);
}

BOOL ComPort::FramingErrorOccoured(BOOL Clear /*= TRUE*/)
{
	return CheckError(CE_FRAME,Clear);
}

BOOL ComPort::OverrunErrorOccoured(BOOL Clear /*= TRUE*/)
{
	return CheckError(CE_OVERRUN,Clear);
}

BOOL ComPort::InputBufferOverflowOccoured(BOOL Clear /*= TRUE*/)
{
	return CheckError(CE_RXOVER,Clear);
}

BOOL ComPort::ParityErrorOccoured(BOOL Clear /*= TRUE*/)
{
	return CheckError(CE_RXPARITY,Clear);
}

BOOL ComPort::OutputBufferOverflowOccoured(BOOL Clear /*= TRUE*/)
{
	return CheckError(CE_TXFULL,Clear);
}


// ==============================
// break communication 
// ==============================

BOOL ComPort::Break(DWORD Milliseconds /*= 300*/)
{
	if (!IsOpened())
		return FALSE;

	SetCommBreak(m_PortID);
	DWORD resumeTime = GetTickCount() + Milliseconds;

	while(GetTickCount() < resumeTime)
		;

	ClearCommBreak(m_PortID);
	return TRUE;
}



// ==============================
// lines testing and setting
// ==============================

BOOL ComPort::RiStatus()
{
	if (!IsOpened())
		return FALSE;

	DWORD modemStatus;
	if (!GetCommModemStatus(m_PortID,&modemStatus))
		return FALSE;

	return (modemStatus & MS_RING_ON);
}

BOOL ComPort::CdStatus()
{
	if (!IsOpened())
		return FALSE;

	DWORD modemStatus;
	if (!GetCommModemStatus(m_PortID,&modemStatus))
		return FALSE;

	return (modemStatus & MS_RLSD_ON);
}

BOOL ComPort::CtsStatus()
{
	if (!IsOpened())
		return FALSE;

	DWORD modemStatus;
	if (!GetCommModemStatus(m_PortID,&modemStatus))
		return FALSE;

	return (modemStatus & MS_CTS_ON);
}

BOOL ComPort::DsrStatus()
{
	if (!IsOpened())
		return FALSE;

	DWORD modemStatus;
	if (!GetCommModemStatus(m_PortID,&modemStatus))
		return FALSE;

	return (modemStatus & MS_DSR_ON);
}

BOOL ComPort::EnableDtr()
{
	if (!IsOpened())
		return FALSE;

	return EscapeCommFunction(m_PortID,SETDTR);
}

BOOL ComPort::DisableDtr()
{
	if (!IsOpened())
		return FALSE;

	return EscapeCommFunction(m_PortID,CLRDTR);
}

BOOL ComPort::EnableRts()
{
	if (!IsOpened())
		return FALSE;

	return EscapeCommFunction(m_PortID,SETRTS);
}

BOOL ComPort::DisableRts()
{
	if (!IsOpened())
		return FALSE;

	return EscapeCommFunction(m_PortID,CLRRTS);
}



// ==============================
// reading and writing
// ==============================

DWORD ComPort::Read(void* pBuffer, DWORD BytesToRead)
{
	if (!IsOpened())
		return (DWORD)0;

	DWORD readBytes;
	ReadFile(m_PortID,(void*)pBuffer,BytesToRead,&readBytes,&m_ReadStruct);

	// retrieve port status
	DWORD currentStatus = 0;
	ClearCommError(m_PortID,&currentStatus,NULL);
	m_Status |= currentStatus;

	return readBytes;
}

DWORD ComPort::Write(void* pBuffer, DWORD BytesToWrite)
{
	if (!IsOpened())
		return (DWORD)0;

	DWORD writtenBytes;
	WriteFile(m_PortID,(void*)pBuffer,BytesToWrite,&writtenBytes,&m_WriteStruct);

	// retrieve port status
	DWORD currentStatus = 0;
	ClearCommError(m_PortID,&currentStatus,NULL);
	m_Status |= currentStatus;

	return writtenBytes;
}



// ==============================
// handlers setting 
// ==============================

void ComPort::SetNotificationWnd(CWnd* pNotificationWnd)
{
	m_ComMutex.SetNotificationWnd(pNotificationWnd);
}

void ComPort::SetEventHandler(LPCOMEVENTHANDLER pEventHandler,DWORD Certificate /*= 0*/)
{
	m_ComMutex.SetEventHandler(pEventHandler,Certificate);
}


	
// ==============================
// COM listener thread
// ==============================

DWORD WINAPI ComPort::CommWatchProc(LPVOID lpParameter)
{
	// listener is starting...
	ComMutex* pMutex = (ComMutex*)lpParameter;
	pMutex->SetThreadFlag(TRUE);
	CWnd* pNotificationWnd = pMutex->GetNotificationWnd();
	DWORD Certificate = pMutex->GetEventHandlerCertificate();
	LPCOMEVENTHANDLER pEventHandler = pMutex->GetEventHandler();

	while (pMutex->IsComOpened())
	{
		DWORD dwEvtMask = 0;
		
		// event testing
		WaitCommEvent(pMutex->GetComHandle(),&dwEvtMask,NULL);

		// if no error occoured, manage the event
		if (dwEvtMask != 0)
		{
			if (pEventHandler != NULL)
				(*pEventHandler)(pMutex->GetComHandle(),dwEvtMask,Certificate);

			if (pNotificationWnd != NULL)
				pNotificationWnd->SendMessage(WM_COMMAND,(WPARAM)dwEvtMask,(LPARAM)pMutex->GetComHandle());
		}
	}

	// listener is stopping...
	pMutex->SetThreadFlag(FALSE);

   return TRUE;
}

