// ComPort.h : declaration file
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMPORT_H__0414FB02_4497_11D2_B636_0000B45C6B2C__INCLUDED_)
#define AFX_COMPORT_H__0414FB02_4497_11D2_B636_0000B45C6B2C__INCLUDED_


#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


#include "afxmt.h"
#include "stdafx.h"


/////////////////////////////////////////////////////////////////////////////
// ComMutex

typedef void (*LPCOMEVENTHANDLER)(HANDLE,DWORD,DWORD);

class ComMutex
{ 
public:
	// construction
	ComMutex();
	~ComMutex();

	// public interface
	BOOL IsComOpened();
	void SetComFlag(BOOL ComOpened);

	HANDLE GetComHandle();
	void SetComHandle(HANDLE ComPort);

	BOOL IsThreadAlive();
	void SetThreadFlag(BOOL ThreadAlive);

	CWnd* GetNotificationWnd();
	void SetNotificationWnd(CWnd* pNotificationWnd);

	DWORD GetEventHandlerCertificate();
	LPCOMEVENTHANDLER GetEventHandler();
	void SetEventHandler(LPCOMEVENTHANDLER pEventHandler,DWORD Certificate = 0);

protected:
	// synchronization
	CSemaphore m_Semaphore;

	// protected data
	BOOL	m_ComOpened;
	BOOL	m_ThreadAlive;
	HANDLE	m_ComPort;

	CWnd*	m_pNotificationWnd;

	LPCOMEVENTHANDLER	m_pEventHandler;
	DWORD				m_EventHandlerCertificate;
};





/////////////////////////////////////////////////////////////////////////////
// ComPort

class AFX_EXT_CLASS ComPort
{
protected:

	// ==============================
	// COM listener thread
	static DWORD WINAPI CommWatchProc(LPVOID lpParameter);


	// UART register displacements
	static unsigned short UART_THR;	// Tx Holding  Register   WO
	static unsigned short UART_RBR;	// Rx Buffer   Register   RO
	static unsigned short UART_IER; // Int Enable  Register   RW
	static unsigned short UART_IIR;	// Int Id      Register   RO
	static unsigned short UART_FCR;	// FIFO Ctrl   Register   WO  16550 only
	static unsigned short UART_LCR;	// Line Ctrl   Register   RW
	static unsigned short UART_MCR;	// Modem Ctrl  Register   RW
	static unsigned short UART_LSR;	// Line Stat   Register   RO
	static unsigned short UART_MSR;	// Modem Stat  Register   RO
	static unsigned short UART_SCR;	// Scratch     Register   RW  16550 only

	typedef enum {	NO_HANDSHAKE, 
					RTSCTS_HANDSHAKE,
					DTRDSR_HANDSHAKE,
					XONXOFF_HANDSHAKE, }	CP_HANDSHAKE_TYPE;

public:
	struct CP_COM_SETTINGS {
					CString csPortName;
					DWORD csBaudRate;
					BYTE csParity;
					BYTE csByteSize;
					BYTE csStopBits;
					BOOL csUseRtsCtsHandshake;
					BOOL csUseDtrDsrHandshake;
					BOOL csUseXonXoffHandshake; };

	typedef enum {	UART_NOT_AVAILABLE,
					UART_UNKNOWN,
					UART_8250,
					UART_16450,
					UART_16550,
					UART_16550AF, }			CP_UART_TYPE;

	// ==============================
	// port construction
	ComPort();
	~ComPort();


	// ==============================
	// low level functions
	HANDLE GetHandle();
	CP_UART_TYPE DetectUARTType(unsigned short PortAddr = 0);


	// ==============================
	// port opening and closing
	BOOL Open(CP_COM_SETTINGS* pComSettings,
			  DWORD InputBufferSize = 4096,
			  DWORD OutputBufferSize = 4096);
	
	BOOL Open(LPCTSTR pPort = _T("COM1"),
			  DWORD BaudRate = CBR_9600,
			  BYTE Parity = NOPARITY,
			  BYTE ByteSize = 8,
			  BYTE StopBits = ONESTOPBIT,
			  BOOL RtsCtsHandshake = FALSE,
			  BOOL DtrDsrHandshake = FALSE,
			  BOOL XonXoffHandshake = FALSE,
			  DWORD InputBufferSize = 4096,
			  DWORD OutputBufferSize = 4096);

	BOOL IsOpened();
	BOOL Close();


	// ==============================
	// port locking
	BOOL Lock(BOOL ThreadLocked = TRUE);
	BOOL Unlock();
	BOOL IsLocked();


	// ==============================
	// port setting
	BOOL Setup(CP_COM_SETTINGS* pComSettings);
	
	BOOL Setup(DWORD BaudRate = CBR_9600,
			   BYTE Parity = NOPARITY,
			   BYTE ByteSize = 8,
			   BYTE StopBits = ONESTOPBIT,
			   BOOL RtsCtsHandshake = FALSE,
			   BOOL DtrDsrHandshake = FALSE,
			   BOOL XonXoffHandshake = FALSE);

	BOOL GetComSetup(CP_COM_SETTINGS* pComSettings);

	BOOL GetComSetup(CString* pPortName,
					 DWORD* pBaudRate,
					 BYTE* pParity,
					 BYTE* pByteSize,
					 BYTE* pStopBits,
					 BOOL* pUseRtsCtsHandshake,
					 BOOL* pUseDtrDsrHandshake,
					 BOOL* pUseXonXoffHandshake);

	BOOL SetComTimeout(COMMTIMEOUTS* pComTimeouts);
	BOOL GetComTimeout(COMMTIMEOUTS* pComTimeouts);

	BOOL OpenSetupDialog();
	BOOL OpenCommonSetupDialog();
	BOOL OpenBuffersSetupDialog();


	// ==============================
	// low level settings
	void SetDCBFromSettings(DCB* pDCB);
	void ExtractSettingsFromDCB(DCB* pDCB);


	// ==============================
	// I/O buffers management
	BOOL SetSuggestedInputBufferSize(DWORD InBufferSize);
	BOOL SetSuggestedOutputBufferSize(DWORD OutBufferSize);

	DWORD GetMaxInputBufferSize();
	DWORD GetMaxOutputBufferSize();

	DWORD GetInputBufferSize();
	DWORD GetOutputBufferSize();

	DWORD GetInputBufferFreeSpace();
	DWORD GetOutputBufferFreeSpace();

	BOOL PurgeBuffers();
	BOOL PurgeInputBuffer();
	BOOL PurgeOutputBuffer();

	// ==============================
	// error status
	BOOL BreakDetected(BOOL Clear = TRUE);
	BOOL ParityErrorOccoured(BOOL Clear = TRUE);
	BOOL FramingErrorOccoured(BOOL Clear = TRUE);
	BOOL OverrunErrorOccoured(BOOL Clear = TRUE);
	BOOL InputBufferOverflowOccoured(BOOL Clear = TRUE);
	BOOL OutputBufferOverflowOccoured(BOOL Clear = TRUE);


	// ==============================
	// break communication 
	BOOL Break(DWORD Milliseconds = 300);


	// ==============================
	// lines testing and setting
	BOOL RiStatus();
	BOOL CdStatus();
	BOOL CtsStatus();
	BOOL DsrStatus();

	BOOL EnableDtr();
	BOOL DisableDtr();
	BOOL EnableRts();
	BOOL DisableRts();


	// ==============================
	// reading and writing
	DWORD Read(void* pBuffer, DWORD BytesToRead);
	DWORD Write(void* pBuffer, DWORD BytesToWrite);


	// ==============================
	// handlers setting 
	void SetNotificationWnd(CWnd* pNotificationWnd);
	void SetEventHandler(LPCOMEVENTHANDLER pEventHandler,DWORD Certificate = 0);


protected:
	DWORD			m_Status;
	HANDLE			m_PortID;
	CP_UART_TYPE		m_UARTType;
	static CSemaphore	m_UARTSync;
	
	// lock status 
	BOOL	m_IsLocked;
	BOOL	m_ThreadLocked;
	DWORD	m_LockerID;

	// parameters
	CString	m_PortName;
	DWORD	m_BaudRate;
	BYTE	m_Parity;
	BYTE	m_ByteSize;
	BYTE	m_StopBits;

	// handshaking
	BOOL	m_UseRtsCts;
	BOOL	m_UseDtrDsr;
	BOOL	m_UseXonXoff;

	// timeouts
	COMMTIMEOUTS	m_ComTimeouts;

	// I/O buffers size
	DWORD	m_SuggestedInputBufferSize;
	DWORD	m_SuggestedOutputBufferSize;

	// port/listener monitor
	ComMutex	m_ComMutex;

	// I/O overlapping support
	OVERLAPPED  m_ReadStruct;
	OVERLAPPED  m_WriteStruct;

 	BOOL CheckError(DWORD Error, BOOL Clear);
};

#endif // !defined(AFX_COMPORT_H__0414FB02_4497_11D2_B636_0000B45C6B2C__INCLUDED_)


