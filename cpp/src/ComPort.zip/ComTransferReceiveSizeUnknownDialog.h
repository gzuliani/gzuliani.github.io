#if !defined(AFX_COMTRANSFERRECEIVESIZEUNKNOWNDIALOG_H__4AD99C61_E017_11D1_B636_444553540000__INCLUDED_)
#define AFX_COMTRANSFERRECEIVESIZEUNKNOWNDIALOG_H__4AD99C61_E017_11D1_B636_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ComTransferReceiveSizeUnknownDialog.h : header file
//

#include "resource.h"
#include "ComTransfer.h"


/////////////////////////////////////////////////////////////////////////////
// ComTransferReceiveSizeUnknownDialog dialog

class ComTransferReceiveSizeUnknownDialog : public CDialog
{
// Construction
public:
	ComTransferReceiveSizeUnknownDialog(ComTransfer* pComTransfer, CWnd* pParent = NULL);   // standard constructor

protected:
// Dialog Data
	//{{AFX_DATA(ComTransferReceiveSizeUnknownDialog)
	enum { IDD = IDD_COMTRANSFER_RECEIVE_SIZEUNKNOWN };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// interface data
	int		m_TimerID;
	DWORD	m_BytesToSend;
	ComTransfer* m_pComTransfer;

	CTime	m_StartTime;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ComTransferReceiveSizeUnknownDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ComTransferReceiveSizeUnknownDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_COMTRANSFERRECEIVESIZEUNKNOWNDIALOG_H__4AD99C61_E017_11D1_B636_444553540000__INCLUDED_)
