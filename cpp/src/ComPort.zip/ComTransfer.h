// ComTransfer.h: interface for the ComTransfer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMTRANSFER_H__0414FB01_4497_11D2_B636_0000B45C6B2C__INCLUDED_)
#define AFX_COMTRANSFER_H__0414FB01_4497_11D2_B636_0000B45C6B2C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


#include "ComPort.h"


class AFX_EXT_CLASS ComTransfer  
{
public:
	// ==============================
	// construction
	ComTransfer(ComPort* pPort);
	~ComTransfer();


	// ==============================
	// main interface
	void AbortTransfer();


	// ==============================
	// data sending
	BOOL Send(LPCTSTR pFileName,				// file to send
			  BOOL OpenDialog = FALSE,			// show window flag
			  BOOL OpenModal = TRUE);			// dialog box type


	BOOL Send(HANDLE File,						// file to send
			  LPCTSTR pBufferName = NULL,
			  BOOL OpenDialog = FALSE,
			  BOOL OpenModal = TRUE);

	BOOL Send(BYTE* pBuffer,					// data to send
			  DWORD BufferLength,
			  LPCTSTR pBufferName = NULL,
			  BOOL CopyBuffer = FALSE,
			  BOOL OpenDialog = FALSE,
			  BOOL OpenModal = TRUE);


	// ==============================
	// data receiving
	BOOL Receive(LPCTSTR pFileName,				// file to save
				 DWORD FileSize = MAXDWORD,		// file size (MAXDWORD is unknown)
				 BOOL OpenDialog = FALSE,		// show window flag
				 BOOL OpenModal = TRUE);		// dialog box type

	BOOL Receive(BYTE* pBuffer,					// user buffer location
				 DWORD BufferSize = MAXDWORD,	// bytes to receive (MAXDWORD is unknown)
				 LPCTSTR pBufferName = NULL,
				 BOOL OpenDialog = FALSE,
				 BOOL OpenModal = TRUE);

	BOOL Receive(BYTE** ppBuffer,				// user buffer location
				 DWORD BufferSize = MAXDWORD,	// bytes to receive (MAXDWORD is unknown)
				 DWORD* pBufferData = NULL,		// bytes actually received
				 LPCTSTR pBufferName = NULL,
				 BOOL OpenDialog = FALSE,
				 BOOL OpenModal = TRUE);

	BOOL DataReceived();
	BOOL FileReceived();

	BOOL IsSending()	{ return m_TxInProgress; }
	BOOL IsReceiving()	{ return m_RxInProgress; }
	BOOL IsAvailable()	{ return (m_pPort->IsOpened() && !m_RxInProgress && !m_TxInProgress); }

	BOOL WasLastSendingSuccessful()		{ return m_TxSuccessfull; }
	BOOL WasLastReceivingSuccessful()	{ return m_RxSuccessfull; }


	// ==============================
	// sending transaction statistics
	DWORD SentBytes()		{ return m_TxInProgress ? m_TxBufferPos : 0; }
	DWORD BytesToSend()		{ return m_TxInProgress ? m_TxBufferSize : 0; }
	DWORD BytesLeftToSend()	{ return m_TxInProgress ? (m_TxBufferSize - m_TxBufferPos) : 0; }

	CString SendingFileName()	{ return m_TxFileName; }
	CString ReceivingFileName()	{ return m_RxFileName; }


	// ==============================
	// receiving transaction statistics
	DWORD ReceivedBytes()		{ return m_RxInProgress ? m_RxBufferPos : 0; }
	DWORD BytesToReceive()		{ return (m_RxInProgress && m_RxBufferSize > 0) ? m_RxBufferSize : 0; }
	DWORD BytesLeftToReceive()	{ return (m_RxInProgress && (m_RxBufferSize > 0)) ? (m_RxBufferSize - m_RxBufferPos) : 0; }

protected:
	ComTransfer();

	// private data
	ComPort*	m_pPort;
	CDialog*	m_pModelessDialog;

	// transmission flags
	BOOL	m_RxInProgress;
	BOOL	m_TxInProgress;
	BOOL	m_TxSuccessfull;
	BOOL	m_RxSuccessfull;
	BOOL	m_ReceivingFile;


	// output buffer
	BYTE*	m_pTxBuffer;	
	BOOL	m_FreeTxBuffer;
	DWORD	m_TxBufferSize;	
	DWORD	m_TxBufferPos;	
	CString m_TxFileName;

	// input buffer
	BYTE*	m_pRxBuffer;	
	BOOL	m_IsRxUnbound;
	DWORD	m_RxBufferSize;	
	DWORD	m_RxBufferPageSize;
	DWORD	m_RxBufferPos;	
	CString m_RxFileName;
	BYTE*	m_pUserBuffer;
	BYTE**	m_ppUserBuffer;
	DWORD*	m_pUserBufferLength;

	// end transactions 
	void CloseTx();
	void CloseRx();

	// receiver protected procedure
	BOOL StartReceiving(DWORD BufferSize = MAXDWORD,
						BOOL OpenDialog = FALSE,
						BOOL OpenModal = TRUE);

	// COM event handler
	static void EventHandler(HANDLE ComPort,DWORD Event,DWORD Param);
};

#endif // !defined(AFX_COMTRANSFER_H__0414FB01_4497_11D2_B636_0000B45C6B2C__INCLUDED_)
