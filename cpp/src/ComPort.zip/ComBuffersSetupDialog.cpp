// ComBuffersSetupDialog.cpp : implementation file
//

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#include "ComBuffersSetupDialog.h"


/////////////////////////////////////////////////////////////////////////////
// ComBuffersSetupDialog dialog

ComBuffersSetupDialog::ComBuffersSetupDialog(ComPort* pComPort, CWnd* pParent /*=NULL*/)
	: CDialog(ComBuffersSetupDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(ComBuffersSetupDialog)
	m_InputSize = 0;
	m_OutputSize = 0;
	//}}AFX_DATA_INIT

	m_pComPort = pComPort;
}

void ComBuffersSetupDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ComBuffersSetupDialog)
	DDX_Text(pDX, IDC_INPUT, m_InputSize);
	DDX_Text(pDX, IDC_OUTPUT, m_OutputSize);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(ComBuffersSetupDialog, CDialog)
	//{{AFX_MSG_MAP(ComBuffersSetupDialog)
	ON_BN_CLICKED(IDC_APPLY, OnApply)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ComBuffersSetupDialog message handlers

BOOL ComBuffersSetupDialog::OnInitDialog() 
{
	if (m_pComPort->IsOpened())
	{
		m_InputSize = m_pComPort->GetInputBufferSize();
		m_OutputSize = m_pComPort->GetOutputBufferSize();
	}

	SetDlgItemInt(IDC_ACTUALINPUT,m_pComPort->GetInputBufferSize());
	SetDlgItemInt(IDC_ACTUALOUTPUT,m_pComPort->GetOutputBufferSize());
	SetDlgItemInt(IDC_MAXINPUT,m_pComPort->GetMaxInputBufferSize());
	SetDlgItemInt(IDC_MAXOUTPUT,m_pComPort->GetMaxOutputBufferSize());

	CDialog::OnInitDialog();
	return TRUE;
}

void ComBuffersSetupDialog::OnApply() 
{
	if (!m_pComPort->IsOpened())
	{
		CString msg((LPCTSTR)IDS_CBSD_COM_NOT_AVAILABLE);
		AfxMessageBox(msg,MB_ICONEXCLAMATION);
		return;
	}

	// update the buffers size
	UpdateData(TRUE);
	m_pComPort->SetSuggestedInputBufferSize(m_InputSize);
	m_pComPort->SetSuggestedOutputBufferSize(m_OutputSize);

	// update the dialog box items
	SetDlgItemInt(IDC_ACTUALINPUT,m_pComPort->GetInputBufferSize());
	SetDlgItemInt(IDC_ACTUALOUTPUT,m_pComPort->GetOutputBufferSize());
	SetDlgItemInt(IDC_MAXINPUT,m_pComPort->GetMaxInputBufferSize());
	SetDlgItemInt(IDC_MAXOUTPUT,m_pComPort->GetMaxOutputBufferSize());
}

