// ComTransferReceiveSizeUnknownDialog.cpp : implementation file
//

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#include "ComTransferReceiveSizeUnknownDialog.h"


/////////////////////////////////////////////////////////////////////////////
// ComTransferReceiveSizeUnknownDialog dialog

#define FTRSUD_CLOCK_ID			1
#define FTRSUD_CLOCK_RESOLUTION	1000

ComTransferReceiveSizeUnknownDialog::ComTransferReceiveSizeUnknownDialog(ComTransfer* pComTransfer, CWnd* pParent /*=NULL*/)
	: CDialog(ComTransferReceiveSizeUnknownDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(ComTransferReceiveSizeUnknownDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_TimerID = 0;
	m_pComTransfer = pComTransfer;
}

void ComTransferReceiveSizeUnknownDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ComTransferReceiveSizeUnknownDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ComTransferReceiveSizeUnknownDialog, CDialog)
	//{{AFX_MSG_MAP(ComTransferReceiveSizeUnknownDialog)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ComTransferReceiveSizeUnknownDialog message handlers

BOOL ComTransferReceiveSizeUnknownDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// initialize the dialog data
	m_BytesToSend = m_pComTransfer->BytesToSend();
	SetDlgItemInt(IDC_RECEIVED,m_pComTransfer->ReceivedBytes());

	// set file name or hide the control
	CString filename = m_pComTransfer->ReceivingFileName();

	if (!filename.IsEmpty())
		SetDlgItemText(IDC_FILENAME,filename);
	else
	{
		GetDlgItem(IDC_FILENAME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_FILENAME_LABEL)->ShowWindow(SW_HIDE);
	}

	// initialize the dialog clock
	m_StartTime = CTime::GetCurrentTime();
	m_TimerID = SetTimer(FTRSUD_CLOCK_ID,FTRSUD_CLOCK_RESOLUTION,NULL);

	return TRUE;
}

void ComTransferReceiveSizeUnknownDialog::OnTimer(UINT nIDEvent) 
{
	// file successfully sent?
	if (!m_pComTransfer->IsReceiving())
	{
		KillTimer(m_TimerID);
		PostMessage(WM_CLOSE);
		return;
	}
	
	if (nIDEvent == (UINT)m_TimerID)
	{
		// time to update the dialog data
		CTime CurrTime = CTime::GetCurrentTime();
		CTimeSpan ElapsedTime = CurrTime - m_StartTime;
		SetDlgItemText(IDC_ELAPSED,ElapsedTime.Format(_T("%H:%M:%S")));
		SetDlgItemInt(IDC_RECEIVED,m_pComTransfer->ReceivedBytes());
	}
	else
		CDialog::OnTimer(nIDEvent);
}

void ComTransferReceiveSizeUnknownDialog::OnCancel() 
{
	// user abortion
	m_pComTransfer->AbortTransfer();
	KillTimer(m_TimerID);
	CDialog::OnCancel();
}

void ComTransferReceiveSizeUnknownDialog::OnOK() 
{
	// user abortion
	if (m_pComTransfer->ReceivingFileName().IsEmpty())
		m_pComTransfer->DataReceived();
	else
		m_pComTransfer->FileReceived();
	
	KillTimer(m_TimerID);
	CDialog::OnOK();
}
