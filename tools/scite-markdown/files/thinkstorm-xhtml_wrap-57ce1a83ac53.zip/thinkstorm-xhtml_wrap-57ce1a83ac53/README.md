xhtml_wrap extension
====================

Extension for the
[Markdown in Python](http://www.freewisdom.org/projects/python-markdown/)
implementation of John Gruber's
[Markdown](http://daringfireball.net/projects/markdown/) that wraps
the output in XHTML, optionally adding a title and a CSS URL. This is
to match the output from Jason Blevins' [markdown-mode](http://jblevins.org/projects/markdown-mode/) for Emacs

Example usage:

`python markdown.py <options> -x xhtml_wrap\(title="<your_title>",css_url="<your_css_url>", js_url="<your_javascript_url>"\) <input_file>`
