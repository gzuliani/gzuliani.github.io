var h1Header = {
    h1:1 /*,
    h2:1,
    h3:1,
    h4:1,
    h5:1,
    h6:1 */
};
function addChapters(root) {
    if( root.nodeType === 1 && root.nodeName !== 'script' ) {
        if( h1Header.hasOwnProperty(root.nodeName.toLowerCase()) ) {
		root.innerHTML = "<span class=\"headerNumber\">"  + h1Header.h1  + "</span>" + root.innerHTML;
		h1Header.h1++;
        } else {
            for( var i = 0; i < root.childNodes.length; i++ ) {
                addChapters( root.childNodes[i] );
            }
        }
    }
}
function linkify(text) {
	// http://, https://, ftp://
	var urlPattern = /(^|[^"])\b(?:https?|ftp):\/\/[a-z0-9-+&@#\/%?=~_|!:,.;]*[a-z0-9-+&@#\/%=~_|]/gim;
	// www. sans http:// or https://
	var pseudoUrlPattern = /(^|[^"\/])(www\.[\S]+(\b|$))/gim;
	// Email addresses
	var emailAddressPattern = /\w+@[a-zA-Z_]+?(?:\.[a-zA-Z]{2,6})+/gim;
	return text
		.replace(urlPattern, '<a href="$&" target="_new">$&</a>')
		.replace(pseudoUrlPattern, '$1<a href="http://$2" target="_new">$2</a>')
		.replace(emailAddressPattern, '<a href="mailto:$&">$&</a>');
};
function markings(text) {
	// [IMP]
	var em_style1 = /(\[IMP\])/gi;
	// [DRAFT]
	var em_style2 = /(\[DRAFT\])/gi;
	// [FINAL]
	var em_style3 = /(\[FINAL\])/gi;
	// [PARTNER]
	var em_style4 = /(\[PARTNER\])/gi;
	return text
		.replace(em_style1, '<em class="em_style1">$1</em>')
		.replace(em_style2, '<em class="em_style2">$1</em>')
		.replace(em_style3, '<em class="em_style3">$1</em>')
		.replace(em_style4, '<em class="em_style4">$1</em>');		
}
window.onload=function(){
	addChapters(document.body);
	document.body.innerHTML = markings(linkify(document.body.innerHTML));
 }
