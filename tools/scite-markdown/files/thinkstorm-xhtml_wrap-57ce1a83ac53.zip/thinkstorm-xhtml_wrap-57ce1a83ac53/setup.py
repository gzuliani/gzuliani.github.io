#! /usr/bin/env python

from setuptools import setup

setup(
    name='mdx_xhtml_wrap',
    version='0.1',
    author='Paul Provost',
    author_email='paul@paulprovost.me',
    description='Python-Markdown extension to add xhtml wrapper for Markdown output; options title and css_url',
#    long_description=open('README.rst').read(),
    url='https://bitbucket.org/paulprovost/xhtml_wrap',
    py_modules=['mdx_xhtml_wrap'],
    install_requires=['markdown>=2.0','namedentities>=1.2'],
    tests_require = ['tox', 'pytest'],
    zip_safe = False,
    keywords='markdown xhtml wrapper css title extension',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Operating System :: OS Independent',
        'License :: OSI Approved :: BSD License',
        'Intended Audience :: Developers',
        'Environment :: Web Environment',
        'Programming Language :: Python',
        'Programming Language :: Python :: 2.5',
        'Programming Language :: Python :: 2.6',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.2',
        'Programming Language :: Python :: 3.3',
        'Programming Language :: Python :: Implementation :: CPython',
        'Programming Language :: Python :: Implementation :: PyPy',
        'Topic :: Text Processing :: Filters',
        'Topic :: Text Processing :: Markup',
        'Topic :: Text Processing :: Markup :: HTML'
    ]
)
