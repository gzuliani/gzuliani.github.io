#!/usr/bin/env python

"""
XHTML Wrap Extension for Python-Markdown
========================================

Adds a XHTML wrapper with an optional page title and CSS URL. Much like Jason
Blevins' markdown-mode for Emacs (http://jblevins.org/projects/markdown-mode/).

Copyright (c)2011 [Paul Provost](http://paulprovost.me)

License: [BSD](http://www.opensource.org/licenses/bsd-license.php) 

Usage: add `-x xhtml_wrap(title="page title", css_url="cssfile.css", js_url="script.js")` to markdown_py

Dependencies:
* [Python2.3+](http://python.org)
* [Markdown 2.0+](http://www.freewisdom.org/projects/python-markdown/)

"""

from markdown.postprocessors import Postprocessor
from markdown.extensions import Extension

class XHTMLWrapExt(Extension):

    def __init__(self, configs):
        # Set defaults to match typical markdown behavior.
        self.config = dict(title="",
                           css_url="",
                           js_url=""
                          )
        # Merge in user defined configs overriding any present if nessecary.
        for c in configs:
            self.config[c[0]] = c[1]

    def extendMarkdown(self, md, md_globals):
        # Save options to markdown instance
        md.xhtml_wrap_options = self.config
        # Add XHTMLWrapProcessor to postprocessors
        md.postprocessors.add('xhtml_wrap', XHTMLWrapPost(md), '_end')
        #md.postprocessors['xhtml_wrap'] = XHTMLWrapProcessor(md)


class XHTMLWrapPost(Postprocessor):

    def run(self, text):
        return ("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n"
                + "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"\n"
                + "\t\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n\n"
                + "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n\n"
                + "<head>\n"
                + (("<title>"
                    + self.markdown.xhtml_wrap_options["title"]
                    + "</title>\n")
                   if (len(self.markdown.xhtml_wrap_options["title"]) != 0)
                   else "")
                + (("<link rel=\"stylesheet\" type=\"text/css\" media=\"all\" href=\""
                    + self.markdown.xhtml_wrap_options["css_url"]
                    + "\"  />\n")
                   if (len(self.markdown.xhtml_wrap_options["css_url"]) != 0)
                   else "")
                + (("<script type=\"text/javascript\" media=\"all\" src=\""
                    + self.markdown.xhtml_wrap_options["js_url"]
                    + "\"></script>\n")
                   if (len(self.markdown.xhtml_wrap_options["js_url"]) != 0)
                   else "")
                + "\n</head>\n\n"
                + "<body>\n\n"
                + text
                + "\n"
                + "</body>\n"
                + "</html>\n")


def makeExtension(configs=None):
	return XHTMLWrapExt(configs=configs)
	