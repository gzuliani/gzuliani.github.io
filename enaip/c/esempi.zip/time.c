#include <time.h>
#include <stdio.h>

void main(void)
{
	clock_t tempo_cpu;
	time_t tempo_trascorso;
	time_t tempo_trascorso_aux;
	double intervallo;
	struct tm* pdata_ora;
	struct tm* pdata_ora_gm;
	char data_ora_italiana[21]; /* gg/mm/aaaa, hh:mm:ss0 */

	/* ricava l'ora attuale */
	time(&tempo_trascorso);
	printf("secondi trascorsi da 01/01/1970 00:00:00 = %d\n", tempo_trascorso);
   
	/* esempio di chiamata ctime */
	printf("data e ora (dai secondi trascorsi): %s", ctime(&tempo_trascorso));

	/* esempio di chiamata gmtime */
	pdata_ora_gm = gmtime(&tempo_trascorso);
	printf("parametri temporali universali (UTC):\n");
	printf("   anno..................: %d\n", pdata_ora_gm->tm_year);
	printf("   mese..................: %d\n", pdata_ora_gm->tm_mon);
	printf("   giorno del mese.......: %d\n", pdata_ora_gm->tm_mday);
	printf("   giorno della settimana: %d\n", pdata_ora_gm->tm_wday);
	printf("   giorno dell'anno......: %d\n", pdata_ora_gm->tm_yday);
	printf("   ore...................: %d\n", pdata_ora_gm->tm_hour);
	printf("   minuti................: %d\n", pdata_ora_gm->tm_min);
	printf("   secondi...............: %d\n", pdata_ora_gm->tm_sec);
	printf("   ora legale............: %d\n", pdata_ora_gm->tm_isdst);
    
	/* esempio di chiamata localtime */
	pdata_ora = localtime(&tempo_trascorso);
	printf("parametri temporali locali:\n");
	printf("   anno..................: %d\n", pdata_ora->tm_year);
	printf("   mese..................: %d\n", pdata_ora->tm_mon);
	printf("   giorno del mese.......: %d\n", pdata_ora->tm_mday);
	printf("   giorno della settimana: %d\n", pdata_ora->tm_wday);
	printf("   giorno dell'anno......: %d\n", pdata_ora->tm_yday);
	printf("   ore...................: %d\n", pdata_ora->tm_hour);
	printf("   minuti................: %d\n", pdata_ora->tm_min);
	printf("   secondi...............: %d\n", pdata_ora->tm_sec);
	printf("   ora legale............: %d\n", pdata_ora->tm_isdst);
 
	/* esempio di chiamata asctime */
	printf("data e ora (dai parametri temporali): %s", asctime(pdata_ora));

	/* esempio di chiamata strftime */
	strftime(data_ora_italiana, 21, "%d/%m/%Y, %H:%M:%S", pdata_ora);
	printf("data e ora in formato italiano: %s\n", data_ora_italiana);

	time(&tempo_trascorso_aux);
	intervallo = difftime(tempo_trascorso_aux, tempo_trascorso);
	printf("tempo trascorso dall'inizio del programma: %.0f secondi\n", intervallo);

	/* esempio chiamata clock */
	tempo_cpu = clock();
	printf("tempo cpu impiegato dal programma: %d cicli di clock\n", tempo_cpu);
}
