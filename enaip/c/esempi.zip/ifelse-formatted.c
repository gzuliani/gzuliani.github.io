#include <stdio.h>

int main()
{
	int a, b, c, d;
	scanf("%d %d %d", &a, &b, &c);

	if (a > b)
		if (b > c)
			d = c;
		else
			d = b;
	else
		if (a > c)
			d = c;
		else
			d = a;
	
	printf("%d", d);
	return 0;
}