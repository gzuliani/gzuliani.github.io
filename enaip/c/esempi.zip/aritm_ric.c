#include <stdio.h>

unsigned somma(unsigned a, unsigned b);
unsigned differenza(unsigned a, unsigned b);
unsigned prodotto(unsigned a, unsigned b);
unsigned quoto(unsigned a, unsigned b);
unsigned resto(unsigned a, unsigned b);

/* operazioni aritmetiche ricorsive - ipotesi: a > b > 0 */
int main()
{
	unsigned a, b;

	scanf("%d %d", &a, &b);
	printf("%d + %d = %d\n", a, b, somma(a, b));
	printf("%d - %d = %d\n", a, b, differenza(a, b));
	printf("%d * %d = %d\n", a, b, prodotto(a, b));
	printf("%d : %d = %d, r = %d\n", a, b, quoto(a, b), resto(a, b));
	return 0;
}

unsigned somma(unsigned a, unsigned b)
{
	return (b == 0) ? a : somma(a, b - 1) + 1;
}

unsigned differenza(unsigned a, unsigned b)
{
	return (b == 0) ? a : differenza(a, b-1) - 1;
}

unsigned prodotto(unsigned a, unsigned b)
{
	return (b == 1) ? a : prodotto(a, b - 1) + a;
}

unsigned quoto(unsigned a, unsigned b)
{
	return (a < b) ? 0 : quoto(a - b, b) + 1;
}

unsigned resto(unsigned a, unsigned b)
{
	return (a < b) ? a : resto(a - b, b);
}
