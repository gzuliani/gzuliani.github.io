#include <stdio.h>

/* converte uno short in binario */
int main()
{
	short n, pos, bit, bits;
	bits = sizeof(n) * 8;

	scanf("%d", &n);
	printf("%d dec = ", n);

	for (pos = bits  - 1; pos > -1; --pos)
	{
		bit = (n >> pos) & 1;
		printf("%1d", bit);
	}

	printf(" bin");
	return 0;
}