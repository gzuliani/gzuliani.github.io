#include <stdio.h>

int power(int m, int n);

/* usa la funzione power */
main()
{
    int i;
    
    for (i = 0; i < 10; ++i)
        printf("%2d %5d %8d\n", i, power(2, i), power(-3, i));
    return 0;
}
 
/* power: eleva base all'n-esima potenza; n >= 0; versione 3, ricorsiva */
int power(int base, int n)
{
    int p;
    
    if (n == 0)
      p = 1;
   else
      p = base * power(base, n - 1);

    return p;
}       

