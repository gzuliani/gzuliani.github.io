#include <stdio.h>

/* costanti simboliche */
#define N 3                     /* ordine della matrice         */
#define K (N * (N * N + 1) / 2) /* caratteristica della matrice */

/* dichiarazione delle funzioni */
int verifica_righe(void);
int verifica_colonne(void);
int verifica_diagonali(void);

/* variabili globali */
int quadrato[N][N];

/* verifica se una matrice e' un quadrato magico */
int main()
{
    int i, r, c;

    printf("Quadrato magico di ordine %d\n", N);
    printf("\n");

    /* lettura della matrice */
    for (i = 1; i < N * N + 1; i++)
    {
        do
        {
            printf("Posizione di %d [r c]: ", i);
            scanf("%d %d", &r, &c);
        
        } while (r < 0 || r > N - 1 || c < 0 || c > N - 1 || quadrato[r][c] != 0);

        quadrato[r][c] = i;
    }
    
    /* visualizza la matrice */
    printf("\n");
    printf("La matrice:\n");
    printf("\n");
    for (r = 0; r < N; r++)
    {
        for (c = 0; c < N; c++)
            printf("%3d", quadrato[r][c]);
        printf("\n");
    }

    /* esegui la verifica ed emetti il responso */
    printf("\n");

    if (verifica_righe() && verifica_colonne() && verifica_diagonali())
        printf("e' ");
    else
        printf("non e' ");

    printf("un quadrato magico\n");
    return 0;
}

int verifica_righe(void)
{
    int r, c, somma;
    
    for (r = 0; r < N; r++)
    {
        somma = 0;
        
        for (c = 0; c < N; c++)
            somma += quadrato[r][c];
    
        if (somma != K)
            return 0;
    }
    
    return 1;
}

int verifica_colonne(void)
{
    int r, c, somma;
    
    for (c = 0; c < N; c++)
    {
        somma = 0;
        
        for (r = 0; r < N; r++)
            somma += quadrato[r][c];
    
        if (somma != K)
            return 0;
    }
    
    return 1;
}

int verifica_diagonali(void)
{
    int i, somma;

    /* diagonale principale */  
    somma = 0;

    for (i = 0; i < N; i++)
        somma += quadrato[i][i];
    
    if (somma != K)
        return 0;
    
    /* diagonale secondaria */  
    somma = 0;

    for (i = 0; i < N; i++)
        somma += quadrato[i][N - 1 - i];
    
    if (somma != K)
        return 0;

    return 1;
}