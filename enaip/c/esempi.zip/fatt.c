#include <stdio.h>

int fatt(int n);
int fatt_r(int n);

/* determina il fattoriale */
int main()
{
    int n;
    scanf("%d", &n);
    printf("%d! = %d (%d)", n, fatt(n), fatt_r(n));
    return 0;
}

/* versione iterativa */
int fatt(int n)
{
    int f = 1;
   
    while (n > 0)     /* while (n > 0)  */
    {                 /*  f *= n--;     */
       f = f * n;
       --n;
    }

	 return f;
}

/* versione ricorsiva */
int fatt_r(int n)
{
    return (n == 0) ? 1 : n * fatt(n - 1);
}
