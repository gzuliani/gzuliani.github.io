#include <stdio.h>
#include <stdlib.h> /* atoi */
#include <ctype.h>  /* toupper */
#include <string.h> /* strncpy, strncmp, strlen */

/* macro */
#define MIN(x,y) (x > y) ? (y) : (x)
#define MAX(x,y) (x > y) ? (x) : (y)

/* costanti simboliche */
#define MAX_LINEA   100 /* lunghezza della linea di input    */
#define MAX_AUTORE   30 /* lunghezza del nome dell'autore    */
#define MAX_TITOLO  100 /* lunghezza del titolo del libro    */
#define MAX_CHIAVE   10 /* lunghezza della chiave di ricerca */
#define MAX_LIBRI   100 /* numero di libri in biblioteca     */

/* tipi di dato */
enum tag_booleano { FALSO = 0, VERO = 1};

typedef enum tag_booleano booleano;

struct tag_libro
{
    char autore[MAX_AUTORE + 1]; /* + 1 per il terminatore! */
    char titolo[MAX_TITOLO + 1]; /* + 1 per il terminatore! */
    int anno;
};

typedef struct tag_libro libro;
typedef struct tag_libro* plibro;
typedef const struct tag_libro* pclibro;

/* dichiarazione delle funzioni */
void leggi_libro(plibro pl);
void visualizza_libro(pclibro pl);

/* funzioni di utilita' generica */
void leggi_numero(const char* pmessaggio, int* pnumero);
void leggi_stringa(const char* pmessaggio, char* pstringa, int lun_stringa);

int main()
{
    libro biblio[MAX_LIBRI];     /* biblioteca                    */

    FILE* pfile;                 /* archivio della biblioteca     */
    int comando;                 /* comando del menu              */
    int num_libri;               /* numero di libri in biblioteca */
    char chiave[MAX_CHIAVE + 1]; /* chiave di ricerca             */
    char risposta[MAX_LINEA];    /* risposta dell'utente          */

    /* variabili ausiliarie */
    char* pc;
    int i, j;

    num_libri = 0;

    do
    {
        /* visualizzazione del menu */
        printf("\n");
        printf("\n");
        printf("\n");
        printf("GESTIONE BIBLIOTECA\n");
        printf("Volumi presenti: %d\n", num_libri);
        printf("\n");
        printf("1 - Inserisci libro\n");
        printf("2 - Cancella libro\n");
        printf("3 - Cerca libro per autore\n");
        printf("4 - Cerca libro per titolo\n");
        printf("5 - Ordina biblioteca per autore\n");
        printf("6 - Ordina biblioteca per titolo\n");
        printf("7 - Visualizza biblioteca\n");
        printf("8 - Carica biblioteca\n");
        printf("9 - Salva biblioteca\n");
        printf("0 - Uscita\n");
    
        /* lettura del comando */
        printf("\n");
        leggi_numero("Comando: ", &comando);

        /* esecuzione del comando */
        switch (comando)
        {
            case 0: /* Uscita */
                break;

            case 1: /* Inserisci libro */
                
                if (num_libri < MAX_LIBRI)
                {
                    leggi_libro(&biblio[num_libri]);
                    num_libri++;

                    printf("Libro inserito.\n");
                }
                else
                    printf("Spazio esaurito.\n");
                break;

            case 2: /* Cancella libro */
                
                if (num_libri < 1)
                {
                    printf("Nessun libro da cancellare.\n");
                    break;
                }

                /* richiedi il libro da cancellare */
                leggi_numero("Libro da cancellare: ", &i);

                /* normalizza l'indice */
                i--;

                /* verifica della bonta' dell'indice */
                if (i < 0 || i > num_libri - 1)
                    printf("Libro inesistente.\n");
                else
                {
                    /* conferma la cancellazione del libro */
                    printf("Rimuovere il libro:\n");
                    visualizza_libro(&biblio[i]);
                    printf("\n");
                    leggi_stringa("Conferma S/[N]: ", risposta, MAX_LINEA);

                    if (toupper (risposta[0]) == 'S')
                    {
                        /* esegui la cancellazione del libro */
                        for (j = i + 1; j < num_libri; j++)
                            biblio[j - 1] = biblio[j];

                        num_libri--;
                        printf("Cancellazione effettuata.\n");
                    }
                    else
                        printf("Cancellazione annullata.\n");
                }
                
                break;

            case 3: /* Cerca libro per autore */
            case 4: /* Cerca libro per titolo */
                
                /* richiedi la chiave di ricerca */
                leggi_stringa("Chiave di ricerca: ", chiave, MAX_CHIAVE);
                
                if (strlen(chiave) == 0)
                {
                    printf("Chiave di ricerca non valida.\n");
                    break;
                }

                /* conta i libri trovati */
                j = 0;
                                
                for (i = 0; i < num_libri; i++)
                {
                    char* pconfr = biblio[i].titolo;

                    if (comando == 3)
                        pc = biblio[i].autore;
                    else
                        pc = biblio[i].titolo;

                    if (strncmp(pc, chiave, strlen(chiave)) == 0)
                    {
                        /* il libro i-esimo soddisfa il criterio di ricerca */
                        printf("\n");
                        printf("Libro n. %d\n", i + 1);
                        visualizza_libro(&biblio[i]);

                        /* visualizza il prossimo risultato */
                        printf("\n");
                        leggi_stringa("Prossimo [S]/N: ", risposta, MAX_LINEA);

                        j++;
                    }
                }

                if (j == 0)
                    printf("Nessun libro trovato.\n");
                else if (j == 1)
                    printf("Un solo libro trovato.\n");
                else
                    printf("Trovati %d libri.\n", j);

                break;

            case 5: /* Ordina biblioteca per autore */
            case 6: /* Ordina biblioteca per titolo */
            {
                /* ordina con un bubble sort */
                libro *l1, *l2, temp;
                booleano scambio, ordinati;

                i = 0;
                scambio = VERO;

                while ((i < num_libri - 1) && scambio)
                {
                    scambio = FALSO;

                    for (j = num_libri - 1; j > i; j--)
                    {
                        l1 = &biblio[j - 1];
                        l2 = &biblio[j];

                        if (comando == 5)
                            ordinati = (strcmp(l1->autore, l2->autore) < 0);
                        else
                            ordinati = (strcmp(l1->titolo, l2->titolo) < 0);
                        
                        if (! ordinati)
                        {
                            scambio = VERO;

                            temp = biblio[j];
                            biblio[j] = biblio[j - 1];
                            biblio[j - 1] = temp;
                        }
                    }

                    i++;
                }

                printf("Ordinamento eseguito.\n");
                break;
            }

            case 7: /* Visualizza biblioteca */

                if (num_libri == 0)
                {
                    printf("La biblioteca non contiene alcun libro.\n");
                    break;
                }
                
                for (i = 0; i < num_libri; i++)
                {
                    /* visualizza il libro in posizione i */
                    printf("\n");
                    printf("Libro n. %d\n", i + 1);
                    visualizza_libro(&biblio[i]);
                    
                    /* conferma la prosecuzione del ciclo */
                    if (i != num_libri - 1)
                    {
                        printf("\n");
                        leggi_stringa("Continuare [S]/N: ", risposta, MAX_LINEA);
                    
                        /* uscita anticipata su richiesta */
                        if (strlen(risposta) > 0)
                            break;
                    }
                }
            
                break;

            case 8: /* Carica biblioteca */

                printf("comando non implementato.\n");
                break;

            case 9: /* Salva biblioteca */

                printf("comando non implementato.\n");
                break;

            default:
                printf("Comando sconosciuto.\n");
                break;
        }

        /* pausa... */
        if (comando != 0)
            leggi_stringa(NULL, risposta, MAX_LINEA);

    } while (comando != 0);

    return 0;
}

void leggi_libro(plibro pl)
{
    leggi_stringa("Autore: ", pl->autore, MAX_AUTORE);
    leggi_stringa("Titolo: ", pl->titolo, MAX_TITOLO);
    leggi_numero("Anno di pubblicazione: ", &pl->anno);
}

void visualizza_libro(pclibro pl)
{
    printf("Autore: %s\n", pl->autore);
    printf("Titolo: %s\n", pl->titolo);
    printf("Anno di pubblicazione: %d\n", pl->anno);
}

int carica_libro(FILE* pfile, plibro pl)
{
    return fread(pl, sizeof(libro), 1, pfile);
}

int salva_libro(FILE* pfile, pclibro pl)
{
    return fwrite(pl, sizeof(libro), 1, pfile);
}

void leggi_numero(const char* pmessaggio, int* pnumero)
{
    char linea[MAX_LINEA];

    /* visualizza il messaggio */
    printf(pmessaggio);

    /* leggi la linea di input */
    gets(linea);
    *pnumero = atoi(linea);
}

void leggi_stringa(const char* pmessaggio, char* pstringa, int lun_stringa)
{
    char linea[MAX_LINEA];
    int lun_linea;

    /* visualizza il messaggio */
    if (pmessaggio != NULL)
        printf(pmessaggio);

    /* leggi la linea di input */
    gets(linea);
    strncpy(pstringa, linea, lun_stringa);

    /* inserisci il terminatore di stringa */
    lun_linea = strlen(linea);
    pstringa[MIN(lun_linea, lun_stringa)] = '\0';
}
