#include <stdio.h>
#include <ctype.h> /* isprint */

#define MAX_BUFFER 100;

/* verifica il comportamento di fopen su file testuali/binari */
int main()
{
    char c;
    FILE* pfile;

    if ((pfile = fopen("test.dat", "wt")) == NULL)
    {
        printf("Errore apertura file.\n");
        return -1;
    }
    
    fputs("Prima riga.\nSeconda riga.", pfile);
    fclose(pfile);

    if ((pfile = fopen("test.dat", "rb")) == NULL)
    {
        printf("Errore apertura file.\n");
        return -1;
    }
    
    while ((c = fgetc(pfile)) != EOF)
    {
        if (isprint(c))
            printf("%c", c);
        else
            printf("0x%02X", c);
    }
    
    fclose(pfile);
    return 0;
}
