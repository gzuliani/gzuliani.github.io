#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define VERO     1
#define FALSO    0

#define N       10
#define MAXVAL 100

void inizializza_vettore(void);
void visualizza_vettore(void);
void selection_sort(void);
void bubble_sort(void);
void insertion_sort(void);
void shell_sort(void);
void quick_sort(void);
void quick_sort_aux(int inizio, int fine);

int vettore[N];
int confronti, scambi;

/* ordinamento di un vettore */
int main(void)
{
    int comando, ordinamento_eseguito;

    /* inizializza il generatore di numeri casuali */
    srand(time(0));

    do
    {
        /* visualizza il menu principale */
        printf("\n");
        printf("\n");
        printf("\n");
        printf("Ordinamento di un vettore \n");
        printf("\n");
        printf("1 - selection sort\n");
        printf("2 - bubble sort\n");
        printf("3 - insertion sort\n");
        printf("4 - shell sort\n");
        printf("5 - quick sort\n");
        printf("0 - fine\n");
        printf("\n");
        printf("Scelta: ");
        scanf("%d", &comando);
        printf("\n");

        /* prepara il vettore da ordinare */
        if (comando != 0)
        {
            inizializza_vettore();
            printf("vettore iniziale: ");
            visualizza_vettore();
        }

        switch (comando)
        {
            case 1:
                selection_sort();
                ordinamento_eseguito = VERO;
                break;

            case 2:
                bubble_sort();
                ordinamento_eseguito = VERO;
                break;

            case 3:
                insertion_sort();
                ordinamento_eseguito = VERO;
                break;

            case 4:
                shell_sort();
                ordinamento_eseguito = VERO;
                break;

            case 5:
                quick_sort();
                ordinamento_eseguito = VERO;
                break;

            default:
                ordinamento_eseguito = FALSO;
                break;
        }
    
        if (ordinamento_eseguito)
        {
            printf("vettore ordinato: ");
            visualizza_vettore();
            printf("\neseguiti %d confronti e %d scambi\n", confronti, scambi);
        }

    } while (comando != 0);
    
    return 0;
}

void inizializza_vettore(void)
{
    int i;

    for (i = 0; i < N; i++)
        vettore[i] = rand() % MAXVAL; /* vettore pseudo-casuale */
}

void visualizza_vettore(void)
{
    int i;

    for (i = 0; i < N; i++)
        printf("%3d", vettore[i]);

    printf("\n");

}

/* ordinamento semplice - estrazione del minimo */
void selection_sort(void)
{
    int i, j, min, temp;

    confronti = 0;
    scambi = 0;

    /* considera uno a uno tutti elementi del vettore tranne l'ultimo */
    for (i = 0; i < N - 1; i++)
    {
        /* ricerca il minimo tra l'elemento corrente ed i successivi */
        min = i;

        for (j = i + 1; j < N; j++)
        {
            confronti++;

            if (vettore[j] < vettore[min])
                min = j;
        }

        /* sposta il minimo in posizione corrente */
        if (vettore[min] < vettore[i])
        {
            scambi++;

            temp = vettore[min];
            vettore[min] = vettore[i];
            vettore[i] = temp;
        }
    }
}

/* ordinamento a bolle - termina immediatamente su un vettore ordinato */
void bubble_sort(void)
{
    int i, j, temp, ordinato;

    confronti = 0;
    scambi = 0;

    i = 0;
    ordinato = FALSO;

    /* finche' il vettore non risulta ordinato... */
    while ((i < N - 1) && ! ordinato)
    {
        /* controlla che le coppie di elementi adiacenti siano ordinate */
        ordinato = VERO;

        /* NOTA: al termine del ciclo, il minimo si trovera' in posizione i */
        for (j = N - 1; j > i; j--)
        {
            confronti++;

            /* ordina le coppie non ordinate */
            if (vettore[j] < vettore[j - 1])
            {
                scambi++;
                ordinato = FALSO;

                temp = vettore[j];
                vettore[j] = vettore[j - 1];
                vettore[j - 1] = temp;
            }
        }

        /* prosegui con il prossimo elemento */
        i++;
    }
}

/* ordinamento a inserimento - mantiene ordinata la parte iniziale del vettore */
void insertion_sort(void)
{
    int i, j, temp;

    confronti = 0;
    scambi = 0;

    for (i = 1; i < N; i++)
    {
        /* ricerca la posizione che l'elemento corrente */
        /* dovrebbe ricoprire nella porzione 0, i - 1   */
        temp = vettore[i];
        j = i;

        /* sposta l'elemento nella sua posizione corretta */
        while (j > 0 && temp < vettore[j - 1])
        {
            confronti++;

            vettore[j] = vettore[j - 1];
            j--;
        }

        vettore[j] = temp;
        scambi++;
    }
}

/* ordinamento di shell: insertion su distanze decrescenti */
void shell_sort(void)
{
    int i, j, temp, distanza;
    
    confronti = 0;
    scambi = 0;
    distanza = N / 2;

    while (distanza > 0)
    {
        for (i = distanza; i < N; i++)
        {
            temp = vettore[i];

            /* confronta l'elemento corrente con i precedenti       */
            /* che distano <distanza>, applicando un insertion-sort */
            j = i;

            while (j >= distanza && temp < vettore[j - distanza])
            {
                confronti++;

                vettore[j] = vettore[j - distanza];
                j -= distanza;
            }

            vettore[j] = temp;
            scambi++;
        }

        /* dimezza la distanza */
        distanza /= 2;
    }
}

/* ordinamento ricorsivo */
void quick_sort(void)
{
    confronti = 0;
    scambi = 0;

    quick_sort_aux(0, N - 1);
}

void quick_sort_aux(int inizio, int fine)
{
    int i, j, perno, temp;

    if (inizio < fine)
    {
        /* determina l'elemento mediano della parte di vettore da ordinare */
        i = inizio;
        j = fine;
        perno = vettore[(inizio + fine) / 2];

        do
        {
            /* cerca il primo elemento a sinistra del perno che lo supera */
            while (vettore[i] < perno)
            {
                confronti++;
                i++;
            }

            /* cerca il primo elemento a destra del perno che gli e' inferiore */
            while (vettore[j] > perno)
            {
                confronti++;
                j--;
            }

            if (i <= j)
            {
                scambi++;

                temp = vettore[i];
                vettore[i] = vettore[j];
                vettore[j] = temp;

                i++;
                j--;
            }
    
        } while (i <= j);

        /* tutti gli elementi a sinistra del perno gli sono inferiori,  */
        /* quelli a destra superiori: ordina separatamente le due parti */
        quick_sort_aux(inizio, j);
        quick_sort_aux(i, fine);
    }
}
