#include <stdio.h>

/* complementa a due uno short mediante l'algoritmo mnemonico */
int main()
{
	short n, cpl, bits, pos;
	bits = sizeof(n) * 8;

	scanf("%d", &n);
	cpl = n;

	/* cerca il primo bit a 1 */
	pos = 0;

	while ((pos < bits) && ((cpl & (1 << pos)) == 0))
		++pos;

	/* il primo bit a 1 resta inalterato */
	++pos;

	/* complementa i restanti bit */
	while (pos < bits)
	{
		cpl ^= (1 << pos);
		++pos;
	}

	printf("cpl2(%d) = %d", n, cpl);
	return 0;
}