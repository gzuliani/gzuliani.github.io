#include <stdio.h>
#include <string.h>

/* costanti simboliche */
#define MAX_STRING 1024

/* dichiarazione delle funzioni */
void applica_piglatin(const char* pstringa, char* pout);

/* trasforma una stringa in pig-latin */
int main()
{
    char stringa[MAX_STRING], stringa_piglatin[MAX_STRING];
    
    gets(stringa);
    applica_piglatin(stringa, stringa_piglatin);
    puts(stringa_piglatin);

    return 0;
}

void applica_piglatin(const char* pin, char* pout)
{
    const char* pinizio;
    const char* pfine;
    const char* pparola;
    
    pinizio = pin;

    do
    {
        /* cerca l'inizio della prossima parola */
        while ((*pinizio != 0) && (*pinizio == ' ' || *pinizio == '\t'))
        {
            /* ricopia in pout tutti gli eventuali spazi trovati in pin */
            *pout = *pinizio;
            pinizio++;
            pout++;
        }

        /* raggiunta la fine della stringa? */
        if (*pinizio == 0)
        {
            /* inserisci il terminatore di stringa di pout */
            *pout = '\0';
            break;
        }

        /* raggiungi la fine della parola */
        pfine = pinizio;

        while ((*pfine != 0) && *pfine != ' ' && *pfine != '\t')
            pfine++;

        /* ora pinizio punta al primo carattere,       */
        /* pfine al carattere successivo all'ultimo... */
        
        /* ricopia la parola in piglatin a partire dalla seconda lettera */
        pparola = pinizio + 1;
        
        while (pparola != pfine)
        {
            *pout = *pparola;
            pout++;
            pparola++;
        }

        /* aggiungi il primo carattere... */
        *pout = *pinizio;
        pout++;

        /* ... infine aggiungi una 'd' */
        *pout = 'd';
        pout++;

        /* ricomincia il ciclo per la prossima parola */
        pinizio = pfine;

    } while (*pfine != 0);

    /* inserisci il terminatore di stringa di pout */
    *pout = '\0';
}
