#include <stdio.h>

#define CELLE     80
#define ORGANISMO '*'
#define SPAZIO    ' '

int main()
{
    int i, vicini, generazioni;
    char automa[CELLE], temp[CELLE];

    /* inizializzazione dell'automa */
    for (i = 0; i < CELLE; i++)
        automa[i] = SPAZIO;

    automa[CELLE / 2] = ORGANISMO;

    printf("Numero di generazioni: ");
    scanf("%d", &generazioni);

    while (generazioni > 0)
    {
        /* visualizza la generazione corrente */
        for (i = 0; i < CELLE; i++)
            printf("%c", automa[i]);

        /* determina la prossima generazione */
        for (i = 0; i < CELLE; i++)
        {
             vicini = 0;

             if (i > 0 && automa[i - 1] == ORGANISMO)
                 vicini++;

             if (i < CELLE -1 && automa[i + 1] == ORGANISMO)
                 vicini++;

             temp[i] = (vicini == 1) ? ORGANISMO : SPAZIO;
        }

        for (i = 0; i < CELLE; i++)
            automa[i] = temp[i];

        generazioni--;
    }
    return 0;
}
