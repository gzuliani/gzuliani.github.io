#include <stdio.h>

char change_bit(unsigned char c, short pos);
void print_char(unsigned char c);

/* altera i bit di un byte */
int main()
{
	short pos, bits;
	unsigned char c = 0;

	print_char(c);
	scanf("%d", &pos);

	bits = sizeof(c) * 8;

	while ((pos > -1) && (pos < bits))
	{
		c = change_bit(c, pos);
		print_char(c);
		scanf("%d", &pos);
	}

	return 0;
}

/* altera il bit pos di c */
char change_bit(unsigned char c, short pos)
{
	return c ^ (1 << pos);
}

/* visualizza c in binario */
void print_char(unsigned char c)
{
	short pos, bit, bits;
	bits = sizeof(c) * 8;

	for (pos = bits  - 1; pos > -1; --pos)
	{
		bit = (c >> pos) & 1;
		printf("%1d", bit);
	}

	printf(" [0x%02X] \n", c);
}
