#include <stdio.h>

void sposta_torre(int dischi, int partenza, int destinazione, int perno);

/* torre di hanoi */
int main()
{
	int h;

	printf("Altezza della torre: ");
	scanf("%d", &h);
	printf("\n");
	sposta_torre(h, 1, 3, 2);
	return 0;
}

void sposta_torre(int dischi, int partenza, int destinazione, int perno)
{
	if (dischi == 1)
		printf("%1d -> %1d\n", partenza, destinazione);
	else
	{
		sposta_torre(dischi - 1, partenza, perno, destinazione);
		printf("%1d -> %1d\n", partenza, destinazione);
		sposta_torre(dischi - 1, perno, destinazione, partenza);
	}
}
