#include <stdio.h>

/* costanti simboliche */
#define N 3   /* dimensione campo di gioco */
#define X 'X' /* simbolo primo giocatore   */
#define O 'O' /* simbolo secondo giocatore */

/* dichiarazioni delle funzioni */
void inizializza_campo();
void visualizza_campo();
void esegui_mossa();
char trova_tria();

/* variabili globali */
char campo[N][N]; /* campo di gioco */

/* gioco della tria: versione umano contro umano */
int main()
{
    int num_mosse;
    char vincitore, turno;

    num_mosse = 0;
    vincitore = '\0'; /* nessun vincitore, per ora! */
    turno = X;        /* inizia il primo giocatore  */

    inizializza_campo();
    visualizza_campo();
    
    do
    {
        /* esegui la prossima mossa */
        esegui_mossa(turno);

        visualizza_campo();

        /* verifica se c'e' qualche tria */
        vincitore = trova_tria();

        /* cambio turno */
        num_mosse++;
        turno = (turno == X) ? O : X;

    } while (num_mosse < N * N && vincitore != X && vincitore != O);

    /* emissione del verdetto */
    if (vincitore == X || vincitore == O)
        printf("Vince %c!\n", vincitore);
    else
        printf("Partita patta.\n");

    return 0;
}

void inizializza_campo()
{
    int r, c;

    /* numera le caselle del campo di gioco */
    for (r = 0; r < N; r++)
        for (c = 0; c < N; c++)
            campo[r][c] = '1' + r * N + c;
}

void visualizza_campo()
{
/*
           1 | 2 | 3
          ---+---+---
           4 | 5 | 6
          ---+---+---
           7 | 8 | 9
*/
    int r, c;

    printf("\n");

    for (r = 0; r < N; r++)
    {
        printf ("          ");

        for (c = 0; c < N; c++)
        {
            printf (" %c ", campo[r][c]);
            
            /* se la casella non e' l'ultima,     */
            /* visualizza il separatore verticale */
            if (c != N - 1)
                printf ("|");
        }

        /* a capo ad ogni riga */   
        printf("\n");

        /* se la riga non e' l'ultima,      */
        /* visualizza una linea orizzontale */
        if (r != N - 1)
            printf ("          ---+---+---\n");
    }

    printf("\n");
}

void esegui_mossa(char turno)
{
    int r, c, mossa;

    do
    {
        do
        {
            /* richiedi il numero della cella */
            /* e verifica che sia valido      */
            printf("%c muove in: ", turno);
            scanf("%d", &mossa);

        } while (mossa < 1 || mossa > N * N);

        /* individua la cella della matrice */
        /* e verifica che sia libera        */
        r = (mossa - 1) / N;
        c = (mossa - 1) % N;

    } while (campo[r][c] == X || campo[r][c] == O);

    /* aggiorna il campo di gioco */
    campo[r][c] = turno;
}

char trova_tria()
{
    char simbolo;
    int r, c, d, tria;

    /* controlla le righe */
    for (r = 0; r < N; r ++)
    {
        /* estrai il simbolo in prima posizione */
        tria = 1;
        simbolo = campo[r][0];

        /* verifica che tutta la riga        */
        /* contiene sempre lo stesso simbolo */
        for (c = 1; c < N; c++)
        {
            if (campo[r][c] != simbolo)
            {
                tria = 0;
                break;
            }
        }

        /* se e' stata trovata una riga           */
        /* di simboli uguali, inutile continuare! */
        if (tria)
            return simbolo;
    }
    
    /* controlla le colonne */
    for (c = 0; c < N; c ++)
    {
        /* estrai il simbolo in prima posizione */
        tria = 1;
        simbolo = campo[0][c];

        /* verifica che tutta la colonna     */
        /* contiene sempre lo stesso simbolo */
        for (r = 1; r < N; r++)
        {
            if (campo[r][c] != simbolo)
            {
                tria = 0;
                break;
            }
        }

        /* se e' stata trovata una colonna        */
        /* di simboli uguali, inutile continuare! */
        if (tria)
            return simbolo;
    }

    /* controlla la diagonale principale */
    tria = 1;
    simbolo = campo[0][0];

    for (d = 1; d < N; d ++)
    {
        if (campo[d][d] != simbolo)
        {
            tria = 0;
            break;
        }
    }

    if (tria)
        return simbolo;

    /* controlla la diagonale secondaria */
    tria = 1;
    simbolo = campo[0][N - 1];

    for (d = 1; d < N; d ++)
    {
        if (campo[d][N - 1 - d] != simbolo)
        {
            tria = 0;
            break;
        }
    }

    if (tria)
        return simbolo;

    return '\0';
}