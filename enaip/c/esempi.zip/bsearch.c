#include <stdio.h>
#include <stdlib.h>

/* costanti simboliche */
#define N 10

/* dichiarazione delle funzioni */
int ricerca_binaria(int elemento);

/* variabili globali */
int vettore[N];

int main()
{
    int i, elem, pos;

    /* genera un vettore di numeri casuali non decrescenti */
    vettore[0] = rand() % 10;
    
    for (i = 1; i < N; i++)
        vettore[i] = vettore[i - 1] + rand() % 10;

    /* visualizza il contenuto del vettore */
    printf("Contenuto del vettore: ");

    for (i = 0; i < N; i++)
        printf("%d ", vettore[i]);

    /* richiede il valore da cercare */
    printf("\n\n");
    printf("Elemento da cercare: ");
    scanf("%d", &elem);
    
    /* esegue la ricerca */
    pos = ricerca_binaria(elem);

    /* emette il verdetto */
    if (pos < 0)
        printf("Elemento non presente\n");
    else
        printf("Elemento presente in posizione %d\n", pos);

    return 0;
}

/* esegue una ricerca binaria - versione iterativa */
int ricerca_binaria(int elemento)
{
    int primo, ultimo, mediano, trovato;

    primo = 0;
    ultimo = N - 1;
    trovato = 0;

    while (primo <= ultimo && ! trovato)
    {
        mediano = (primo + ultimo) / 2;
        
        if (vettore[mediano] < elemento)
            primo = mediano + 1;
        else if (vettore[mediano] > elemento)
            ultimo = mediano - 1;
        else
            trovato = 1;
    }

    return trovato ? mediano : -1;
}
