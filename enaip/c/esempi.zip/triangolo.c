#include <stdio.h>

/* determina la natura di un triangolo di lati dati */
int main()
{
	int a, b, c;

	printf("Lati: ");
	scanf("%d %d %d", &a, &b, &c);

	if ((a < b + c) && (b < a + c) && (c < a + b))
		if ((a == b) && (b == c))
			printf("equilatero");
		else
			if ((a == b) || (b == c) || (a == c))
				printf("isoscele");
			else
				printf("scaleno");
	else
		printf("dati invalidi");

	return 0;
}
