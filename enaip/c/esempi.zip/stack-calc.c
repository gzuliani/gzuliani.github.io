#include <stdio.h>
#include <ctype.h>
#include <string.h>

/* costanti simboliche */
#define MAX_STACK  10
#define MAX_STRING 1024

/* calcolatrice polacca */
int main()
{
    int stack[MAX_STACK];
    char stringa[MAX_STRING];
    
    int num, pos;
    const char* pstringa;

    do
    {
        /* leggi l'espressione */
        gets(stringa);

        /* "svuota" lo stack */
        pos = 0;

        /* analisi della stringa di calcolo */
        pstringa = stringa;

        do
        {
            /* salta gli spazi */
            while (*pstringa != 0 && *pstringa == ' ')
                pstringa++;

            /* termina se non ci sono piu' caratteri a disposizione */
            if (*pstringa == 0)
                break;

            /* il carattere trovato e' una cifra? */
            if (isdigit(*pstringa))
            {
                /* c'e' spazio a sufficienza nello stack? */
                if (pos == MAX_STACK)
                {
                    printf("ERRORE: Stack esaurito.\n");
                    break;
                }
                
                /* leggi il numero intero */
                num = 0;

                do
                {
                    num = num * 10 + *pstringa - '0';
                    pstringa++;

                } while (isdigit(*pstringa));

                /* inserisci il numero nello stack */
                stack[pos] = num;
                pos++;
            }
            /* il carattere trovato e' l'operatore di somma? */
            else if (*pstringa == '+')
            {    
                pstringa++;

                /* controlla la disponibilita' degli operandi */
                if (pos < 1)
                {
                    printf("ERRORE: Numero di operandi insufficiente\n");
                    break;
                }

                /* esegui l'operazione */
                stack[pos - 2] = stack[pos - 1] + stack[pos - 2];
                pos--;
            }
            /* il carattere trovato e' l'operatore di sottrazione? */
            else if (*pstringa == '-')
            {
                pstringa++;

                /* controlla la disponibilita' degli operandi */
                if (pos < 1)
                {
                    printf("ERRORE: Numero di operandi insufficiente\n");
                    break;
                }

                /* esegui l'operazione */
                stack[pos - 2] = stack[pos - 1] - stack[pos - 2];
                pos--;
            }
            /* il carattere trovato e' l'operatore di moltiplicazione? */
            else if (*pstringa == '*')
            {
                pstringa++;

                /* controlla la disponibilita' degli operandi */
                if (pos < 1)
                {
                    printf("ERRORE: Numero di operandi insufficiente\n");
                    break;
                }

                /* esegui l'operazione */
                stack[pos - 2] = stack[pos - 1] * stack[pos - 2];
                pos--;
            }
            /* il carattere trovato e' l'operatore di divisione? */
            else if (*pstringa == '/')
            {
                pstringa++;

                /* controlla la disponibilita' degli operandi */
                if (pos < 1)
                {
                    printf("ERRORE: Numero di operandi insufficiente\n");
                    break;
                }

                /* esegui l'operazione */
                stack[pos - 2] = stack[pos - 1] / stack[pos - 2];
                pos--;
            }
            else
            {
                printf("ERRORE: carattere <%c> invalido.\n", *pstringa);
                break;
            }

        } while (*pstringa != 0);
    
        /* stampa il risultato dell'operazione */
        if (pos > 0)
            printf("Risultato: %d\n", stack[pos - 1]);
        else
            printf("Stack vuoto.\n");
    
    }     while (strlen(stringa) > 0);

    return 0;
}

