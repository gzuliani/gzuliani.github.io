#include <stdio.h>

/* Z:interi, Q:razionali, R:reali, X:ignoto */
enum tipo_numero { Z, Q, R, X };

struct tag_frazione
{
    int num;
    int den;
};

typedef struct tag_frazione frazione;

union tag_numero
{
    int          intero;
    frazione     razionale;
    double       reale;
};

typedef union tag_numero numero;

struct tag_variante
{
    int    tipo_numero;
    numero valore;
};

typedef struct tag_variante variante;

/* funzioni di supporto al tipo di dato "frazione" */
frazione crea_frazione(int num, int den);
frazione somma_frazione_intero(frazione f, int z);
frazione somma_frazioni(frazione f1, frazione f2);
double valore_frazione(frazione f);
void stampa_frazione(frazione f);

/* funzioni di supporto al tipo di dato "variante" */
variante crea_variante_N(unsigned int n);
variante crea_variante_Z(int z);
variante crea_variante_Q(frazione f);
variante crea_variante_R(double r);
variante somma_varianti(variante v1, variante v2);
void stampa_variante(variante v);



/* programma principale */
int main()
{
    variante z, q, r;

    z = crea_variante_Z(2);
    q = crea_variante_Q(crea_frazione(3, 4));
    r = crea_variante_R(0.25);

    printf("z = ");
    stampa_variante(z);
    printf("\n");

    printf("q = ");
    stampa_variante(q);
    printf("\n");

    printf("r = ");
    stampa_variante(r);
    printf("\n");

    printf("\n");
    printf("z + q = ");
    stampa_variante(somma_varianti(z, q));
    printf("\n");

    printf("q + z = ");
    stampa_variante(somma_varianti(q, z));
    printf("\n");

    printf("\n");
    printf("z + r = ");
    stampa_variante(somma_varianti(z, r));
    printf("\n");

    printf("r + z = ");
    stampa_variante(somma_varianti(r, z));
    printf("\n");

    printf("\n");
    printf("q + r = ");
    stampa_variante(somma_varianti(q, r));
    printf("\n");

    printf("r + q = ");
    stampa_variante(somma_varianti(r, q));
    printf("\n");

    printf("\n");
    printf("z + r + q = ");
    stampa_variante(somma_varianti(somma_varianti(z, q), r));
    printf("\n");

    return 0;
}




/* crea una frazione */
frazione crea_frazione(int num, int den)
{
    frazione f;
    f.num = num;
    f.den = den;

    return f;
}

/* somma una frazione con un intero */
frazione somma_frazione_intero(frazione f, int z)
{
    return somma_frazioni(f, crea_frazione(z, 1));
}

/* somma due frazioni */
frazione somma_frazioni(frazione f1, frazione f2)
{
    return crea_frazione(f1.num * f2.den + f2.num * f1.den, f1.den * f2.den);
}

/* determina il valore di una frazione - ritorna 0 se il denominatore � nullo */
double valore_frazione(frazione f)
{
    return (f.den != 0) ? (double)f.num / f.den : 0;
}

/* visualizza una frazione */
void stampa_frazione(frazione f)
{
    printf("%d/%d", f.num, f.den);
}



/* crea una variante intera */
variante crea_variante_Z(int z)
{
    variante v;
    v.tipo_numero = Z;
    v.valore.intero = z;

    return v;
}

/* crea una variante razionale */
variante crea_variante_Q(frazione f)
{
    variante v;
    v.tipo_numero = Q;
    v.valore.razionale = f;

    return v;
}

/* crea una variante reale */
variante crea_variante_R(double r)
{
    variante v;
    v.tipo_numero = R;
    v.valore.reale = r;

    return v;
}

/* somma due varianti */
variante somma_varianti(variante v1, variante v2)
{
    /* il risultato della somma per ora e' ignoto */
    double r;
    frazione f;

    variante v;
    v.tipo_numero = X;
    
    switch (v1.tipo_numero)
    {
        case Z:
            switch (v2.tipo_numero)
            {
                case Z:
                    v = crea_variante_Z(v1.valore.intero + v2.valore.intero);
                    break;

                case Q:
                    f = somma_frazione_intero(v2.valore.razionale, v1.valore.intero);
                    v = crea_variante_Q(f);
                    break;

                case R:
                    v = crea_variante_R(v1.valore.intero + v2.valore.reale);
                    break;

                default:
                    break;
            }
            break;

        case Q:
            switch (v2.tipo_numero)
            {
                case Z:
                    f = somma_frazione_intero(v1.valore.razionale, v2.valore.intero);
                    v = crea_variante_Q(f);
                    break;

                case Q:
                    f = somma_frazioni(v1.valore.razionale, v2.valore.razionale);
                    v = crea_variante_Q(f);
                    break;
    
                case R:
                    r = valore_frazione(v1.valore.razionale);
                    v = crea_variante_R(r + v2.valore.reale);
                    break;

                default:
                    break;
            }
            break;

        case R:
            switch (v2.tipo_numero)
            {
                case Z:
                    v = crea_variante_R(v1.valore.reale + v2.valore.intero);
                    break;

                case Q:
                    r = valore_frazione(v2.valore.razionale);
                    v = crea_variante_R(v1.valore.reale + r);
                    break;

                case R:
                    v = crea_variante_R(v1.valore.reale + v2.valore.reale);
                    break;

                default:
                    break;
            }
            break;

        default:
            break;
    }

    return v;
}

/* visualizza tipo e valore di una variante */
void stampa_variante(variante v)
{
    switch (v.tipo_numero)
    {
        case Z:
            printf("Z: %d", v.valore.intero);
            break;

        case Q:
            printf("Q: ");
            stampa_frazione(v.valore.razionale);
            break;

        case R:
            printf("R: %f", v.valore.reale);
            break;

        default:
            printf("?: ?");
            break;
    }
}
