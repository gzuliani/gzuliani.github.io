#include <stdio.h>
#include <stdlib.h>

/* costanti simboliche */
#define N 10

/* dichiarazione delle funzioni */
int ricerca_binaria(int elemento);
int ricerca_binaria_aux(int inizio, int fine, int elemento);

/* variabili globali */
int vettore[N];

int main()
{
    int i, elem, pos;

    /* genera un vettore di numeri casuali non decrescenti */
    vettore[0] = rand() % 10;
    
    for (i = 1; i < N; i++)
        vettore[i] = vettore[i - 1] + rand() % 10;

    /* visualizza il contenuto del vettore */
    printf("Contenuto del vettore: ");

    for (i = 0; i < N; i++)
        printf("%d ", vettore[i]);

    /* richiede il valore da cercare */
    printf("\n\n");
    printf("Elemento da cercare: ");
    scanf("%d", &elem);
    
    /* esegue la ricerca */
    pos = ricerca_binaria(elem);

    /* emette il verdetto */
    if (pos < 0)
        printf("Elemento non presente\n");
    else
        printf("Elemento presente in posizione %d\n", pos);

    return 0;
}

/* esegue una ricerca binaria - versione ricorsiva */
int ricerca_binaria(int elemento)
{
    return ricerca_binaria_aux(0, N - 1, elemento);
}

/* funzione ricorsiva di supporto */
int ricerca_binaria_aux(int inizio, int fine, int elemento)
{
    int mediano;

    if (inizio > fine)
        return -1;
        
    mediano = (inizio + fine) / 2;
        
    if (vettore[mediano] < elemento)
        return ricerca_binaria_aux(mediano + 1, fine, elemento);
    else if (vettore[mediano] > elemento)
        return ricerca_binaria_aux(inizio, mediano - 1, elemento);
    else
        return mediano;
}
